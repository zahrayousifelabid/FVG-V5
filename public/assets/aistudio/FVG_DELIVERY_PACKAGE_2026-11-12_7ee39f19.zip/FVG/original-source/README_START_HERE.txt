# START HERE — Financial Vision Guide (FVG)

This folder contains only text-readable files and PNG images. No ZIP archives are included.

## Required reading order
1. `00_START_HERE_CLAUDE_CODE.md`
2. `ALL_TEXT_REQUIREMENTS_AND_SOURCE_CONTENT.md` (full consolidated requirements and source text)
3. `specifications/` (the main package's separate specifications)
4. `source_text/` (text extracted from nested handoff archives and source documents)
5. `APPROVED_ABOUT_US_TEXT.txt`
6. `ASSET_REGISTRY.md` and the four PNG assets in `assets/`

## Non-negotiable
Preserve every requirement, feature, formula, research constraint, approved wording and decision. Do not silently remove or simplify anything. If documents conflict, record the conflict in a decision register and ask rather than guessing. Never present synthetic data as real. The Nobo case must not invent internal factory figures, survey responses, interviews or findings. The Ben Alzahra case and Nobo research case must remain separate.

## About Us wording
Use the exact text in `APPROVED_ABOUT_US_TEXT.txt` without edits.

## Images
Only the four user-selected original images are included as PNG. The additional/fifth image is excluded as requested.

## Important delivery note
The full master file is the consolidated reference, while the separate files preserve the readable source documents where available. Text extraction from PDF/DOCX can lose layout or embedded graphics; all binary archives and non-PNG images are intentionally omitted from this folder to comply with the user's file-type restriction.
