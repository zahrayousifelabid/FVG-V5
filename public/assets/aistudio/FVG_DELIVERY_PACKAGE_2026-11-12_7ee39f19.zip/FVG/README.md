# FVG — Financial Vision Guide / دليل رؤيتك المالي

**Smarter Decisions. Stronger Financial Future.**

Owned by Zahra Yousif Elabid Wagiealla Ahmed — Accounting Graduate, Nile University, Class of 2026.

Contact details supplied in the original project materials: Financialvisionguide@gmail.com · 00249911569966.

## Current delivery status

This repository is a development implementation, **not an approved production release**. The supplied source archive did not contain an existing application repository. The current implementation adds a working FastAPI/SQLite service, a React interface, a deterministic calculation engine, tenant-scoped organization/product/cost records, immutable costing snapshots, what-if scenarios, and a research evidence register. It is not the complete multi-module product described by the source specification.

## Implemented in this build

- Arabic-first interface with RTL/LTR language switching and the approved ten-color palette.
- Registration/login/logout; passwords are stored with stdlib scrypt; bearer sessions expire after 12 hours.
- Multiple organizations per account; organization-scoped products and records.
- Server-timed 72-hour trial; writes are blocked after expiry unless an active subscription is present.
- Decimal-based total/unit cost, profit, margin, markup, target price, break-even, unit conversion, allocation, and percentage scenario calculations.
- Cost snapshots preserve entered inputs, period, currency, formula version, results, timestamp and creator.
- Scenario records do not overwrite the base snapshot.
- Traceable overhead allocation records and explicit user-supplied unit conversions.
- Research evidence records use the specified evidence-status vocabulary and explicitly do not claim to be findings.
- Ben Alzahra assets are kept separately; Nobo product images remain quarantined and original source files are preserved.

## Not implemented / not production-ready

See `docs/KNOWN_LIMITATIONS.md`. Among the major missing modules: complete production routing and full lifecycle controls, advanced inventory lots/expiry/returns/rework, allocations workflow UI, FX/inflation source ingestion, complete financial statements, Excel import and broad multi-sheet exports, OCR, AI advisor, full research instruments and analysis, email verification/recovery, role administration/invitations, subscription admin/payment provider, rate limiting, comprehensive audit coverage, automated backup scheduling, and full E2E/browser/security/accessibility validation.

## Quick start

Backend:

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp ../.env.example .env
uvicorn app.main:app --reload
```

Frontend (in a second terminal):

```bash
cd frontend
npm install
npm run dev
```

Vite proxies `/api` to `http://127.0.0.1:8000`. Open the Vite URL shown in the terminal. SQLite data is stored in `backend/fvg.db` when started from the backend directory.

## Essential configuration

Session tokens are random opaque values stored only as SHA-256 digests in the database. Set `FVG_DATABASE_URL` to a protected persistent database location. The current storage adapter is SQLite; production multi-instance deployment requires a managed database and reviewed migrations/locking strategy. Never commit `.env` or real API keys.

## Verification

Backend tests: `cd backend && PYTHONPATH=. pytest -q`. The included suite tests calculation functions, API validation, registration, trial expiry, tenant isolation, cost snapshots, scenario immutability and research evidence records. Frontend production build was not verified in the current environment because npm dependency installation failed with a registry DNS/network error (`EAI_AGAIN`). Latest frontend TSX source passed syntax transpilation with zero syntax diagnostics, but module type-check/build and browser execution remain unverified.

## Source preservation

`original-source/` contains preserved source requirements and the original archive. `assets/quarantine-nobo/` holds Nobo-specific assets outside active product/research modules. `assets/ben-alzahra/` is a separate commercial asset area. Do not treat Ben Alzahra materials as field-study evidence.

## Brand / install metadata

The original supplied app icon is referenced unchanged by the browser favicon, Apple touch icon, launch screen, header and `frontend/public/manifest.webmanifest`. The manifest enables install metadata in compatible browsers; it does not create a native iOS/Android binary and does not imply app-store approval.
