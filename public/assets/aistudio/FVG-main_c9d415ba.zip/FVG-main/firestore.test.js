const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-fvg-44d2717d-cc86-48a4-af9d-60b00b331ba3";
const ALICE_UID = "alice_owner_1";
const BOB_UID = "bob_outsider_2";
const VIEWER_UID = "charlie_viewer_3";
const ORG_ID = "org_fvg_alpha";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function dbFor(ctx) {
  return typeof ctx.firestore === "function" ? ctx.firestore(DATABASE_ID) : ctx.firestore;
}

async function seedOrgAndMembership() {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const adminDb = dbFor(context);
    const now = new Date(Date.now() - 1000);
    await adminDb.collection("organizations").doc(ORG_ID).set({
      name: "Alpha Trading Co",
      baseCurrency: "USD",
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, VIEWER_UID],
      roles: {
        [ALICE_UID]: "owner",
        [VIEWER_UID]: "viewer",
      },
      planTier: "trial",
      subscriptionStatus: "trial",
      trialStartedAt: now,
      trialEndsAt: new Date(now.getTime() + 3 * 86400000),
      createdAt: now,
      updatedAt: now,
    });
  });
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or list organizations or products", async () => {
  await seedOrgAndMembership();
  const unauthDb = dbFor(testEnv.unauthenticatedContext());
  await assertFails(unauthDb.collection("organizations").doc(ORG_ID).get());
  await assertFails(unauthDb.collection("organizations").doc(ORG_ID).collection("products").get());
});

test("Owner can create and read their organization and own user profile", async () => {
  const aliceDb = dbFor(testEnv.authenticatedContext(ALICE_UID));
  const now = new Date(Date.now() - 1000);
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      email: "alice@fvg.test",
      displayName: "Alice",
      preferredLanguage: "en",
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    aliceDb.collection("organizations").doc(ORG_ID).set({
      name: "Alpha Co",
      baseCurrency: "USD",
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID],
      roles: { [ALICE_UID]: "owner" },
      planTier: "trial",
      subscriptionStatus: "trial",
      trialStartedAt: now,
      trialEndsAt: new Date(now.getTime() + 3 * 86400000),
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    aliceDb.collection("organizations").where("memberUids", "array-contains", ALICE_UID).get()
  );
});

test("Cross-organization isolation: outsider cannot read, list unfiltered, or write to another org", async () => {
  await seedOrgAndMembership();
  const aliceDb = dbFor(testEnv.authenticatedContext(ALICE_UID));
  const bobDb = dbFor(testEnv.authenticatedContext(BOB_UID));
  const now = new Date(Date.now() - 1000);
  await assertSucceeds(
    aliceDb.collection("organizations").doc(ORG_ID).collection("products").doc("prod_1").set({
      orgId: ORG_ID,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, VIEWER_UID],
      createdBy: ALICE_UID,
      name: "Cement",
      category: "Materials",
      unit: "ton",
      currency: "USD",
      currentPrice: "120.00",
      previousPrice: "110.00",
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(bobDb.collection("organizations").doc(ORG_ID).get());
  await assertFails(bobDb.collection("organizations").doc(ORG_ID).collection("products").get());
  await assertFails(bobDb.collection("organizations").doc(ORG_ID).collection("products").doc("prod_1").get());
  await assertFails(
    bobDb.collection("organizations").doc(ORG_ID).collection("products").doc("prod_2").set({
      orgId: ORG_ID,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, BOB_UID],
      createdBy: BOB_UID,
      name: "Spoofed Item",
      category: "Grain",
      unit: "kg",
      currency: "USD",
      currentPrice: "10.00",
      previousPrice: "9.00",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Viewer role can read with memberUids filter but cannot write financial records", async () => {
  await seedOrgAndMembership();
  const aliceDb = dbFor(testEnv.authenticatedContext(ALICE_UID));
  const viewerDb = dbFor(testEnv.authenticatedContext(VIEWER_UID));
  const now = new Date(Date.now() - 1000);

  await assertSucceeds(
    aliceDb.collection("organizations").doc(ORG_ID).collection("products").doc("prod_1").set({
      orgId: ORG_ID,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, VIEWER_UID],
      createdBy: ALICE_UID,
      name: "Wheat Flour",
      category: "Commodities",
      unit: "kg",
      currency: "USD",
      currentPrice: "1.80",
      previousPrice: "1.50",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    viewerDb.collection("organizations").doc(ORG_ID).collection("products").where("memberUids", "array-contains", VIEWER_UID).get()
  );

  await assertFails(
    viewerDb.collection("organizations").doc(ORG_ID).collection("products").doc("prod_2").set({
      orgId: ORG_ID,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, VIEWER_UID],
      createdBy: VIEWER_UID,
      name: "Unauthorized Item",
      category: "Commodities",
      unit: "kg",
      currency: "USD",
      currentPrice: "2.00",
      previousPrice: "2.00",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Journal entry enforces balanced debits/credits and terminal lock on posted entries", async () => {
  await seedOrgAndMembership();
  const aliceDb = dbFor(testEnv.authenticatedContext(ALICE_UID));
  const now = new Date(Date.now() - 1000);

  // Unbalanced entry must fail
  await assertFails(
    aliceDb.collection("organizations").doc(ORG_ID).collection("journalEntries").doc("je_unbalanced").set({
      orgId: ORG_ID,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, VIEWER_UID],
      createdBy: ALICE_UID,
      referenceNo: "JE-001",
      entryDate: "2026-11-15",
      period: "2026-11",
      description: "Unbalanced",
      currency: "USD",
      exchangeRate: "1.0000",
      status: "posted",
      lines: [{ accountCode: "1010", debit: "100.00", credit: "0.00" }, { accountCode: "4010", debit: "0.00", credit: "90.00" }],
      totalDebit: "100.00",
      totalCredit: "90.00",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Balanced entry succeeds
  await assertSucceeds(
    aliceDb.collection("organizations").doc(ORG_ID).collection("journalEntries").doc("je_1").set({
      orgId: ORG_ID,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, VIEWER_UID],
      createdBy: ALICE_UID,
      referenceNo: "JE-002",
      entryDate: "2026-11-15",
      period: "2026-11",
      description: "Cash Sale",
      currency: "USD",
      exchangeRate: "1.0000",
      status: "posted",
      lines: [{ accountCode: "1010", debit: "100.00", credit: "0.00" }, { accountCode: "4010", debit: "0.00", credit: "100.00" }],
      totalDebit: "100.00",
      totalCredit: "100.00",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Tampering with posted amounts must fail
  await assertFails(
    aliceDb.collection("organizations").doc(ORG_ID).collection("journalEntries").doc("je_1").update({
      totalDebit: "500.00",
      totalCredit: "500.00",
      updatedAt: now,
    })
  );
});

test("Audit logs and price observations protect history from tampering or deletion", async () => {
  await seedOrgAndMembership();
  const aliceDb = dbFor(testEnv.authenticatedContext(ALICE_UID));
  const now = new Date(Date.now() - 1000);

  await assertSucceeds(
    aliceDb.collection("organizations").doc(ORG_ID).collection("auditLogs").doc("log_1").set({
      orgId: ORG_ID,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, VIEWER_UID],
      createdBy: ALICE_UID,
      action: "CREATE_PRODUCT",
      entityType: "product",
      entityId: "prod_1",
      summary: "Created Wheat Flour",
      actorEmail: "alice@fvg.test",
      createdAt: now,
    })
  );

  await assertFails(
    aliceDb.collection("organizations").doc(ORG_ID).collection("auditLogs").doc("log_1").update({
      summary: "Tampered",
    })
  );
  await assertFails(
    aliceDb.collection("organizations").doc(ORG_ID).collection("auditLogs").doc("log_1").delete()
  );
});

test("Standard costs, production orders, and admin-only scrap loss approvals enforce RBAC and immutability", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const adminDb = dbFor(context);
    const now = new Date(Date.now() - 1000);
    await adminDb.collection("organizations").doc(ORG_ID).set({
      name: "Alpha Manufacturing",
      baseCurrency: "USD",
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, "accountant_4", VIEWER_UID],
      roles: {
        [ALICE_UID]: "owner",
        accountant_4: "accountant",
        [VIEWER_UID]: "viewer",
      },
      planTier: "trial",
      subscriptionStatus: "trial",
      trialStartedAt: now,
      trialEndsAt: new Date(now.getTime() + 3 * 86400000),
      createdAt: now,
      updatedAt: now,
    });
  });

  const aliceDb = dbFor(testEnv.authenticatedContext(ALICE_UID));
  const accountantDb = dbFor(testEnv.authenticatedContext("accountant_4"));
  const viewerDb = dbFor(testEnv.authenticatedContext(VIEWER_UID));
  const bobDb = dbFor(testEnv.authenticatedContext(BOB_UID));
  const now = new Date(Date.now() - 1000);

  // Accountant can create StandardCostSheet & ProductionOrder & pending ScrapLoss
  await assertSucceeds(
    accountantDb.collection("organizations").doc(ORG_ID).collection("standardCosts").doc("std_1").set({
      orgId: ORG_ID,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, "accountant_4", VIEWER_UID],
      createdBy: "accountant_4",
      productId: "prod_1",
      productName: "Roasted Coffee 1kg",
      version: 1,
      currency: "USD",
      standardMaterialCost: "4.00",
      standardLaborHours: "0.50",
      standardLaborRate: "6.00",
      standardOverheadPerUnit: "1.00",
      standardUnitCost: "8.00",
      notes: "Q4 Baseline",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Standard cost updates are forbidden (versioned immutable)
  await assertFails(
    aliceDb.collection("organizations").doc(ORG_ID).collection("standardCosts").doc("std_1").update({
      standardUnitCost: "9.00",
      updatedAt: now,
    })
  );

  // Accountant can create ProductionOrder
  await assertSucceeds(
    accountantDb.collection("organizations").doc(ORG_ID).collection("productionOrders").doc("po_1").set({
      orgId: ORG_ID,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, "accountant_4", VIEWER_UID],
      createdBy: "accountant_4",
      productId: "prod_1",
      productName: "Roasted Coffee 1kg",
      period: "2026-11",
      currency: "USD",
      plannedUnits: "100",
      goodUnits: "95",
      scrapUnits: "5",
      actualMaterialCost: "420.00",
      actualLaborCost: "300.00",
      actualOverheadCost: "100.00",
      actualTotalCost: "820.00",
      status: "in_progress",
      stages: [{ seq: 1, name: "Roasting", status: "in_progress" }],
      createdAt: now,
      updatedAt: now,
    })
  );

  // Accountant creates ScrapLoss awaiting approval
  await assertSucceeds(
    accountantDb.collection("organizations").doc(ORG_ID).collection("scrapLosses").doc("scr_1").set({
      orgId: ORG_ID,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID, "accountant_4", VIEWER_UID],
      createdBy: "accountant_4",
      itemId: "inv_1",
      itemName: "Green Beans",
      lossType: "damaged",
      quantity: "5",
      unitCost: "4.00",
      totalLossCost: "20.00",
      reason: "Moisture damage",
      lossDate: "2026-11-15",
      status: "pending_approval",
      reviewedBy: "",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Accountant cannot self-approve scrapLoss; only owner/admin can approve
  await assertFails(
    accountantDb.collection("organizations").doc(ORG_ID).collection("scrapLosses").doc("scr_1").update({
      status: "approved",
      reviewedBy: "accountant_4",
      updatedAt: now,
    })
  );

  // Owner approves scrapLoss
  await assertSucceeds(
    aliceDb.collection("organizations").doc(ORG_ID).collection("scrapLosses").doc("scr_1").update({
      status: "approved",
      reviewedBy: ALICE_UID,
      updatedAt: now,
    })
  );

  // Already approved scrapLoss cannot be flipped again and cannot be deleted
  await assertFails(
    aliceDb.collection("organizations").doc(ORG_ID).collection("scrapLosses").doc("scr_1").update({
      status: "rejected",
      reviewedBy: ALICE_UID,
      updatedAt: now,
    })
  );
  await assertFails(
    aliceDb.collection("organizations").doc(ORG_ID).collection("scrapLosses").doc("scr_1").delete()
  );

  // Viewer can read standardCosts with memberUids filter, outsider cannot
  await assertSucceeds(
    viewerDb.collection("organizations").doc(ORG_ID).collection("standardCosts").where("memberUids", "array-contains", VIEWER_UID).get()
  );
  await assertFails(
    bobDb.collection("organizations").doc(ORG_ID).collection("scrapLosses").get()
  );
});
