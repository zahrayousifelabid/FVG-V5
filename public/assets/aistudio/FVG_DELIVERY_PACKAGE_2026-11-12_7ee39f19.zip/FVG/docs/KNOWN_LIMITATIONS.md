# Known limitations — honest implementation status

Last reviewed: 2026-11-09. This document describes the code in this package, not planned functionality.

## Working development scope
- FastAPI + SQLite persistence.
- Registration/login/logout; scrypt password hashing; 12-hour bearer sessions.
- Multi-organization membership foundation and tenant-scoped product/cost/scenario/research-evidence records.
- Server-clock 72-hour trial start/expiry and write blocking after expiry. There is no payment/renewal path, so expiry cannot be upgraded through the app.
- Decimal financial calculation engine and cost snapshot history.
- React interface for auth, organization selection, products, costing, history, scenarios, evidence capture, raw-material registration/opening receipts, BOM entry, product standard-cost creation, production-order and stage management, stage labor/machine-hour entry, and variance display. The newest production screens have not passed a dependency-backed build or browser test.
- Backend automated tests currently pass (29 tests; see `ACTUAL_TEST_RESULTS.md`).

## Security gaps — do not deploy publicly
- No email verification or password reset flow.
- No login/register rate limiting, abuse detection, MFA, administrator invitation workflow, session management UI, or security alerting.
- Session tokens are held in frontend memory only; refresh loses the UI session. HTTPS, secure hosting, database encryption and reverse-proxy controls remain deployment responsibilities.
- No complete authorization role administration; viewer role is read-only but only owner membership is created by the current UI/API.
- Audit logging is partial, not comprehensive across every sensitive action.
- No independent penetration test, dependency vulnerability review, threat model sign-off, or external security audit.

## Financial/operational gaps
- Raw-material/BOM costing, production orders, ordered production stages, manual stage labor and machine-hour capture, stage-level material consumption, scrap records and provisional scrap analysis, WIP cost listing, finished-goods receipt/issue quantities, FIFO/moving weighted-average inventory valuation, stocktake adjustments, standard-cost sheets and read-only variance analysis are implemented in the backend. The frontend now has initial workflows for material/BOM/standards/orders/stages/labor/machine hours/variance plus raw-material and finished-goods balances, stocktake, valuation and WIP listing; its dependency-backed build and browser behavior remain unverified. Reusable routing templates, batch/lot/expiry, returns, rework, payroll/time-clock integration, overtime premiums, formal scrap-to-loss accounting and detailed fixed/variable overhead absorption remain incomplete.
- Cost component entry currently supports a basic cost pool; full source documents, allocation drivers, periods, units and traceability screens are not complete.
- No validated multi-currency conversion workflow, historical FX snapshots, inflation index ingestion, or replacement-cost policy engine.
- No financial statement ingestion/reconciliation, budgets, cash flow, full ratio analysis, or management reporting suite.
- No Excel import/export, PDF reporting, OCR, formula-injection scanning or upload quarantine.
- No automated backup schedule, disaster recovery rehearsal, or managed database migration tooling. SQLite schema is initialized idempotently at startup; this is not a substitute for versioned production migrations.

## Research/AI/external integrations
- Research evidence register only. Research questions, sampling, consent, instruments, field collection workflow, data dictionary, coding, cleaning, hypotheses, verified analysis and report export remain incomplete.
- No field research findings or real-world financial data are included.
- No AI provider integration; no AI answers should be represented as available.
- No payment, email, OCR, FX, analytics or cloud storage provider credentials were supplied. Those integrations are inactive.
- Synthetic/demo records must be labelled `SYNTHETIC / DEMO DATA — NOT REAL FIELD DATA.` No synthetic field findings are shipped.

## Frontend verification
- TSX syntax transpilation completed with zero syntax diagnostics in the 2026-11-11 inventory/WIP UI increment. This does not replace module type-checking or a production build.
- The Vite/TypeScript build was not verified because `npm install` timed out in the current environment.
- No full browser E2E, accessibility audit, responsive screenshot suite, cross-browser validation, or localization completeness review has been performed.

## Brand assets
- The supplied composite reference and JPEG app-icon reference are preserved. No separate vector/transparent original logo master was supplied; do not claim that a faithful original logo master exists.
- Founder portrait and Ben Alzahra assets are preserved. Nobo-specific product images are quarantined and remain in the untouched original source archive.

## Additional production/inventory boundaries (2026-11-09)

Raw-material records, BOMs, production cost orders, ordered production stages, stage labor capture, WIP cost listing, finished-goods receipts/issues, FIFO/moving weighted-average valuation and basic stocktake adjustment ledgers now exist and have backend tests. This is not a complete manufacturing execution system: reusable routing templates, stage-level material consumption, batch/lot/expiry, returns, rework/scrap workflows, payroll integration, detailed machine-based overhead spending/efficiency decomposition and formal count-session approvals remain unimplemented. Basic versioned standard-vs-actual material/labor/overhead variance analysis is now available in the backend, with the limitations listed below. Dedicated frontend screens for finished-goods production receipts, stage materials/scrap details and inventory audit history are still incomplete; basic WIP, finished-goods issue/stocktake/valuation and raw-material stocktake/valuation screens now exist.

### Production-stage materials and scrap increment limitations
- Stage material issues require the registered inventory unit exactly; automatic unit conversion is not applied at posting time.
- Actual stage material issues are valued using the selected inventory replay method and replace the BOM estimate with accumulated actual stage issues. Mixed workflows that combine some stage-level actual material issues with unrecorded materials need reconciliation before relying on the order's material-cost total.
- Scrap is recorded as an operational quantity and reason only. It does not automatically reduce good saleable units, adjust finished-goods receipts, or post scrap-to-loss accounting entries.
- No rework, scrap recovery, by-product, co-product, or multi-warehouse stage issue workflow is implemented.

### Standard-cost and variance-analysis boundaries (2026-11-11)
- Standard-cost sheets are manually supplied, versioned product benchmarks; no automatic standards are inferred from historical actuals.
- Variance analysis uses the latest standard sheet at query time. Production orders do not yet lock the standard version effective when the order began.
- Material price/usage variances require stage-level actual material issues for every material in the standard sheet. Missing material actuals make the material and combined variance unavailable.
- Labor rate/efficiency variances require recorded stage labor. If standard labor is non-zero and no actual labor is recorded, labor and combined variance are unavailable.
- Overhead comparison includes only the production-order overhead field plus stage overhead fields. No machine-hour, activity-based, capacity, fixed/variable overhead absorption, or overhead spending/efficiency split is implemented.
- Variance reports are read-only. They do not post journals, change production orders, revise standard costs, or make operational forecasts. Confirm the completeness and period alignment of actual records before management or financial use.

## Research Workspace fieldwork UI increment (2026-11-11)
- The interface now supports pseudonymous establishment registry, permission metadata, interview/survey/observation metadata, hypothesis register, data dictionary and evidence register, with organization-scoped list refresh.
- Permission records are metadata only. The application does not inspect signed consent/authorization files, grant ethics approval, or provide a secure document vault.
- Interaction entries contain metadata and status only; a full survey/interview instrument builder, encrypted response storage, coding, cleaning, anonymization workflow, participant withdrawal workflow and research publication exporter are not implemented.
- Hypothesis evidence references are checked against the same organization, but evidence quality and researcher interpretation still require human review. Hypothesis statuses are not automatically verified findings.
- The research JSON export is a structured workspace export, not a validated academic report.
- Frontend module type-check/build and browser tests remain unverified because package installation could not reach the npm registry (`EAI_AGAIN`).

## Research field-data limitations (2026-11-11)
- Versioned survey/interview instrument metadata and structured response capture are implemented, but there is no drag-and-drop form designer, offline field collection, attachment vault, participant-facing portal or electronic consent signature workflow.
- Raw responses are retained as JSON and cleaning actions are separate audit records. There is not yet a versioned cleaned-analysis dataset, automated statistical cleaning, duplicate-detection engine, coding framework UI, inter-rater reliability workflow or validated statistical analysis module.
- Instrument allowed-value validation is field-level; date values currently receive string-type validation and require researcher review for calendar validity.
- Research exports contain confidential field records; access is organization-scoped, but export-specific redaction profiles and approval workflow remain outstanding.

## Additional 2026-11-12 limitation
- Research instrument authoring and response capture now have guided schema-driven forms. A respondent portal, offline capture, consent document vault/signature workflow, automated analysis dataset, and statistical analysis remain incomplete.
- Frontend Vite build, full TypeScript project check, browser/e2e, accessibility, and visual regression remain unverified because npm dependency installation timed out.


## 2026-11-12 consolidated release boundary
- The guided research instrument builder and schema-driven response form are implemented in the current source. They do not constitute a complete research data-management or statistical-analysis system.
- The six-screen navigation and dashboard refinement are implemented at code level, but visual parity with the supplied composite reference has not been proven by browser screenshots.
- The original app-icon JPEG is preserved and referenced by web metadata; this is not a native iOS/Android store package.
- The application is not approved for production. Do not use it for live financial, payroll, tax, regulatory, or confidential field decisions without the missing validation, security, accounting review, and deployment controls.


## Product CSV import boundary — 2026-11-12
The product CSV importer is a bounded preview-and-commit workflow only. It does not import costing, raw-material, BOM, inventory, or research data. XLSX import, reusable templates, import history/undo, large-file streaming, and browser E2E verification are not implemented. CSV formula-like values are rejected in imported text fields; this does not replace a broader spreadsheet security review.
