package com.example.domain.engine

import org.junit.Assert.*
import org.junit.Test
import java.math.BigDecimal

class FvgFinancialEngineTest {

    @Test
    fun priceChange_handlesNormalAndZeroPreviousPrice() {
        val normal = FvgFinancialEngine.calculatePriceChange(BigDecimal("125.00"), BigDecimal("100.00"))
        assertEquals(BigDecimal("25.00"), normal.absChange)
        assertEquals(BigDecimal("25.00"), normal.pctChange)
        assertEquals("increased", normal.direction)

        val zeroPrev = FvgFinancialEngine.calculatePriceChange(BigDecimal("50.00"), BigDecimal.ZERO)
        assertEquals(BigDecimal("50.00"), zeroPrev.absChange)
        assertNull(zeroPrev.pctChange)
        assertEquals("increased", zeroPrev.direction)
    }

    @Test
    fun inflationAndWeightedBasket_calculatesIndexAndCumulativeRate() {
        val monthly = FvgFinancialEngine.calculatePeriodInflationPct(BigDecimal("105.00"), BigDecimal("100.00"))
        assertEquals(BigDecimal("5.00"), monthly)

        val cumulative = FvgFinancialEngine.calculateCumulativeInflationPct(
            listOf(BigDecimal("5.00"), BigDecimal("5.00"))
        )
        assertEquals(BigDecimal("10.25"), cumulative)

        val basket = FvgFinancialEngine.calculateWeightedBasket(
            listOf(
                FvgFinancialEngine.BasketLineInput("Flour", BigDecimal("2"), BigDecimal("0.6"), BigDecimal("10.00"), BigDecimal("12.00")),
                FvgFinancialEngine.BasketLineInput("Oil", BigDecimal("1"), BigDecimal("0.4"), BigDecimal("20.00"), BigDecimal("25.00"))
            )
        )
        // Base = 12 + 8 = 20.00; Current = 14.4 + 10 = 24.40; Index = 122.00
        assertEquals(BigDecimal("20.00"), basket.baseCost)
        assertEquals(BigDecimal("24.40"), basket.currentCost)
        assertEquals(BigDecimal("122.00"), basket.indexValue)
    }

    @Test
    fun costing_distinguishesMarginFromMarkup_andComputesBreakEven() {
        val res = FvgFinancialEngine.calculateCosting(
            FvgFinancialEngine.CostingInput(
                directMaterial = BigDecimal("150.00"),
                directLabor = BigDecimal("80.00"),
                overhead = BigDecimal("70.00"),
                fixedCosts = BigDecimal("7000.00"),
                goodUnits = BigDecimal("100"),
                sellingPrice = BigDecimal("6.00")
            )
        )
        assertEquals(BigDecimal("300.00"), res.totalCost)
        assertEquals(BigDecimal("3.00"), res.unitCost)
        // Margin = (6 - 3)/6 = 50.00%, Markup = (6 - 3)/3 = 100.00%
        assertEquals(BigDecimal("50.00"), res.profitMarginPct)
        assertEquals(BigDecimal("100.00"), res.markupPct)
        assertEquals(BigDecimal("2334"), res.breakEvenUnits)
    }

    @Test
    fun accountingStatementsAndRatios_balanceEquationAndFlagMissingInputs() {
        val accounts = listOf(
            FvgFinancialEngine.AccountInput("1010", "Cash", "asset", "cash_bank", "debit", BigDecimal.ZERO),
            FvgFinancialEngine.AccountInput("1210", "Inventory", "asset", "inventory", "debit", BigDecimal.ZERO),
            FvgFinancialEngine.AccountInput("3010", "Equity", "equity", "equity", "credit", BigDecimal.ZERO),
            FvgFinancialEngine.AccountInput("4010", "Revenue", "revenue", "revenue", "credit", BigDecimal.ZERO),
            FvgFinancialEngine.AccountInput("5010", "COGS", "cogs", "cogs", "debit", BigDecimal.ZERO)
        )
        val entries = listOf(
            listOf(
                FvgFinancialEngine.JournalLineInput("1010", "Cash", BigDecimal("10000.00"), BigDecimal.ZERO),
                FvgFinancialEngine.JournalLineInput("3010", "Equity", BigDecimal.ZERO, BigDecimal("10000.00"))
            ),
            listOf(
                FvgFinancialEngine.JournalLineInput("1210", "Inventory", BigDecimal("4000.00"), BigDecimal.ZERO),
                FvgFinancialEngine.JournalLineInput("1010", "Cash", BigDecimal.ZERO, BigDecimal("4000.00"))
            ),
            listOf(
                FvgFinancialEngine.JournalLineInput("1010", "Cash", BigDecimal("6000.00"), BigDecimal.ZERO),
                FvgFinancialEngine.JournalLineInput("4010", "Revenue", BigDecimal.ZERO, BigDecimal("6000.00"))
            ),
            listOf(
                FvgFinancialEngine.JournalLineInput("5010", "COGS", BigDecimal("2500.00"), BigDecimal.ZERO),
                FvgFinancialEngine.JournalLineInput("1210", "Inventory", BigDecimal.ZERO, BigDecimal("2500.00"))
            )
        )
        val stmt = FvgFinancialEngine.generateFinancialStatements(accounts, entries)
        assertTrue(stmt.isTrialBalanced)
        assertTrue(stmt.isAccountingEquationBalanced)
        assertEquals(BigDecimal("3500.00"), stmt.netProfit)
        assertEquals(BigDecimal("13500.00"), stmt.totalAssets)
        assertEquals(BigDecimal("13500.00"), stmt.totalLiabilitiesAndEquity)

        val ratios = FvgFinancialEngine.computeFinancialRatios(stmt)
        val currentRatio = ratios.first { it.key == "current_ratio" }
        assertNull(currentRatio.value)
        assertNotNull(currentRatio.missingDataWarning)
    }

    @Test
    fun inventoryFifoAndMovingAvg_andReplacementGap_calculateDeterministically() {
        val lot1 = FvgFinancialEngine.FifoLot("2026-10-01", BigDecimal("10"), BigDecimal("10.00"))
        val lot2 = FvgFinancialEngine.FifoLot("2026-10-15", BigDecimal("10"), BigDecimal("20.00"))
        val fifoOut = FvgFinancialEngine.applyInventoryIssue(
            valuationMethod = "fifo",
            currentQty = BigDecimal("20"),
            currentBookValue = BigDecimal("300.00"),
            currentMovingAvg = BigDecimal("15.00"),
            currentLots = listOf(lot1, lot2),
            issueQty = BigDecimal("12")
        )
        // Consumes 10@10 + 2@20 = 140.00 COGS, leaving 8@20 = 160.00
        assertEquals(BigDecimal("140.00"), fifoOut.movementTotalCost)
        assertEquals(BigDecimal("160.00"), fifoOut.newTotalBookValue)

        val mwaOut = FvgFinancialEngine.applyInventoryIssue(
            valuationMethod = "moving_avg",
            currentQty = BigDecimal("20"),
            currentBookValue = BigDecimal("300.00"),
            currentMovingAvg = BigDecimal("15.00"),
            currentLots = listOf(lot1, lot2),
            issueQty = BigDecimal("12")
        )
        assertEquals(BigDecimal("180.00"), mwaOut.movementTotalCost)
        assertEquals(BigDecimal("120.00"), mwaOut.newTotalBookValue)

        val repl = FvgFinancialEngine.analyzeReplacementCost(
            quantityOnHand = BigDecimal("8"),
            bookValue = BigDecimal("160.00"),
            currentMarketPrice = BigDecimal("25.00"),
            inflationFactor = BigDecimal("1.10")
        )
        assertEquals(BigDecimal("200.00"), repl.currentReplacementCost)
        assertEquals(BigDecimal("40.00"), repl.replacementGap)
    }

    @Test
    fun csvImport_rejectsFormulaInjectionAndDuplicates() {
        val csv = """
            name,sku,category,unit,currency,price,location
            Flour,FLR-1,Grain,kg,USD,2.50,HQ
            =CMD('calc'),BAD-1,Grain,kg,USD,1.00,HQ
            DuplicateSku,FLR-1,Grain,kg,USD,3.00,HQ
        """.trimIndent()
        val parsed = FvgFinancialEngine.parseAndValidateProductCsv(csv, emptySet())
        assertEquals(3, parsed.size)
        assertNull(parsed[0].error)
        assertNotNull(parsed[1].error)
        assertNotNull(parsed[2].error)
    }

    @Test
    fun trialCountdown_computesExact3DayBreakdownAndExpiredState() {
        val now = 1_700_000_000_000L
        // 2 days, 5 hours, 17 minutes, 43 seconds remaining
        val end = now + (2L * 86400_000L) + (5L * 3600_000L) + (17L * 60_000L) + (43L * 1000L)
        val active = FvgFinancialEngine.computeTrialCountdown(end, now)
        assertFalse(active.isExpired)
        assertEquals(2L, active.days)
        assertEquals(5L, active.hours)
        assertEquals(17L, active.minutes)
        assertEquals(43L, active.seconds)
        assertEquals(53L, active.totalRemainingHours)

        val exact72h = FvgFinancialEngine.computeTrialCountdown(now + 3L * 86400_000L, now)
        assertFalse(exact72h.isExpired)
        assertEquals(3L, exact72h.days)
        assertEquals(0L, exact72h.hours)
        assertEquals(72L, exact72h.totalRemainingHours)

        val expired = FvgFinancialEngine.computeTrialCountdown(now - 5000L, now)
        assertTrue(expired.isExpired)
        assertEquals(0L, expired.days)
        assertEquals(0L, expired.seconds)
    }

    @Test
    fun priceSpikeVarianceYieldVolatilityCvpGlAgingAndBridge_computeDeterministically() {
        assertTrue(FvgFinancialEngine.isUnusualPriceMovement(BigDecimal("15.00")))
        assertTrue(FvgFinancialEngine.isUnusualPriceMovement(BigDecimal("-22.50")))
        assertFalse(FvgFinancialEngine.isUnusualPriceMovement(BigDecimal("14.99")))
        assertFalse(FvgFinancialEngine.isUnusualPriceMovement(null))

        // Standard Cost Variance: complete vs incomplete
        val vComplete = FvgFinancialEngine.computeCostVariance(
            stdMaterialPerUnit = BigDecimal("10.00"),
            stdLaborHoursPerUnit = BigDecimal("2.00"),
            stdLaborRate = BigDecimal("5.00"),
            stdOverheadPerUnit = BigDecimal("3.00"),
            goodUnits = BigDecimal("10"),
            actualMaterialCost = BigDecimal("115.00"),
            actualLaborCost = BigDecimal("95.00"),
            actualOverheadCost = BigDecimal("30.00")
        )
        assertEquals(BigDecimal("230.00"), vComplete.standardTotalAllowed)
        assertEquals(BigDecimal("15.00"), vComplete.materialVariance)
        assertEquals(BigDecimal("-5.00"), vComplete.laborVariance)
        assertEquals(BigDecimal("0.00"), vComplete.overheadVariance)
        assertEquals(BigDecimal("10.00"), vComplete.totalVariance)

        val vIncomplete = FvgFinancialEngine.computeCostVariance(
            BigDecimal("10.00"), BigDecimal("2.00"), BigDecimal("5.00"), BigDecimal("3.00"),
            BigDecimal("10"), BigDecimal("115.00"), null, null
        )
        assertNull(vIncomplete.totalVariance)
        assertTrue(vIncomplete.completenessNote.contains("withheld"))

        // Scrap & Yield analysis
        val scrapYield = FvgFinancialEngine.computeScrapYieldAnalysis(
            plannedUnits = BigDecimal("100"),
            goodUnits = BigDecimal("90"),
            recordedScrapUnits = BigDecimal("10"),
            totalCost = BigDecimal("900.00")
        )
        assertEquals(BigDecimal("10.00"), scrapYield.scrapRatePct)
        assertEquals(BigDecimal("90.00"), scrapYield.yieldPct)
        assertEquals(BigDecimal("10.00"), scrapYield.currentCostPerGoodUnit)
        assertEquals(BigDecimal("10.00"), scrapYield.indicativeCostAfterScrap)

        // Cost volatility
        val vol = FvgFinancialEngine.computeCostVolatility(
            listOf(BigDecimal("10.00"), BigDecimal("12.00"), BigDecimal("14.00"))
        )!!
        assertEquals(BigDecimal("10.00"), vol.minCost)
        assertEquals(BigDecimal("14.00"), vol.maxCost)
        assertEquals(BigDecimal("12.00"), vol.meanCost)
        assertEquals(BigDecimal("40.00"), vol.spreadPct)

        // CVP curve points
        val cvp = FvgFinancialEngine.generateCvpCurvePoints(
            fixedCosts = BigDecimal("1000"),
            variableUnitCost = BigDecimal("5"),
            sellingPrice = BigDecimal("10"),
            maxUnits = BigDecimal("500")
        )
        assertEquals(6, cvp.size)
        assertEquals(1000f, cvp.first().totalCost, 0.01f)
        assertEquals(0f, cvp.first().totalRevenue, 0.01f)

        // General Ledger running balance
        val cashAcc = FvgFinancialEngine.AccountInput("1010", "Cash", "asset", "cash_bank", "debit", BigDecimal("1000.00"))
        val gl = FvgFinancialEngine.computeAccountLedgerStatement(
            account = cashAcc,
            entries = listOf(
                Triple("2026-11-01", "JE-1", "Sale" to listOf(FvgFinancialEngine.JournalLineInput("1010", "Cash", BigDecimal("500.00"), BigDecimal.ZERO))),
                Triple("2026-11-05", "JE-2", "Expense" to listOf(FvgFinancialEngine.JournalLineInput("1010", "Cash", BigDecimal.ZERO, BigDecimal("200.00"))))
            )
        )
        assertEquals(2, gl.movements.size)
        assertEquals(BigDecimal("1500.00"), gl.movements[0].runningBalance)
        assertEquals(BigDecimal("1300.00"), gl.closingBalance)

        // AR/AP aging buckets
        val asOf = 20000L
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val day0 = fmt.format(java.util.Date(asOf * 86400_000L))
        val dayPast20 = fmt.format(java.util.Date((asOf - 20) * 86400_000L))
        val dayPast95 = fmt.format(java.util.Date((asOf - 95) * 86400_000L))
        val aging = FvgFinancialEngine.computeArApAgingBuckets(
            listOf(
                Triple(day0, BigDecimal("100.00"), "open"),
                Triple(dayPast20, BigDecimal("250.00"), "partial"),
                Triple(dayPast95, BigDecimal("400.00"), "open"),
                Triple(dayPast95, BigDecimal("999.00"), "paid")
            ),
            asOfEpochDays = asOf
        )
        assertEquals(BigDecimal("100.00"), aging.currentAmount)
        assertEquals(BigDecimal("250.00"), aging.days1To30Amount)
        assertEquals(BigDecimal("400.00"), aging.days90PlusAmount)
        assertEquals(2, aging.overdueCount)

        // Period Comparison Profit Bridge
        val accs = listOf(
            FvgFinancialEngine.AccountInput("1010", "Cash", "asset", "cash_bank", "debit", BigDecimal.ZERO),
            FvgFinancialEngine.AccountInput("4010", "Revenue", "revenue", "revenue", "credit", BigDecimal.ZERO),
            FvgFinancialEngine.AccountInput("5010", "COGS", "cogs", "cogs", "debit", BigDecimal.ZERO)
        )
        val dated = listOf(
            "2026-10" to listOf(
                FvgFinancialEngine.JournalLineInput("1010", "Cash", BigDecimal("1000"), BigDecimal.ZERO),
                FvgFinancialEngine.JournalLineInput("4010", "Revenue", BigDecimal.ZERO, BigDecimal("1000"))
            ),
            "2026-11" to listOf(
                FvgFinancialEngine.JournalLineInput("1010", "Cash", BigDecimal("1800"), BigDecimal.ZERO),
                FvgFinancialEngine.JournalLineInput("4010", "Revenue", BigDecimal.ZERO, BigDecimal("1800"))
            )
        )
        val bridge = FvgFinancialEngine.comparePeriodsProfitBridge(accs, dated, "2026-10", "2026-11")
        assertEquals(BigDecimal("800.00"), bridge.revenueDelta)
        assertEquals(BigDecimal("800.00"), bridge.netProfitDelta)

        // Accounting CSV parser with formula injection & unknown account guard
        val accCsv = """
            date,refNo,description,debitCode,creditCode,amount
            2026-11-15,JE-99,Cash sale,1010,4010,550.00
            2026-11-15,JE-BAD,=CMD(),1010,4010,100.00
            2026-11-15,JE-UNK,Unknown acc,9999,4010,100.00
        """.trimIndent()
        val parsedAcc = FvgFinancialEngine.parseAndValidateAccountingCsv(accCsv, setOf("1010", "4010"))
        assertEquals(3, parsedAcc.size)
        assertNull(parsedAcc[0].error)
        assertEquals(BigDecimal("550.00"), parsedAcc[0].amount)
        assertNotNull(parsedAcc[1].error)
        assertNotNull(parsedAcc[2].error)
    }
}
