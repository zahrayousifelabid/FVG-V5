package com.example

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.domain.export.FvgExportService
import com.example.domain.export.ReportExportPayload
import com.example.ui.screens.APPROVED_ARABIC_ABOUT_US
import com.example.ui.screens.DeveloperShowcaseScreen
import com.example.ui.screens.FvgSplashScreen
import com.example.ui.screens.PublicWebsiteAndAuthScreen
import com.example.ui.theme.FvgTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class FvgAppCujTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun splashScreen_rendersFvgBrandIdentity() {
        var finished = false
        composeRule.setContent {
            FvgTheme(darkTheme = false, isArabic = false) {
                FvgSplashScreen(isArabic = false) { finished = true }
            }
        }
        composeRule.onNodeWithTag("fvg_splash_screen").assertIsDisplayed()
        composeRule.onNodeWithText("FVG").assertIsDisplayed()
        composeRule.onNodeWithText("Financial Vision Guide").assertIsDisplayed()
        composeRule.onNodeWithText("دليل رؤيتك المالي").assertIsDisplayed()
        composeRule.onNodeWithText("Smarter Decisions. Stronger Financial Future.").assertIsDisplayed()
    }

    @Test
    fun developerShowcaseScreen_displaysPortraitAndExactVisionAndContinues() {
        var continued = false
        composeRule.setContent {
            FvgTheme(darkTheme = false, isArabic = false) {
                DeveloperShowcaseScreen(
                    isArabic = false,
                    isDark = false,
                    onToggleLanguage = {},
                    onToggleTheme = {},
                    onContinue = { continued = true }
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("developer_showcase_screen").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Zahra Yousif Developer Portrait").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Zahra Yousif  |  زهراء يوسف").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText(APPROVED_ARABIC_ABOUT_US).performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("trial_countdown_banner").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Days").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Hours").assertIsDisplayed()
        composeRule.onNodeWithText("Mins").assertIsDisplayed()
        composeRule.onNodeWithText("Secs").assertIsDisplayed()

        composeRule.onNodeWithTag("developer_continue_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertTrue(continued)
    }

    @Test
    fun publicWebsite_navigatesPagesDisplaysShowcasesAnd3DayCountdownAndArabicRtl() {
        composeRule.setContent {
            val isArabic = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
            FvgTheme(darkTheme = false, isArabic = isArabic.value) {
                PublicWebsiteAndAuthScreen(
                    isArabic = isArabic.value,
                    isDark = false,
                    isSigningIn = false,
                    authError = null,
                    onToggleLanguage = { isArabic.value = !isArabic.value },
                    onToggleTheme = {},
                    onGoogleSignInClick = {}
                )
            }
        }

        // Verify Home page + Google Sign-In CTA + 3-Day D:H:M:S countdown + restored photos
        composeRule.onNodeWithTag("google_sign_in_button").assertIsDisplayed()
        composeRule.onNodeWithTag("trial_countdown_banner").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Days").assertIsDisplayed()
        composeRule.onNodeWithText("Hours").assertIsDisplayed()
        composeRule.onNodeWithText("Mins").assertIsDisplayed()
        composeRule.onNodeWithText("Secs").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Zahra Yousif Founder Portrait").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Ben Al-Zahra Commercial Products Visual Showcase").performScrollTo().assertIsDisplayed()

        // Navigate to Features tab (index 1)
        composeRule.onNodeWithTag("public_nav_tab_1").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Price Registry, Anomaly Alerts & Trends").performScrollTo().assertIsDisplayed()

        // Navigate to Pricing Plans tab (index 2) and verify 3-Day (72h) Trial & honest adapter notice
        composeRule.onNodeWithTag("public_nav_tab_2").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("3-Day (72h) Trial").performScrollTo().assertIsDisplayed()

        // Toggle to Arabic (RTL)
        composeRule.onNodeWithTag("toggle_language_button").performClick()
        composeRule.onNodeWithTag("public_nav_tab_0").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("google_sign_in_button").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun exportService_producesValidCsvJsonOpenXmlXlsxAndWorkspaceBackup() {
        val payload = ReportExportPayload(
            title = "Financial Statements Test",
            organizationName = "FVG Demo Co",
            currency = "USD",
            generatedDate = "2026-11-15",
            methodNotes = "Double-Entry Accrual",
            headers = listOf("Account", "Amount"),
            rows = listOf(
                listOf("Revenue", "12500.00"),
                listOf("Net Profit", "4200.00")
            ),
            missingDataNotes = listOf("Interest coverage skipped: zero interest expense")
        )

        val csv = FvgExportService.toCsvString(payload)
        assertTrue(csv.contains("# FVG Report: Financial Statements Test"))
        assertTrue(csv.contains("\"Revenue\",\"12500.00\""))

        val json = FvgExportService.toJsonString(payload)
        assertTrue(json.contains("\"organization\": \"FVG Demo Co\""))
        assertTrue(json.contains("\"Amount\": \"4200.00\""))

        val backupJson = FvgExportService.toWorkspaceBackupJson(
            organizationName = "FVG Demo Co",
            baseCurrency = "USD",
            generatedAtIso = "2026-11-15",
            sections = mapOf("products" to 2, "journalEntries" to 5),
            payloads = listOf(payload)
        )
        assertTrue(backupJson.contains("\"schema\": \"FVG_WORKSPACE_BACKUP_V1\""))
        assertTrue(backupJson.contains("\"journalEntries\": 5"))
        assertTrue(backupJson.contains("\"datasets\""))

        val xlsxBytes = ByteArrayOutputStream()
        FvgExportService.writeXlsx(xlsxBytes, payload)
        assertTrue(xlsxBytes.size() > 200)

        val roundTripCsv = FvgExportService.extractXlsxToCsvLines(ByteArrayInputStream(xlsxBytes.toByteArray()))
        assertTrue(roundTripCsv.contains("Revenue,12500.00"))
        assertTrue(roundTripCsv.contains("Net Profit,4200.00"))
    }
}
