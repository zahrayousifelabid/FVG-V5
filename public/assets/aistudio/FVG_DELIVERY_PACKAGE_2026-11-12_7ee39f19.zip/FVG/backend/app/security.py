"""Minimal stdlib security primitives; production deployment still requires HTTPS and secret management."""
import os, hashlib, hmac, secrets, time
from datetime import datetime, timedelta, timezone
from .storage import connect

SECRET=os.getenv('FVG_SESSION_SECRET','')
if not SECRET or SECRET.startswith('CHANGE_ME'):
    SECRET='development-only-change-before-deployment'

def hash_password(password:str)->str:
    salt=secrets.token_bytes(16)
    key=hashlib.scrypt(password.encode(),salt=salt,n=2**14,r=8,p=1,dklen=32)
    return 'scrypt$'+salt.hex()+'$'+key.hex()

def verify_password(password:str, encoded:str)->bool:
    try:
        algo,salt,key=encoded.split('$'); actual=hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=2**14,r=8,p=1,dklen=32)
        return algo=='scrypt' and hmac.compare_digest(actual,bytes.fromhex(key))
    except Exception: return False

def issue_session(user_id:str)->str:
    token=secrets.token_urlsafe(32); digest=hashlib.sha256(token.encode()).hexdigest()
    now=datetime.now(timezone.utc); expiry=now+timedelta(hours=12)
    with connect() as c: c.execute('INSERT INTO sessions VALUES(?,?,?,?)',(digest,user_id,expiry.isoformat(),now.isoformat()))
    return token

def authenticate(token:str):
    digest=hashlib.sha256(token.encode()).hexdigest()
    with connect() as c:
        row=c.execute('SELECT user_id,expires_at FROM sessions WHERE token_hash=?',(digest,)).fetchone()
        if not row or datetime.fromisoformat(row['expires_at']) <= datetime.now(timezone.utc): return None
        return row['user_id']
