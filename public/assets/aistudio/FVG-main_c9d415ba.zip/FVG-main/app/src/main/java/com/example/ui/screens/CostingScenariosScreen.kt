package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.CostSnapshot
import com.example.data.model.ProductionOrderRecord
import com.example.data.model.StandardCostSheet
import com.example.domain.engine.FvgFinancialEngine
import com.example.ui.components.*
import com.example.ui.i18n.fvgStrings
import com.example.ui.theme.*
import com.example.ui.viewmodel.FvgUiState
import com.example.ui.viewmodel.FvgViewModel
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CostingScenariosScreen(
    state: FvgUiState,
    viewModel: FvgViewModel,
    isArabic: Boolean,
    isDark: Boolean,
    onToggleLanguage: () -> Unit,
    onToggleTheme: () -> Unit
) {
    val s = fvgStrings(isArabic)
    var subTab by remember { mutableIntStateOf(0) }
    val defaultCurrency = state.activeOrg?.baseCurrency ?: "USD"
    val currentPeriod = remember { SimpleDateFormat("yyyy-MM", Locale.US).format(Date()) }

    Column(modifier = Modifier.fillMaxSize().testTag("costing_scenarios_screen")) {
        FvgTopHeaderBanner(
            title = if (isArabic) "التكاليف والتحليل والسيناريوهات" else "Costing, CVP & Standards",
            subtitle = s.brandTaglineEn,
            icon = Icons.Filled.Calculate,
            isArabic = isArabic,
            isDark = isDark,
            onToggleLanguage = onToggleLanguage,
            onToggleTheme = onToggleTheme,
            orgName = state.activeOrg?.name,
            roleBadge = state.currentUserRole
        )
        FvgSubTabRow(
            tabs = listOf(s.tabProductCosting, s.tabCostingCvp, s.tabStandardsProd, s.tabWhatIfScenarios),
            selectedIndex = subTab,
            onSelect = { subTab = it },
            testTagPrefix = "costing"
        )

        when (subTab) {
            0 -> ProductCostingTab(state, viewModel, isArabic, currentPeriod, defaultCurrency)
            1 -> CvpAndProfitabilityTab(state, isArabic, defaultCurrency)
            2 -> StandardsAndProductionTab(state, viewModel, isArabic, currentPeriod, defaultCurrency)
            3 -> WhatIfScenariosTab(state, viewModel, isArabic)
        }
    }
}

@Composable
private fun ProductCostingTab(
    state: FvgUiState,
    viewModel: FvgViewModel,
    isArabic: Boolean,
    defaultPeriod: String,
    defaultCurrency: String
) {
    var selectedProductId by remember { mutableStateOf("") }
    var productName by remember { mutableStateOf("") }
    var period by remember { mutableStateOf(defaultPeriod) }
    var method by remember { mutableStateOf("actual") }
    var directMat by remember { mutableStateOf("0") }
    var indirectMat by remember { mutableStateOf("0") }
    var directLab by remember { mutableStateOf("0") }
    var indirectLab by remember { mutableStateOf("0") }
    var overhead by remember { mutableStateOf("0") }
    var energyFuel by remember { mutableStateOf("0") }
    var packaging by remember { mutableStateOf("0") }
    var transport by remember { mutableStateOf("0") }
    var wasteScrap by remember { mutableStateOf("0") }
    var fixedCosts by remember { mutableStateOf("0") }
    var goodUnits by remember { mutableStateOf("100") }
    var sellingPrice by remember { mutableStateOf("0") }

    var targetPct by remember { mutableStateOf("25") }
    var abcPool by remember { mutableStateOf("1000") }
    var abcTotalDriver by remember { mutableStateOf("100") }
    var abcSelectedDriver by remember { mutableStateOf("25") }

    val liveInput = remember(
        directMat, indirectMat, directLab, indirectLab, overhead, energyFuel,
        packaging, transport, wasteScrap, fixedCosts, goodUnits, sellingPrice
    ) {
        runCatching {
            FvgFinancialEngine.CostingInput(
                directMaterial = FvgFinancialEngine.dOrZero(directMat),
                indirectMaterial = FvgFinancialEngine.dOrZero(indirectMat),
                directLabor = FvgFinancialEngine.dOrZero(directLab),
                indirectLabor = FvgFinancialEngine.dOrZero(indirectLab),
                overhead = FvgFinancialEngine.dOrZero(overhead),
                energyFuel = FvgFinancialEngine.dOrZero(energyFuel),
                packaging = FvgFinancialEngine.dOrZero(packaging),
                transport = FvgFinancialEngine.dOrZero(transport),
                wasteScrap = FvgFinancialEngine.dOrZero(wasteScrap),
                fixedCosts = FvgFinancialEngine.dOrZero(fixedCosts),
                goodUnits = FvgFinancialEngine.d(goodUnits),
                sellingPrice = FvgFinancialEngine.dOrZero(sellingPrice)
            )
        }.getOrNull()
    }
    val liveResult = remember(liveInput) {
        liveInput?.let { runCatching { FvgFinancialEngine.calculateCosting(it) }.getOrNull() }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            FvgCard {
                Text(
                    text = if (isArabic) "حاسبة التكلفة والتسعير ونقطة التعادل" else "Product Cost & Pricing Calculator",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                if (state.products.isNotEmpty()) {
                    FvgChipSelector(
                        options = state.products.map { it.id },
                        selected = selectedProductId,
                        onSelect = { id ->
                            selectedProductId = id
                            state.products.firstOrNull { it.id == id }?.let { productName = it.name }
                        },
                        labelResolver = { id -> state.products.firstOrNull { it.id == id }?.name ?: id }
                    )
                }
                FvgField(productName, { productName = it }, if (isArabic) "اسم المنتج" else "Product Name", testTag = "costing_product_name_input")
                FvgChipSelector(
                    options = listOf("actual", "standard", "target", "abc"),
                    selected = method,
                    onSelect = { method = it }
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(directMat, { directMat = it }, "Direct Material", numeric = true, modifier = Modifier.weight(1f), testTag = "costing_direct_mat_input")
                    FvgField(indirectMat, { indirectMat = it }, "Indirect Material", numeric = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(directLab, { directLab = it }, "Direct Labor", numeric = true, modifier = Modifier.weight(1f))
                    FvgField(indirectLab, { indirectLab = it }, "Indirect Labor", numeric = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(overhead, { overhead = it }, "Overhead", numeric = true, modifier = Modifier.weight(1f))
                    FvgField(energyFuel, { energyFuel = it }, "Energy & Fuel", numeric = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(packaging, { packaging = it }, "Packaging", numeric = true, modifier = Modifier.weight(1f))
                    FvgField(transport, { transport = it }, "Transport", numeric = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(wasteScrap, { wasteScrap = it }, "Waste / Scrap", numeric = true, modifier = Modifier.weight(1f))
                    FvgField(fixedCosts, { fixedCosts = it }, "Fixed Costs", numeric = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(goodUnits, { goodUnits = it }, "Good Units", numeric = true, modifier = Modifier.weight(1f), testTag = "costing_units_input")
                    FvgField(sellingPrice, { sellingPrice = it }, "Selling Price / Unit", numeric = true, modifier = Modifier.weight(1f), testTag = "costing_price_input")
                }

                if (liveResult != null) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = FvgSoftCream,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isArabic) "التكلفة الإجمالية" else "Total Cost", fontWeight = FontWeight.Bold, color = FvgDeepGreen)
                                Text("${liveResult.totalCost} $defaultCurrency", fontWeight = FontWeight.Bold, color = FvgDeepGreen)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isArabic) "تكلفة الوحدة الواحدة" else "Unit Cost", color = FvgInkDark)
                                Text("${liveResult.unitCost} $defaultCurrency", fontWeight = FontWeight.SemiBold, color = FvgForestGreen)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isArabic) "هامش الربح (Margin %)" else "Profit Margin % (of Price)", color = FvgInkDark)
                                Text("${liveResult.profitMarginPct ?: "N/A"}%", fontWeight = FontWeight.SemiBold)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isArabic) "نسبة الإضافة (Markup %)" else "Markup % (of Cost)", color = FvgInkDark)
                                Text("${liveResult.markupPct ?: "N/A"}%", fontWeight = FontWeight.SemiBold)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isArabic) "نقطة التعادل (وحدات CEILING)" else "Break-Even (CEILING Units)", color = FvgInkDark)
                                Text("${liveResult.breakEvenUnits ?: "N/A"} units", fontWeight = FontWeight.SemiBold)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isArabic) "صافي الربح" else "Net Profit", fontWeight = FontWeight.Bold, color = FvgDeepGreen)
                                Text(
                                    "${liveResult.netProfit} $defaultCurrency",
                                    fontWeight = FontWeight.Bold,
                                    color = if (liveResult.netProfit.signum() < 0) FvgNegative else FvgPositive
                                )
                            }
                        }
                    }
                }

                FvgPrimaryButton(
                    text = if (isArabic) "حفظ حساب التكلفة" else "Save Calculation",
                    icon = Icons.Filled.Save,
                    enabled = state.canEditFinancialData && productName.isNotBlank() && liveInput != null && !state.isBusy,
                    onClick = {
                        liveInput?.let {
                            viewModel.saveCosting(selectedProductId, productName, period, defaultCurrency, method, it)
                        }
                    },
                    testTag = "save_costing_button"
                )
            }
        }

        // Target Pricing & ABC Cost Allocator Helpers
        item {
            FvgCard {
                Text(
                    text = if (isArabic) "التسعير المستهدف وتوزيع التكاليف ABC" else "Target Pricing (Margin vs Markup) & ABC Allocator",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                FvgField(targetPct, { targetPct = it }, "Target Profit %", numeric = true)
                if (liveResult != null) {
                    val pPct = runCatching { FvgFinancialEngine.d(targetPct) }.getOrNull()
                    if (pPct != null) {
                        val byMargin = runCatching { FvgFinancialEngine.targetPriceByMargin(liveResult.unitCost, pPct).toPlainString() }.getOrElse { "Invalid <100%" }
                        val byMarkup = runCatching { FvgFinancialEngine.targetPriceByMarkup(liveResult.unitCost, pPct).toPlainString() }.getOrElse { "N/A" }
                        Text("At $targetPct% Margin -> Sell at $byMargin | At $targetPct% Markup -> Sell at $byMarkup", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    }
                }
                HorizontalDivider()
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(abcPool, { abcPool = it }, "ABC Pool", numeric = true, modifier = Modifier.weight(1f))
                    FvgField(abcTotalDriver, { abcTotalDriver = it }, "Total Driver", numeric = true, modifier = Modifier.weight(1f))
                    FvgField(abcSelectedDriver, { abcSelectedDriver = it }, "Product Driver", numeric = true, modifier = Modifier.weight(1f))
                }
                val abcShare = runCatching {
                    FvgFinancialEngine.allocateAbcCost(
                        FvgFinancialEngine.d(abcPool),
                        listOf(FvgFinancialEngine.d(abcTotalDriver)),
                        FvgFinancialEngine.d(abcSelectedDriver)
                    )
                }.getOrNull()
                Text("Allocated ABC Overhead: ${abcShare ?: "Invalid driver"} $defaultCurrency", style = MaterialTheme.typography.bodyMedium)
            }
        }

        items(state.costSnapshots, key = { it.id }) { snap ->
            FvgCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${snap.productName} (${snap.period})", style = MaterialTheme.typography.titleMedium)
                    FvgRoleBadge(snap.costingMethod)
                }
                Text(
                    "Unit Cost: ${snap.unitCost} | Price: ${snap.sellingPrice} | Margin: ${snap.profitMarginPct}% | Markup: ${snap.markupPct}%",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "Break-Even: ${snap.breakEvenUnits} units | Total Net Profit: ${snap.netProfit} ${snap.currency}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun CvpAndProfitabilityTab(
    state: FvgUiState,
    isArabic: Boolean,
    currency: String
) {
    var mode by remember { mutableStateOf("cvp") } // "cvp" | "profitability"
    var selectedSnap by remember(state.costSnapshots) { mutableStateOf<CostSnapshot?>(state.costSnapshots.firstOrNull()) }

    val volatility = remember(state.costSnapshots) {
        val unitCosts = state.costSnapshots.mapNotNull { runCatching { FvgFinancialEngine.d(it.unitCost) }.getOrNull() }
        FvgFinancialEngine.computeCostVolatility(unitCosts)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            FvgChipSelector(
                options = listOf("cvp", "profitability"),
                selected = mode,
                onSelect = { mode = it },
                labelResolver = {
                    if (it == "cvp") (if (isArabic) "تحليل التعادل CVP" else "CVP Analysis")
                    else (if (isArabic) "الربحية والتقلب" else "Profitability & Volatility")
                }
            )
        }

        if (state.costSnapshots.isEmpty()) {
            item {
                FvgEmptyStateCard(
                    if (isArabic) "احفظ لقطة تكلفة في التبويب الأول لعرض منحنى التعادل والتقلب التاريخي."
                    else "Save at least one Cost Calculation in Product Costing to render CVP curve, Margin of Safety, and Volatility."
                )
            }
        } else {
            item {
                FvgCard {
                    Text(if (isArabic) "اختر لقطة التكلفة للتحليل" else "Select Cost Snapshot", style = MaterialTheme.typography.labelLarge)
                    FvgChipSelector(
                        options = state.costSnapshots.map { it.id },
                        selected = selectedSnap?.id ?: "",
                        onSelect = { id -> selectedSnap = state.costSnapshots.firstOrNull { it.id == id } },
                        labelResolver = { id -> state.costSnapshots.firstOrNull { it.id == id }?.let { "${it.productName} (${it.period})" } ?: id }
                    )

                    selectedSnap?.let { snap ->
                        val goodUnits = FvgFinancialEngine.dOrZero(snap.goodUnits).max(BigDecimal.ONE)
                        val fixed = FvgFinancialEngine.dOrZero(snap.fixedCosts)
                        val totCost = FvgFinancialEngine.dOrZero(snap.totalCost)
                        val varTotal = totCost.subtract(fixed).max(BigDecimal.ZERO)
                        val varUnit = varTotal.divide(goodUnits, FvgFinancialEngine.MC)
                        val price = FvgFinancialEngine.dOrZero(snap.sellingPrice)
                        val beUnits = snap.breakEvenUnits.toFloatOrNull()
                        val maxUnits = (beUnits?.let { BigDecimal(it.toDouble() * 1.8) } ?: goodUnits).max(goodUnits)

                        if (mode == "cvp") {
                            Surface(shape = RoundedCornerShape(16.dp), color = FvgSoftCream, modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(if (isArabic) "نقطة التعادل" else "Break-Even Point", style = MaterialTheme.typography.labelLarge, color = FvgMutedForest)
                                    Text(
                                        text = "${snap.breakEvenUnits} units",
                                        style = MaterialTheme.typography.headlineMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = FvgDeepGreen
                                    )
                                }
                            }
                            val curve = FvgFinancialEngine.generateCvpCurvePoints(fixed, varUnit, price, maxUnits)
                            FvgCvpChartCanvas(cvpPoints = curve, breakEvenUnits = beUnits)

                            val contribMarginPct = if (price > BigDecimal.ZERO) {
                                FvgFinancialEngine.pct4(price.subtract(varUnit).divide(price, FvgFinancialEngine.MC).multiply(BigDecimal(100))).toPlainString()
                            } else "N/A"
                            val mosPct = if (beUnits != null && goodUnits.toFloat() > 0f) {
                                val mos = ((goodUnits.toFloat() - beUnits) / goodUnits.toFloat()) * 100f
                                String.format("%.2f", mos)
                            } else "N/A"

                            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(if (isArabic) "مؤشرات الأمان والهامش" else "Key CVP Metrics", style = MaterialTheme.typography.titleMedium)
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Contribution Margin %")
                                        Text("$contribMarginPct%", fontWeight = FontWeight.Bold, color = FvgForestGreen)
                                    }
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Margin of Safety %")
                                        Text("$mosPct%", fontWeight = FontWeight.Bold, color = FvgDeepGreen)
                                    }
                                }
                            }
                        } else {
                            // Profitability & Historical Unit Cost Trend
                            val trendPts = state.costSnapshots.takeLast(8).mapNotNull { cs ->
                                cs.unitCost.toFloatOrNull()?.let { cs.period to it }
                            }
                            if (trendPts.size >= 2) {
                                Text(if (isArabic) "تطور تكلفة الوحدة" else "Historical Unit Cost Trend", style = MaterialTheme.typography.titleMedium)
                                FvgSplineLineChartCanvas(points = trendPts)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Gross Profit")
                                Text("${snap.grossProfit} $currency", fontWeight = FontWeight.Bold)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Net Profit")
                                Text("${snap.netProfit} $currency", fontWeight = FontWeight.Bold, color = FvgForestGreen)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Profit Margin % vs Markup %")
                                Text("${snap.profitMarginPct}% / ${snap.markupPct}%", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            if (volatility != null) {
                item {
                    FvgCard(containerColor = FvgSoftCream) {
                        Text(if (isArabic) "تقلب تكلفة الوحدة (Cost Volatility)" else "Unit Cost Volatility Index", style = MaterialTheme.typography.titleMedium, color = FvgDeepGreen)
                        Text(
                            text = "Snapshots: ${volatility.count} | Min: ${volatility.minCost} | Max: ${volatility.maxCost} | Mean: ${volatility.meanCost} $currency",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Spread: ${volatility.spreadPct}% | StdDev: ${volatility.stdDev} $currency",
                            style = MaterialTheme.typography.labelLarge,
                            color = FvgAntiqueGold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StandardsAndProductionTab(
    state: FvgUiState,
    viewModel: FvgViewModel,
    isArabic: Boolean,
    currentPeriod: String,
    defaultCurrency: String
) {
    // Standard Cost Sheet form
    var stdProductName by remember { mutableStateOf("") }
    var stdMat by remember { mutableStateOf("10.00") }
    var stdHrs by remember { mutableStateOf("1.5") }
    var stdRate by remember { mutableStateOf("6.00") }
    var stdOvh by remember { mutableStateOf("4.00") }
    var stdNotes by remember { mutableStateOf("Baseline standard recipe") }

    // Production Order form
    var poProductName by remember { mutableStateOf("") }
    var poPeriod by remember { mutableStateOf(currentPeriod) }
    var poPlanned by remember { mutableStateOf("100") }
    var poGood by remember { mutableStateOf("95") }
    var poScrap by remember { mutableStateOf("5") }
    var poActMat by remember { mutableStateOf("1050") }
    var poActLab by remember { mutableStateOf("890") }
    var poActOvh by remember { mutableStateOf("390") }

    var selectedStd by remember(state.standardCosts) { mutableStateOf<StandardCostSheet?>(state.standardCosts.firstOrNull()) }
    var selectedPo by remember(state.productionOrders) { mutableStateOf<ProductionOrderRecord?>(state.productionOrders.firstOrNull()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            FvgCard {
                Text(if (isArabic) "التكلفة المعيارية للمنتج (Standard Costing)" else "Standard Cost Sheet (Versioned)", style = MaterialTheme.typography.titleMedium)
                FvgField(stdProductName, { stdProductName = it }, "Product Name", testTag = "std_product_input")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(stdMat, { stdMat = it }, "Std Material/Unit", numeric = true, modifier = Modifier.weight(1f))
                    FvgField(stdOvh, { stdOvh = it }, "Std Overhead/Unit", numeric = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(stdHrs, { stdHrs = it }, "Std Labor Hrs", numeric = true, modifier = Modifier.weight(1f))
                    FvgField(stdRate, { stdRate = it }, "Std Labor Rate", numeric = true, modifier = Modifier.weight(1f))
                }
                FvgField(stdNotes, { stdNotes = it }, "Engineering Notes")
                FvgPrimaryButton(
                    text = if (isArabic) "حفظ بطاقة التكلفة المعيارية" else "Save Standard Cost Sheet",
                    icon = Icons.Filled.Save,
                    enabled = state.canEditFinancialData && stdProductName.isNotBlank() && !state.isBusy,
                    onClick = {
                        viewModel.createStandardCost("", stdProductName, stdMat, stdHrs, stdRate, stdOvh, stdNotes)
                        poProductName = stdProductName
                    },
                    testTag = "save_standard_cost_button"
                )
            }
        }

        item {
            FvgCard {
                Text(if (isArabic) "أمر الإنتاج والمراحل والهدر الفعلي" else "Production Order & Multi-Stage Tracking", style = MaterialTheme.typography.titleMedium)
                FvgField(poProductName, { poProductName = it }, "Product Name", testTag = "po_product_input")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(poPeriod, { poPeriod = it }, "Period", modifier = Modifier.weight(0.9f))
                    FvgField(poPlanned, { poPlanned = it }, "Planned Units", numeric = true, modifier = Modifier.weight(1f))
                    FvgField(poGood, { poGood = it }, "Good Units", numeric = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(poScrap, { poScrap = it }, "Scrap Units", numeric = true, modifier = Modifier.weight(0.9f))
                    FvgField(poActMat, { poActMat = it }, "Actual Material", numeric = true, modifier = Modifier.weight(1.1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FvgField(poActLab, { poActLab = it }, "Actual Labor", numeric = true, modifier = Modifier.weight(1f))
                    FvgField(poActOvh, { poActOvh = it }, "Actual Overhead", numeric = true, modifier = Modifier.weight(1f))
                }
                FvgGoldButton(
                    text = if (isArabic) "تسجيل أمر إنتاج" else "Create Production Order",
                    icon = Icons.Filled.Factory,
                    enabled = state.canEditFinancialData && poProductName.isNotBlank() && !state.isBusy,
                    onClick = {
                        viewModel.createProductionOrder("", poProductName, poPeriod, poPlanned, poGood, poScrap, poActMat, poActLab, poActOvh)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "create_po_button"
                )
            }
        }

        // Standard vs Actual Cost Variance + Yield & Scrap Sensitivity
        if (selectedStd != null && selectedPo != null) {
            item {
                val stdSheet = selectedStd!!
                val po = selectedPo!!
                val variance = FvgFinancialEngine.computeCostVariance(
                    stdMaterialPerUnit = FvgFinancialEngine.dOrZero(stdSheet.standardMaterialCost),
                    stdLaborHoursPerUnit = FvgFinancialEngine.dOrZero(stdSheet.standardLaborHours),
                    stdLaborRate = FvgFinancialEngine.dOrZero(stdSheet.standardLaborRate),
                    stdOverheadPerUnit = FvgFinancialEngine.dOrZero(stdSheet.standardOverheadPerUnit),
                    goodUnits = FvgFinancialEngine.d(po.goodUnits),
                    actualMaterialCost = FvgFinancialEngine.dOrZero(po.actualMaterialCost),
                    actualLaborCost = FvgFinancialEngine.dOrZero(po.actualLaborCost),
                    actualOverheadCost = FvgFinancialEngine.dOrZero(po.actualOverheadCost)
                )
                val yieldRes = FvgFinancialEngine.computeScrapYieldAnalysis(
                    plannedUnits = FvgFinancialEngine.d(po.plannedUnits),
                    goodUnits = FvgFinancialEngine.d(po.goodUnits),
                    recordedScrapUnits = FvgFinancialEngine.dOrZero(po.scrapUnits),
                    totalCost = FvgFinancialEngine.dOrZero(po.actualTotalCost)
                )
                FvgCard(containerColor = FvgSoftCream) {
                    Text(if (isArabic) "تحليل انحراف التكاليف وكفاءة الهدر" else "Standard vs Actual Variance & Yield Analysis", style = MaterialTheme.typography.titleMedium, color = FvgDeepGreen)
                    Text("Standard Total Allowed: ${variance.standardTotalAllowed} $defaultCurrency", style = MaterialTheme.typography.bodyMedium)
                    Text("Material Variance: ${variance.materialVariance ?: "N/A"} | Labor: ${variance.laborVariance ?: "N/A"} | Overhead: ${variance.overheadVariance ?: "N/A"}", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = "Total Cost Variance: ${variance.totalVariance ?: "Incomplete"} $defaultCurrency",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if ((variance.totalVariance ?: BigDecimal.ZERO) > BigDecimal.ZERO) FvgNegative else FvgPositive
                    )
                    HorizontalDivider()
                    Text("Yield: ${yieldRes.yieldPct}% | Scrap Rate: ${yieldRes.scrapRatePct}% (${yieldRes.recordedScrapUnits} units)", style = MaterialTheme.typography.bodyMedium)
                    Text("Unit Cost (Good): ${yieldRes.currentCostPerGoodUnit} | Indicative After Scrap: ${yieldRes.indicativeCostAfterScrap} $defaultCurrency", style = MaterialTheme.typography.labelLarge, color = FvgForestGreen)
                }
            }
        }

        items(state.productionOrders, key = { it.id }) { po ->
            FvgCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${po.productName} (${po.period})", style = MaterialTheme.typography.titleMedium)
                    FvgRoleBadge(po.status)
                }
                Text("Planned: ${po.plannedUnits} | Good: ${po.goodUnits} | Scrap: ${po.scrapUnits} | Actual Total: ${po.actualTotalCost} ${po.currency}", style = MaterialTheme.typography.bodyMedium)
                if (po.status == "in_progress" && state.canEditFinancialData) {
                    OutlinedButton(
                        onClick = {
                            viewModel.completeProductionOrder(po, po.scrapUnits, po.actualMaterialCost, po.actualLaborCost, po.actualOverheadCost)
                        },
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (isArabic) "إتمام مراحل الإنتاج" else "Complete Stages")
                    }
                }
            }
        }

        items(state.standardCosts, key = { it.id }) { std ->
            FvgCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${std.productName} Standard v${std.version}", style = MaterialTheme.typography.titleMedium)
                    FvgRoleBadge("${std.standardUnitCost} ${std.currency}")
                }
                Text("Mat: ${std.standardMaterialCost} | Lab: ${std.standardLaborHours}h × ${std.standardLaborRate} | Ovh: ${std.standardOverheadPerUnit}", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun WhatIfScenariosTab(
    state: FvgUiState,
    viewModel: FvgViewModel,
    isArabic: Boolean
) {
    var selectedSnap by remember(state.costSnapshots) { mutableStateOf<CostSnapshot?>(state.costSnapshots.firstOrNull()) }
    var scenName by remember { mutableStateOf("Raw Material +15% Inflation Stress") }
    var matPct by remember { mutableStateOf("15") }
    var labPct by remember { mutableStateOf("5") }
    var ovhPct by remember { mutableStateOf("10") }
    var pricePct by remember { mutableStateOf("8") }

    val previewScenario = remember(selectedSnap, matPct, labPct, ovhPct, pricePct) {
        selectedSnap?.let { snap ->
            runCatching {
                val baseMat = FvgFinancialEngine.dOrZero(snap.directMaterial).add(FvgFinancialEngine.dOrZero(snap.indirectMaterial))
                val baseLab = FvgFinancialEngine.dOrZero(snap.directLabor).add(FvgFinancialEngine.dOrZero(snap.indirectLabor))
                val baseOther = FvgFinancialEngine.dOrZero(snap.totalCost).subtract(baseMat).subtract(baseLab).max(BigDecimal.ZERO)
                FvgFinancialEngine.runScenario(
                    baseMat, baseLab, baseOther, FvgFinancialEngine.dOrZero(snap.revenue),
                    FvgFinancialEngine.dOrZero(matPct), FvgFinancialEngine.dOrZero(labPct),
                    FvgFinancialEngine.dOrZero(ovhPct), FvgFinancialEngine.dOrZero(pricePct)
                )
            }.getOrNull()
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (state.scenarios.isNotEmpty() && selectedSnap != null) {
            item {
                val baseP = FvgFinancialEngine.dOrZero(selectedSnap!!.netProfit).toFloat()
                val s2 = state.scenarios.getOrNull(0)?.scenarioProfit?.toFloatOrNull() ?: baseP
                val s3 = state.scenarios.getOrNull(1)?.scenarioProfit?.toFloatOrNull() ?: previewScenario?.scenarioProfit?.toFloat() ?: baseP
                FvgCard(containerColor = FvgSoftCream) {
                    Text(if (isArabic) "مقارنة السيناريو 1 (الحالي) مقابل 2 و 3" else "Scenario 1 (Current) vs Scenario 2 vs Scenario 3", style = MaterialTheme.typography.titleMedium, color = FvgDeepGreen)
                    FvgBarComparisonCanvas(
                        bars = listOf("S1 Current" to baseP, "S2 Saved" to s2, "S3 Alt" to s3)
                    )
                }
            }
        }

        item {
            if (state.costSnapshots.isEmpty()) {
                FvgEmptyStateCard(
                    if (isArabic) "احفظ لقطة تكلفة أولاً في تبويب حاسبة التكلفة لتشغيل محاكاة ماذا لو."
                    else "Save a Product Cost Snapshot first to simulate non-destructive What-If pricing scenarios."
                )
            } else {
                FvgCard {
                    Text(
                        text = if (isArabic) "محاكاة ماذا لو (دون المساس بالسجلات)" else "Non-Destructive What-If Scenario Simulator",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    FvgChipSelector(
                        options = state.costSnapshots.map { it.id },
                        selected = selectedSnap?.id ?: "",
                        onSelect = { id -> selectedSnap = state.costSnapshots.firstOrNull { it.id == id } },
                        labelResolver = { id -> state.costSnapshots.firstOrNull { it.id == id }?.productName ?: id }
                    )
                    FvgField(scenName, { scenName = it }, "Scenario Name")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FvgField(matPct, { matPct = it }, "Material Δ %", numeric = true, modifier = Modifier.weight(1f))
                        FvgField(labPct, { labPct = it }, "Labor Δ %", numeric = true, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FvgField(ovhPct, { ovhPct = it }, "Overhead Δ %", numeric = true, modifier = Modifier.weight(1f))
                        FvgField(pricePct, { pricePct = it }, "Selling Price Δ %", numeric = true, modifier = Modifier.weight(1f))
                    }
                    if (previewScenario != null) {
                        FvgBarComparisonCanvas(
                            bars = listOf(
                                "Base Cost" to previewScenario.baseTotalCost.toFloat(),
                                "Scen. Cost" to previewScenario.scenarioTotalCost.toFloat(),
                                "Base Profit" to previewScenario.baseProfit.toFloat(),
                                "Scen. Profit" to previewScenario.scenarioProfit.toFloat()
                            )
                        )
                        Text(
                            text = "Profit Impact: ${previewScenario.profitDelta} (Cost Δ: ${previewScenario.costDelta})",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (previewScenario.profitDelta.signum() < 0) FvgNegative else FvgPositive
                        )
                    }
                    FvgGoldButton(
                        text = if (isArabic) "حفظ السيناريو" else "Save What-If Scenario",
                        enabled = state.canEditFinancialData && selectedSnap != null && scenName.isNotBlank() && !state.isBusy,
                        onClick = {
                            selectedSnap?.let { viewModel.saveScenario(it, scenName, matPct, labPct, ovhPct, pricePct) }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        items(state.scenarios, key = { it.id }) { scn ->
            FvgCard {
                Text(scn.name, style = MaterialTheme.typography.titleMedium)
                Text(
                    "Inputs: Mat ${scn.materialChangePct}% | Lab ${scn.laborChangePct}% | Ovh ${scn.overheadChangePct}% | Price ${scn.priceChangePct}%",
                    style = MaterialTheme.typography.labelSmall
                )
                Text(
                    "Base Profit: ${scn.baseProfit} -> Scenario Profit: ${scn.scenarioProfit}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = FvgDeepGreen
                )
            }
        }
    }
}
