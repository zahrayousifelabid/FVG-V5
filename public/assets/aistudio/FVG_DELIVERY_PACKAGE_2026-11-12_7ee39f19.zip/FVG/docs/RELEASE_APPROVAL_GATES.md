# FVG release approval gates

**Status: NOT APPROVED FOR PRODUCTION RELEASE**

This checklist prevents a development archive from being mistaken for a final approved product. A release may be labelled approved only after each applicable gate is evidenced by executed tests, reviewed configuration, and authorized sign-off.

## Current evidence
- Backend automated suite: 63 passed on 2026-11-12 (rerun for this package).
- Backend Python syntax compilation: passed.
- Latest frontend TSX syntax transpilation: 0 diagnostics; this is not a full TypeScript type-check or bundle build.
- Frontend dependency installation timed out; no frontend production build or browser execution is verified.
- No production database, live deployment, external service credentials, payment provider, email delivery, or FX provider is configured.

## Mandatory gates still open
1. Install and lock frontend dependencies; run full TypeScript type-check and Vite production build.
2. Add browser E2E tests for registration/login, tenant switching, product/material setup, BOM, costing, production order, stage transitions, labor/machine hours, variance display, reports and logout.
3. Complete missing frontend workflows: stage material consumption and scrap, WIP, finished-goods receipts/issues/valuation, stocktakes, inventory valuation, research modules and import/export history.
4. Correct and validate financial workflows against approved accounting policies, including period matching, standards effective dates pinned to orders, overhead fixed/variable decomposition, currency/FX snapshots, and complete inventory lifecycle.
5. Complete authentication recovery/email verification, RBAC administration, rate limiting, CSRF/session policy, security headers, upload controls, secrets management and independent security review.
6. Implement versioned database migrations and select/configure a production-grade database; test tenant isolation under concurrent requests.
7. Execute backup and restore drill, rollback rehearsal, retention/deletion review, and disaster recovery validation.
8. Complete accessibility, Arabic RTL, English LTR, responsive, keyboard, screen-reader and cross-browser tests.
9. Complete full Research Workspace instruments, consent/privacy controls, data cleaning/coding and evidence-based exports; do not publish unverified findings.
10. Configure only authorized external integrations and verify their credentials, permissions, failure modes and audit logs.
11. Obtain product-owner approval and independent technical/accounting sign-off; deploy to a controlled staging environment, validate it, then authorize production release.

## Release rule
Until every mandatory gate is closed and evidenced, identify the artifact as a **development increment**. Do not call it final, approved, secure, production-ready, deployed, or complete.

## Additional evidence — 2026-11-11 Research Workspace increment
- Added bilingual frontend workflows for pseudonymous establishments, permission metadata, interaction metadata, hypotheses, data dictionary and evidence listing.
- Added same-tenant evidence-reference validation for hypothesis creation and audit logging for data dictionary records.
- Backend suite now: 61 passed; Python compilation passed; TSX syntax transpilation: 0 diagnostics.
- `npm install` failed with `EAI_AGAIN` resolving npm registry. Full type-check/build and browser testing remain open.


## Additional evidence — 2026-11-12 Guided research capture
- Instrument authoring now provides a visual schema builder for question keys, supported field types, required flags, and allowed category values.
- Response entry is generated from the selected active instrument schema; required values are checked before submission. Raw responses remain preserved and cleaning logs remain separate.
- Backend suite rerun: 63 passed in 4.05s; `python -m py_compile app/*.py` passed; TSX syntax transpilation reported 0 diagnostics.
- ZIP integrity and SHA-256 are recorded in the delivery message.
- These checks do not close the frontend build, browser, visual, security, deployment, or remaining functional gates.
