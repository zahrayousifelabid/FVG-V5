from fastapi import FastAPI, HTTPException, Depends, Header
from contextlib import asynccontextmanager
from pydantic import BaseModel, Field, EmailStr, ConfigDict
from typing import Literal
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import uuid, json, os, base64, binascii
from . import engine
from .storage import connect, initialize
from .security import hash_password, verify_password, issue_session, authenticate

@asynccontextmanager
async def lifespan(app):
    initialize()
    yield

app=FastAPI(title='Financial Vision Guide API',version='0.2.0',description='FVG deterministic costing, tenant-scoped records, and research evidence API',lifespan=lifespan)

def now(): return datetime.now(timezone.utc).isoformat()
def uid(): return str(uuid.uuid4())
def user_id(authorization:str|None=Header(default=None)):
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'Authentication required')
    found=authenticate(authorization[7:])
    if not found: raise HTTPException(401,'Invalid or expired session')
    return found

def org_access(org_id:str, user:str, write=False):
    with connect() as c: row=c.execute('SELECT role FROM memberships WHERE org_id=? AND user_id=?',(org_id,user)).fetchone()
    if not row: raise HTTPException(404,'Organization not found')
    if write and row['role']=='viewer': raise HTTPException(403,'Read-only membership')
    return row['role']

def require_active_subscription(org_id:str):
    with connect() as c: sub=c.execute('SELECT status,trial_ends_at FROM subscriptions WHERE org_id=?',(org_id,)).fetchone()
    if not sub: raise HTTPException(402,'No subscription record')
    if sub['status']=='trial' and datetime.fromisoformat(sub['trial_ends_at'])<=datetime.now(timezone.utc):
        raise HTTPException(402,'The 72-hour trial has expired. Contact the administrator for subscription review.')
    if sub['status'] not in ('trial','active'):
        raise HTTPException(402,'An active subscription is required')

class Register(BaseModel):
    email:str=Field(min_length=5,max_length=254)
    password:str=Field(min_length=12,max_length=256)
    organization_name:str=Field(min_length=2,max_length=160)
class Login(BaseModel): email:str; password:str
class OrganizationIn(BaseModel): name:str=Field(min_length=2,max_length=160); currency:str=Field(default='SDG',min_length=3,max_length=3)
class ProductIn(BaseModel): name:str=Field(min_length=1,max_length=180); sku:str|None=None; unit:str=Field(min_length=1,max_length=30); currency:str=Field(default='SDG',min_length=3,max_length=3)
class ProductImportRow(BaseModel):
    name:str=Field(min_length=1,max_length=180)
    sku:str|None=None
    unit:str=Field(min_length=1,max_length=30)
    currency:str=Field(default='SDG',min_length=3,max_length=3)
class ProductImportCommit(BaseModel): rows:list[ProductImportRow]=Field(min_length=1,max_length=500)
class ProductImportPreview(BaseModel): csv_text:str=Field(min_length=1,max_length=2_000_000)
class ProductXlsxImportPreview(BaseModel): xlsx_base64:str=Field(min_length=1,max_length=3_000_000)
class CostingIn(BaseModel): product_id:str; period:str=Field(min_length=4,max_length=30); currency:str=Field(min_length=3,max_length=3); components:dict[str,float]; good_saleable_units:float=Field(gt=0); selling_price:float=Field(ge=0)
class ScenarioIn(BaseModel): snapshot_id:str; name:str=Field(min_length=1,max_length=120); changes:dict[str,float]
class AllocationIn(BaseModel):
    pool_name:str=Field(min_length=1,max_length=160); pool_cost:float=Field(ge=0); basis:str=Field(min_length=1,max_length=120); driver:str=Field(min_length=1,max_length=120); period:str=Field(min_length=4,max_length=30); driver_quantities:list[float]=Field(min_length=1); selected_driver_quantity:float=Field(ge=0); source_quantities:dict[str,float]; assumptions:str='';
class UnitConversionIn(BaseModel): quantity:float=Field(ge=0); from_unit:str; to_unit:str; conversions:dict[str,float]
class RawMaterialIn(BaseModel):
    name:str=Field(min_length=1,max_length=180)
    sku:str|None=None
    unit:str=Field(min_length=1,max_length=30)
    currency:str=Field(default='SDG',min_length=3,max_length=3)
    unit_cost:float=Field(ge=0)

class BOMItemIn(BaseModel):
    material_id:str
    quantity_per_unit:float=Field(gt=0)
    waste_rate:float=Field(default=0,ge=0,lt=1)

class InventoryMovementIn(BaseModel):
    material_id:str
    movement_type:Literal['receipt','issue','adjustment']
    quantity:float=Field(gt=0)
    unit:str=Field(min_length=1,max_length=30)
    unit_cost:float=Field(ge=0)
    reference:str=Field(min_length=1,max_length=160)

class MaterialStocktakeIn(BaseModel):
    material_id:str
    counted_quantity:float=Field(ge=0)
    unit:str=Field(min_length=1,max_length=30)
    unit_cost:float=Field(ge=0, description='Required valuation for any positive stocktake difference')
    reference:str=Field(min_length=3,max_length=160)
    notes:str=Field(default='',max_length=1000)

class FinishedGoodsStocktakeIn(BaseModel):
    product_id:str
    counted_quantity:float=Field(ge=0)
    unit:str=Field(min_length=1,max_length=30)
    unit_cost:float=Field(ge=0, description='Required valuation for any positive stocktake difference')
    currency:str=Field(min_length=3,max_length=3)
    reference:str=Field(min_length=3,max_length=160)
    notes:str=Field(default='',max_length=1000)

class ProductionOrderIn(BaseModel):
    product_id:str
    planned_units:float=Field(gt=0)
    good_units:float=Field(gt=0)
    period:str=Field(min_length=4,max_length=30)
    currency:str=Field(min_length=3,max_length=3)
    conversion_cost:float=Field(default=0,ge=0)
    overhead_cost:float=Field(default=0,ge=0)

class ProductionStageIn(BaseModel):
    sequence_no:int=Field(ge=1)
    stage_name:str=Field(min_length=2,max_length=120)
    conversion_cost:float=Field(default=0,ge=0)
    overhead_cost:float=Field(default=0,ge=0)

class ProductionStageMaterialIn(BaseModel):
    material_id:str
    quantity:float=Field(gt=0)
    unit:str=Field(min_length=1,max_length=30)
    valuation_method:Literal['fifo','weighted_average']='weighted_average'
    reference:str=Field(min_length=3,max_length=160)

class ProductionStageScrapIn(BaseModel):
    scrap_units:float=Field(gt=0)
    unit:str=Field(min_length=1,max_length=30)
    reason:str=Field(min_length=3,max_length=300)
    occurred_on:str=Field(min_length=4,max_length=40)

class ProductionStageStatusIn(BaseModel):
    status:Literal['in_progress','completed']

class ProductionLaborIn(BaseModel):
    worker_code:str=Field(default='',max_length=80)
    work_description:str=Field(min_length=2,max_length=300)
    hours:float=Field(gt=0,le=1000)
    hourly_rate:float=Field(ge=0)
    currency:str=Field(min_length=3,max_length=3)
    occurred_on:str=Field(min_length=4,max_length=40)

class StandardMaterialCostIn(BaseModel):
    material_id:str
    quantity_per_good_unit:float=Field(gt=0)
    standard_unit_cost:float=Field(ge=0)

class ProductStandardCostIn(BaseModel):
    currency:str=Field(min_length=3,max_length=3)
    materials:list[StandardMaterialCostIn]=Field(min_length=1)
    labor_hours_per_good_unit:float=Field(default=0,ge=0)
    standard_labor_hourly_rate:float=Field(default=0,ge=0)
    overhead_per_good_unit:float=Field(default=0,ge=0)
    machine_hours_per_good_unit:float|None=Field(default=None,gt=0)
    budgeted_machine_hours:float|None=Field(default=None,gt=0)
    fixed_overhead_budget:float|None=Field(default=None,ge=0)

class ProductionMachineHoursIn(BaseModel):
    machine_code:str=Field(default='',max_length=80)
    description:str=Field(min_length=2,max_length=300)
    machine_hours:float=Field(gt=0,le=10000)
    occurred_on:str=Field(min_length=4,max_length=40)

class FinishedGoodsReceiptIn(BaseModel):
    quantity:float=Field(gt=0)
    reference:str=Field(min_length=1,max_length=160)

class FinishedGoodsMovementIn(BaseModel):
    product_id:str
    movement_type:Literal['issue','adjustment']
    quantity:float=Field(gt=0)
    unit:str=Field(min_length=1,max_length=30)
    unit_cost:float=Field(ge=0)
    currency:str=Field(min_length=3,max_length=3)
    reference:str=Field(min_length=1,max_length=160)

class EvidenceIn(BaseModel): title:str=Field(min_length=1,max_length=300); status:Literal['Verified Public Source','Researcher Observation','Field Data — Pending Collection','Field Data — Verified','Demo/Synthetic','Not Available']; source_ref:str|None=None; notes:str=''

class ResearchEstablishmentIn(BaseModel):
    pseudonym:str=Field(min_length=2,max_length=80); sector:str=Field(min_length=2,max_length=100); region:str=Field(default='',max_length=120)
    participation_status:Literal['proposed','contacted','approved','declined','withdrawn']='proposed'; notes:str=Field(default='',max_length=2000)
class ResearchPermissionIn(BaseModel):
    establishment_id:str; permission_type:Literal['site_access','interview','survey','records_review','photography','publication']
    permission_status:Literal['pending','granted','denied','withdrawn']='pending'; reference:str=Field(default='',max_length=200)
    valid_from:str=Field(default='',max_length=40); valid_until:str=Field(default='',max_length=40); notes:str=Field(default='',max_length=2000)
class ResearchInteractionIn(BaseModel):
    establishment_id:str; interaction_type:Literal['interview','survey','observation']; participant_code:str=Field(default='',max_length=80)
    occurred_on:str=Field(min_length=4,max_length=40); permission_id:str
    record_status:Literal['metadata_only','notes_pending_review','reviewed','excluded']='metadata_only'; notes:str=Field(default='',max_length=3000)
class ResearchHypothesisIn(BaseModel):
    statement:str=Field(min_length=8,max_length=1000); status:Literal['proposed','under_review']='proposed'
    evidence_refs:list[str]=Field(default_factory=list,max_length=30); notes:str=Field(default='',max_length=2000)
class ResearchHypothesisUpdate(BaseModel):
    status:Literal['proposed','under_review','supported','not_supported','inconclusive']; evidence_refs:list[str]=Field(default_factory=list,max_length=30); notes:str=Field(default='',max_length=2000)
class ResearchDictionaryIn(BaseModel):
    variable_name:str=Field(min_length=1,max_length=100); definition:str=Field(min_length=3,max_length=1000)
    data_type:Literal['text','integer','decimal','date','boolean','category']; unit:str=Field(default='',max_length=40)
    allowed_values:str=Field(default='',max_length=1000); sensitivity:Literal['non_personal','confidential_business','personal_data']='non_personal'

class ResearchInstrumentIn(BaseModel):
    title:str=Field(min_length=3,max_length=180)
    instrument_type:Literal['interview','survey']
    fields:list[dict]=Field(min_length=1,max_length=80)
    status:Literal['draft','active']='draft'
class ResearchResponseIn(BaseModel):
    instrument_id:str
    interaction_id:str
    response:dict
    review_status:Literal['pending_review','reviewed']='pending_review'
class ResearchCleaningIn(BaseModel):
    variable_name:str=Field(min_length=1,max_length=100)
    issue_type:Literal['missing','outlier','inconsistent','invalid_format','duplicate','other']
    action_taken:str=Field(min_length=3,max_length=500)
    outcome:Literal['flagged_only','corrected_in_analysis_copy','excluded_from_analysis','awaiting_review']
    reviewer_note:str=Field(default='',max_length=1000)

@app.get('/health')
def health(): return {'status':'ok','service':'fvg-api','version':app.version,'database':'sqlite'}

@app.post('/api/v1/auth/register',status_code=201)
def register(req:Register):
    email=req.email.strip().lower()
    if '@' not in email or '.' not in email.rsplit('@',1)[-1]: raise HTTPException(422,'Valid email required')
    uid_user,org=uid(),uid(); t=now(); end=(datetime.now(timezone.utc)+timedelta(hours=72)).isoformat()
    try:
        with connect() as c:
            c.execute('INSERT INTO users VALUES(?,?,?,?)',(uid_user,email,hash_password(req.password),t))
            c.execute('INSERT INTO organizations VALUES(?,?,?,?,?)',(org,req.organization_name,uid_user,'SDG',t))
            c.execute('INSERT INTO memberships VALUES(?,?,?)',(uid_user,org,'owner'))
            c.execute('INSERT INTO subscriptions VALUES(?,?,?,?,?)',(org,t,end,'trial','none'))
    except Exception: raise HTTPException(409,'Email already registered or invalid registration')
    return {'user_id':uid_user,'organization_id':org,'trial_hours':72,'trial_ends_at':end,'session_token':issue_session(uid_user),'token_type':'bearer'}

@app.post('/api/v1/auth/login')
def login(req:Login):
    with connect() as c: row=c.execute('SELECT id,password_hash FROM users WHERE email=?',(req.email.strip().lower(),)).fetchone()
    if not row or not verify_password(req.password,row['password_hash']): raise HTTPException(401,'Invalid email or password')
    return {'session_token':issue_session(row['id']),'token_type':'bearer'}

@app.post('/api/v1/auth/logout')
def logout(authorization:str|None=Header(default=None),user:str=Depends(user_id)):
    if authorization and authorization.startswith('Bearer '):
        import hashlib
        digest=hashlib.sha256(authorization[7:].encode()).hexdigest()
        with connect() as c: c.execute('DELETE FROM sessions WHERE token_hash=?',(digest,))
    return {'status':'signed_out'}

@app.get('/api/v1/organizations')
def organizations(user:str=Depends(user_id)):
    with connect() as c: rows=c.execute('SELECT o.id,o.name,o.currency,m.role FROM organizations o JOIN memberships m ON m.org_id=o.id WHERE m.user_id=?',(user,)).fetchall()
    return [dict(r) for r in rows]

@app.post('/api/v1/organizations',status_code=201)
def create_org(req:OrganizationIn,user:str=Depends(user_id)):
    oid=uid(); t=now()
    with connect() as c:
        c.execute('INSERT INTO organizations VALUES(?,?,?,?,?)',(oid,req.name,user,req.currency.upper(),t)); c.execute('INSERT INTO memberships VALUES(?,?,?)',(user,oid,'owner'))
        end=(datetime.now(timezone.utc)+timedelta(hours=72)).isoformat(); c.execute('INSERT INTO subscriptions VALUES(?,?,?,?,?)',(oid,t,end,'trial','none'))
    return {'id':oid,'name':req.name,'currency':req.currency.upper()}

@app.post('/api/v1/organizations/{org_id}/products',status_code=201)
def create_product(org_id:str,req:ProductIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id); pid=uid(); t=now()
    try:
        with connect() as c: c.execute('INSERT INTO products VALUES(?,?,?,?,?,?,?)',(pid,org_id,req.name,req.sku,req.unit,req.currency.upper(),t))
    except Exception: raise HTTPException(409,'Duplicate SKU or invalid product')
    return {'id':pid,'name':req.name,'sku':req.sku,'unit':req.unit,'currency':req.currency.upper()}

@app.get('/api/v1/organizations/{org_id}/products')
def list_products(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,name,sku,unit,currency,created_at FROM products WHERE org_id=? ORDER BY created_at DESC',(org_id,)).fetchall()
    return [dict(r) for r in rows]

@app.post('/api/v1/organizations/{org_id}/costing',status_code=201)
def create_costing(org_id:str,req:CostingIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c: product=c.execute('SELECT id,currency FROM products WHERE id=? AND org_id=?',(req.product_id,org_id)).fetchone()
    if not product: raise HTTPException(404,'Product not found in this organization')
    if product['currency']!=req.currency.upper(): raise HTTPException(422,'Product and costing currencies must match')
    try:
        total=engine.total_cost(req.components.values()); unit=engine.unit_cost(total,req.good_saleable_units); profit=engine.profit_per_unit(req.selling_price,unit)
        result={'total_cost':str(total),'unit_cost':str(unit),'profit_per_unit':str(profit),'total_revenue':str(engine.money(Decimal(str(req.selling_price))*Decimal(str(req.good_saleable_units)))),'total_profit':str(engine.money((Decimal(str(req.selling_price))-unit)*Decimal(str(req.good_saleable_units)))),'margin':str(engine.margin(profit,req.selling_price)),'markup':str(engine.markup(profit,unit)) if unit>0 else None,'formula_version':engine.MODEL_VERSION}
    except engine.FinancialInputError as e: raise HTTPException(422,str(e))
    sid=uid(); t=now(); inputs=req.model_dump(); inputs['components']={k:str(v) for k,v in req.components.items()}
    with connect() as c:
        c.execute('INSERT INTO cost_snapshots VALUES(?,?,?,?,?,?,?,?,?,?)',(sid,org_id,req.product_id,req.period,req.currency.upper(),json.dumps(inputs,ensure_ascii=False),json.dumps(result),engine.MODEL_VERSION,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','cost_snapshot',sid,t))
    return {'snapshot_id':sid,'inputs':inputs,'results':result,'created_at':t,'warning':'Snapshot is immutable; recalculation creates a new snapshot.'}

@app.get('/api/v1/organizations/{org_id}/costing')
def list_costing(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,product_id,period,currency,inputs_json,results_json,formula_version,created_at FROM cost_snapshots WHERE org_id=? ORDER BY created_at DESC',(org_id,)).fetchall()
    return [{'id':r['id'],'snapshot_id':r['id'],'product_id':r['product_id'],'period':r['period'],'currency':r['currency'],'inputs':json.loads(r['inputs_json']),'results':json.loads(r['results_json']),'formula_version':r['formula_version'],'created_at':r['created_at']} for r in rows]

@app.post('/api/v1/organizations/{org_id}/scenarios',status_code=201)
def create_scenario(org_id:str,req:ScenarioIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c: snap=c.execute('SELECT inputs_json,results_json FROM cost_snapshots WHERE id=? AND org_id=?',(req.snapshot_id,org_id)).fetchone()
    if not snap: raise HTTPException(404,'Cost snapshot not found')
    inputs=json.loads(snap['inputs_json']); base=inputs['components']
    try: result=engine.scenario(base,req.changes)
    except engine.FinancialInputError as e: raise HTTPException(422,str(e))
    sid=uid(); t=now()
    with connect() as c: c.execute('INSERT INTO scenarios VALUES(?,?,?,?,?,?,?,?)',(sid,org_id,req.snapshot_id,req.name,json.dumps(req.changes),json.dumps(result,default=str),t,user))
    return {'id':sid,'base_snapshot_id':req.snapshot_id,'name':req.name,'results':json.loads(json.dumps(result,default=str)),'is_forecast':False,'label':'What-if scenario — not a forecast'}

@app.post('/api/v1/organizations/{org_id}/allocations',status_code=201)
def create_allocation(org_id:str,req:AllocationIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    try: result=engine.allocate_cost(req.pool_cost,req.driver_quantities,req.selected_driver_quantity)
    except engine.FinancialInputError as e: raise HTTPException(422,str(e))
    aid=uid(); t=now(); formula='Allocated Share = Cost Pool × Selected Driver Quantity / Total Driver Quantity'
    with connect() as c: c.execute('INSERT INTO allocations VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(aid,org_id,req.pool_name,req.basis,req.driver,req.period,json.dumps(req.source_quantities),req.assumptions,formula,str(result),t,user))
    return {'id':aid,'pool_name':req.pool_name,'basis':req.basis,'driver':req.driver,'period':req.period,'source_quantities':req.source_quantities,'assumptions':req.assumptions,'formula':formula,'allocated_cost':str(result),'created_at':t}

@app.get('/api/v1/organizations/{org_id}/allocations')
def list_allocations(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT * FROM allocations WHERE org_id=? ORDER BY created_at DESC',(org_id,)).fetchall()
    return [{'id':r['id'],'pool_name':r['pool_name'],'basis':r['basis'],'driver':r['driver'],'period':r['period'],'source_quantities':json.loads(r['source_quantities_json']),'assumptions':r['assumptions'],'formula':r['formula'],'allocated_cost':r['result'],'created_at':r['created_at']} for r in rows]

@app.post('/api/v1/units/convert')
def convert_units(req:UnitConversionIn):
    try: return {'quantity':str(engine.convert_units(req.quantity,req.from_unit,req.to_unit,{tuple(k.split('|',1)):v for k,v in req.conversions.items() if '|' in k})),'from_unit':req.from_unit,'to_unit':req.to_unit,'conversion_source':'user-supplied conversion map'}
    except engine.FinancialInputError as e: raise HTTPException(422,str(e))

@app.post('/api/v1/organizations/{org_id}/research/evidence',status_code=201)
def add_evidence(org_id:str,req:EvidenceIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id); eid=uid(); t=now()
    with connect() as c: c.execute('INSERT INTO research_evidence VALUES(?,?,?,?,?,?,?,?)',(eid,org_id,req.title,req.status,req.source_ref,req.notes,t,user))
    return {'id':eid,'title':req.title,'status':req.status,'source_ref':req.source_ref,'created_at':t,'notice':'Evidence record only; this does not establish a research finding.'}

@app.get('/api/v1/organizations/{org_id}/research/evidence')
def list_evidence(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,title,status,source_ref,notes,created_at FROM research_evidence WHERE org_id=? ORDER BY created_at DESC',(org_id,)).fetchall()
    return [dict(r) for r in rows]

@app.post('/api/v1/organizations/{org_id}/research/establishments',status_code=201)
def create_research_establishment(org_id:str,req:ResearchEstablishmentIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id); eid=uid(); t=now()
    try:
        with connect() as c:
            c.execute('INSERT INTO research_establishments VALUES(?,?,?,?,?,?,?,?,?)',(eid,org_id,req.pseudonym,req.sector,req.region,req.participation_status,req.notes,t,user))
            c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','research_establishment',eid,t))
    except Exception: raise HTTPException(409,'Pseudonym already exists or record is invalid')
    return {'id':eid,'pseudonym':req.pseudonym,'sector':req.sector,'region':req.region,'participation_status':req.participation_status,'notice':'Use pseudonyms; do not store identifying participant details.'}
@app.get('/api/v1/organizations/{org_id}/research/establishments')
def list_research_establishments(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,pseudonym,sector,region,participation_status,notes,created_at FROM research_establishments WHERE org_id=? ORDER BY created_at DESC',(org_id,)).fetchall()
    return [dict(r) for r in rows]
@app.post('/api/v1/organizations/{org_id}/research/permissions',status_code=201)
def create_research_permission(org_id:str,req:ResearchPermissionIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c: est=c.execute('SELECT id FROM research_establishments WHERE id=? AND org_id=?',(req.establishment_id,org_id)).fetchone()
    if not est: raise HTTPException(404,'Research establishment not found')
    if req.permission_status=='granted' and not req.reference.strip(): raise HTTPException(422,'Permission reference required for granted status')
    pid=uid(); t=now()
    with connect() as c:
        c.execute('INSERT INTO research_permissions VALUES(?,?,?,?,?,?,?,?,?,?,?)',(pid,org_id,req.establishment_id,req.permission_type,req.permission_status,req.reference,req.valid_from,req.valid_until,req.notes,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','research_permission',pid,t))
    return {'id':pid,'permission_status':req.permission_status,'notice':'Metadata only; verify the actual authorization document.'}
@app.get('/api/v1/organizations/{org_id}/research/permissions')
def list_research_permissions(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,establishment_id,permission_type,permission_status,reference,valid_from,valid_until,notes,created_at FROM research_permissions WHERE org_id=? ORDER BY created_at DESC',(org_id,)).fetchall()
    return [dict(r) for r in rows]
@app.post('/api/v1/organizations/{org_id}/research/interactions',status_code=201)
def create_research_interaction(org_id:str,req:ResearchInteractionIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        required_permission={'interview':'interview','survey':'survey','observation':'site_access'}[req.interaction_type]
        permission=c.execute("SELECT id FROM research_permissions WHERE id=? AND org_id=? AND establishment_id=? AND permission_type=? AND permission_status='granted' AND (valid_from='' OR valid_from<=?) AND (valid_until='' OR valid_until>=?)",(req.permission_id,org_id,req.establishment_id,required_permission,req.occurred_on,req.occurred_on)).fetchone()
    if not permission: raise HTTPException(403,'Matching granted and in-date permission is required')
    iid=uid(); t=now()
    with connect() as c:
        c.execute('INSERT INTO research_interactions VALUES(?,?,?,?,?,?,?,?,?,?,?)',(iid,org_id,req.establishment_id,req.interaction_type,req.participant_code,req.occurred_on,req.permission_id,req.record_status,req.notes,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','research_interaction',iid,t))
    return {'id':iid,'interaction_type':req.interaction_type,'record_status':req.record_status,'notice':'Metadata only; no research finding is inferred.'}
@app.get('/api/v1/organizations/{org_id}/research/interactions')
def list_research_interactions(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,establishment_id,interaction_type,participant_code,occurred_on,permission_id,record_status,notes,created_at FROM research_interactions WHERE org_id=? ORDER BY occurred_on DESC',(org_id,)).fetchall()
    return [dict(r) for r in rows]
@app.post('/api/v1/organizations/{org_id}/research/hypotheses',status_code=201)
def create_research_hypothesis(org_id:str,req:ResearchHypothesisIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        for ref in req.evidence_refs:
            if not c.execute('SELECT id FROM research_evidence WHERE id=? AND org_id=?',(ref,org_id)).fetchone():
                raise HTTPException(422,'Evidence reference must belong to this organization')
        hid=uid(); t=now()
        c.execute('INSERT INTO research_hypotheses VALUES(?,?,?,?,?,?,?,?,?)',(hid,org_id,req.statement,req.status,json.dumps(req.evidence_refs),req.notes,t,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','research_hypothesis',hid,t))
    return {'id':hid,'status':req.status,'evidence_refs':req.evidence_refs,'notice':'Hypothesis is not a finding.'}
@app.patch('/api/v1/organizations/{org_id}/research/hypotheses/{hypothesis_id}')
def update_research_hypothesis(org_id:str,hypothesis_id:str,req:ResearchHypothesisUpdate,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    if req.status in ('supported','not_supported','inconclusive') and not req.evidence_refs: raise HTTPException(422,'Evidence references required for assessed status')
    with connect() as c:
        if not c.execute('SELECT id FROM research_hypotheses WHERE id=? AND org_id=?',(hypothesis_id,org_id)).fetchone(): raise HTTPException(404,'Hypothesis not found')
        for ref in req.evidence_refs:
            if not c.execute('SELECT id FROM research_evidence WHERE id=? AND org_id=?',(ref,org_id)).fetchone(): raise HTTPException(422,'Evidence reference must belong to this organization')
        c.execute('UPDATE research_hypotheses SET status=?,evidence_refs_json=?,notes=?,updated_at=? WHERE id=? AND org_id=?',(req.status,json.dumps(req.evidence_refs),req.notes,now(),hypothesis_id,org_id))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'update','research_hypothesis',hypothesis_id,now()))
    return {'id':hypothesis_id,'status':req.status,'evidence_refs':req.evidence_refs,'notice':'Researcher assessment only; not automatically verified.'}
@app.get('/api/v1/organizations/{org_id}/research/hypotheses')
def list_research_hypotheses(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,statement,status,evidence_refs_json,notes,created_at,updated_at FROM research_hypotheses WHERE org_id=? ORDER BY created_at DESC',(org_id,)).fetchall()
    return [{'id':r['id'],'statement':r['statement'],'status':r['status'],'evidence_refs':json.loads(r['evidence_refs_json']),'notes':r['notes'],'created_at':r['created_at'],'updated_at':r['updated_at']} for r in rows]
@app.post('/api/v1/organizations/{org_id}/research/data-dictionary',status_code=201)
def create_research_dictionary_item(org_id:str,req:ResearchDictionaryIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id); did=uid(); t=now()
    try:
        with connect() as c:
            c.execute('INSERT INTO research_dictionary VALUES(?,?,?,?,?,?,?,?,?,?)',(did,org_id,req.variable_name,req.definition,req.data_type,req.unit,req.allowed_values,req.sensitivity,t,user))
            c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','research_dictionary',did,t))
    except Exception: raise HTTPException(409,'Variable name already exists or invalid')
    return {'id':did,'variable_name':req.variable_name,'definition':req.definition,'data_type':req.data_type,'unit':req.unit,'sensitivity':req.sensitivity}
@app.get('/api/v1/organizations/{org_id}/research/data-dictionary')
def list_research_dictionary(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,variable_name,definition,data_type,unit,allowed_values,sensitivity,created_at FROM research_dictionary WHERE org_id=? ORDER BY variable_name',(org_id,)).fetchall()
    return [dict(r) for r in rows]

@app.post('/api/v1/organizations/{org_id}/materials',status_code=201)
def create_material(org_id:str,req:RawMaterialIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    mid=uid(); t=now()
    try:
        with connect() as c: c.execute('INSERT INTO raw_materials VALUES(?,?,?,?,?,?,?,?)',(mid,org_id,req.name,req.sku,req.unit,req.currency.upper(),str(engine.money(engine.D(req.unit_cost))),t))
    except Exception: raise HTTPException(409,'Duplicate material SKU or invalid material')
    return {'id':mid,'name':req.name,'sku':req.sku,'unit':req.unit,'currency':req.currency.upper(),'unit_cost':str(engine.money(engine.D(req.unit_cost)))}

@app.get('/api/v1/organizations/{org_id}/materials')
def list_materials(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,name,sku,unit,currency,unit_cost,created_at FROM raw_materials WHERE org_id=? ORDER BY name',(org_id,)).fetchall()
    return [dict(r) for r in rows]

@app.post('/api/v1/organizations/{org_id}/inventory/movements',status_code=201)
def create_inventory_movement(org_id:str,req:InventoryMovementIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        material=c.execute('SELECT id,unit,unit_cost FROM raw_materials WHERE id=? AND org_id=?',(req.material_id,org_id)).fetchone()
        if not material: raise HTTPException(404,'Material not found in this organization')
        if material['unit']!=req.unit: raise HTTPException(422,'Inventory movement unit must match material base unit; convert explicitly first')
        balance=c.execute("SELECT COALESCE(SUM(CASE movement_type WHEN 'receipt' THEN CAST(quantity AS REAL) WHEN 'issue' THEN -CAST(quantity AS REAL) ELSE CAST(quantity AS REAL) END),0) AS qty FROM inventory_movements WHERE org_id=? AND material_id=?",(org_id,req.material_id)).fetchone()['qty']
        if req.movement_type=='issue' and req.quantity>balance: raise HTTPException(422,'Insufficient on-hand inventory')
        if req.movement_type=='adjustment' and req.quantity<0: raise HTTPException(422,'Adjustment quantity must be positive; use a separately reviewed stock correction workflow')
        mid=uid(); t=now()
        c.execute('INSERT INTO inventory_movements VALUES(?,?,?,?,?,?,?,?,?,?)',(mid,org_id,req.material_id,req.movement_type,str(req.quantity),req.unit,str(engine.money(engine.D(req.unit_cost))),req.reference,t,user))
        new_balance=balance + req.quantity if req.movement_type in ('receipt','adjustment') else balance-req.quantity
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','inventory_movement',mid,t))
    return {'id':mid,'material_id':req.material_id,'movement_type':req.movement_type,'quantity':str(req.quantity),'unit':req.unit,'reference':req.reference,'on_hand':str(engine.D(new_balance)),'created_at':t}

@app.post('/api/v1/organizations/{org_id}/inventory/stocktake',status_code=201)
def material_stocktake(org_id:str,req:MaterialStocktakeIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        material=c.execute('SELECT id,unit FROM raw_materials WHERE id=? AND org_id=?',(req.material_id,org_id)).fetchone()
        if not material: raise HTTPException(404,'Material not found in this organization')
        if material['unit']!=req.unit: raise HTTPException(422,'Stocktake unit must match the material base unit')
        balance=Decimal(str(c.execute("SELECT COALESCE(SUM(CASE movement_type WHEN 'receipt' THEN CAST(quantity AS REAL) WHEN 'issue' THEN -CAST(quantity AS REAL) ELSE CAST(quantity AS REAL) END),0) q FROM inventory_movements WHERE org_id=? AND material_id=?",(org_id,req.material_id)).fetchone()['q']))
        counted=Decimal(str(req.counted_quantity)); delta=counted-balance
        if delta==0: return {'material_id':req.material_id,'book_quantity':str(balance),'counted_quantity':str(counted),'difference':'0','movement_id':None,'notice':'No adjustment required; physical count matches recorded quantity.'}
        movement_type='adjustment' if delta>0 else 'issue'; quantity=abs(delta)
        if delta>0 and Decimal(str(req.unit_cost))<0: raise HTTPException(422,'Positive stocktake difference requires a non-negative valuation cost')
        mid=uid(); t=now(); cost=engine.money(engine.D(req.unit_cost))
        ref='stocktake:'+req.reference.strip()
        if c.execute('SELECT 1 FROM inventory_movements WHERE org_id=? AND reference=?',(org_id,ref)).fetchone(): raise HTTPException(409,'Stocktake reference already used')
        c.execute('INSERT INTO inventory_movements VALUES(?,?,?,?,?,?,?,?,?,?)',(mid,org_id,req.material_id,movement_type,str(quantity),req.unit,str(cost),ref,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','inventory_stocktake',mid,t))
        return {'material_id':req.material_id,'book_quantity':str(balance),'counted_quantity':str(counted),'difference':str(delta),'movement_type':movement_type,'quantity':str(quantity),'movement_id':mid,'reference':ref,'notes':req.notes,'created_at':t,'notice':'Stocktake posted as a signed difference; negative differences consume inventory layers using the selected valuation method during valuation replay.'}

def _material_valuation(c, org_id: str, material_id: str, method: str):
    events=c.execute("SELECT movement_type,quantity,unit_cost,created_at,id FROM inventory_movements WHERE org_id=? AND material_id=? ORDER BY created_at,id",(org_id,material_id)).fetchall()
    qty=Decimal('0'); value=Decimal('0'); layers=[]
    for e in events:
        q=Decimal(e['quantity']); cost=Decimal(e['unit_cost'])
        if e['movement_type'] in ('receipt','adjustment'):
            qty+=q; value+=q*cost
            if method=='fifo': layers.append([q,cost])
        elif e['movement_type']=='issue':
            if q>qty: raise HTTPException(409,'Historical inventory movements contain a negative-stock sequence; reconcile before valuation')
            if method=='weighted_average':
                avg=(value/qty) if qty else Decimal('0')
                value-=q*avg
            else:
                remaining=q; issue_value=Decimal('0')
                while remaining>0 and layers:
                    take=min(remaining,layers[0][0]); issue_value+=take*layers[0][1]
                    layers[0][0]-=take; remaining-=take
                    if layers[0][0]==0: layers.pop(0)
                if remaining>0: raise HTTPException(409,'FIFO layers do not reconcile with inventory quantity')
                value-=issue_value
            qty-=q
    if qty==0: value=Decimal('0')
    avg=value/qty if qty else Decimal('0')
    return {'quantity':str(qty),'inventory_value':str(engine.money(value)),'average_unit_cost':str(engine.money(avg))}

@app.get('/api/v1/organizations/{org_id}/inventory/valuation')
def inventory_valuation(org_id:str,method:Literal['fifo','weighted_average']='weighted_average',user:str=Depends(user_id)):
    org_access(org_id,user)
    result=[]
    with connect() as c:
        materials=c.execute('SELECT id,name,unit,currency FROM raw_materials WHERE org_id=? ORDER BY name',(org_id,)).fetchall()
        for m in materials:
            v=_material_valuation(c,org_id,m['id'],method)
            result.append({'material_id':m['id'],'name':m['name'],'unit':m['unit'],'currency':m['currency'],'method':method,**v})
    return {'method':method,'items':result,'notice':'Valuation is reconstructed from recorded movements in timestamp order. Adjustment movements are treated as positive receipts. Verify opening balances and historical movement completeness before financial reporting.'}

@app.post('/api/v1/organizations/{org_id}/production-orders/{order_id}/issue-materials',status_code=201)
def issue_production_materials(org_id:str,order_id:str,method:Literal['fifo','weighted_average']='weighted_average',user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        order=c.execute('SELECT * FROM production_orders WHERE id=? AND org_id=?',(order_id,org_id)).fetchone()
        if not order: raise HTTPException(404,'Production order not found')
        ref=f'production:{order_id}'
        if c.execute('SELECT 1 FROM inventory_movements WHERE org_id=? AND reference=? LIMIT 1',(org_id,ref)).fetchone():
            raise HTTPException(409,'Materials have already been issued for this production order')
        bom=c.execute('SELECT b.material_id,b.quantity_per_unit,b.waste_rate,r.unit,r.currency FROM bom_items b JOIN raw_materials r ON r.id=b.material_id WHERE b.org_id=? AND b.product_id=? ORDER BY b.material_id',(org_id,order['product_id'])).fetchall()
        if not bom: raise HTTPException(422,'A bill of materials is required')
        required=[]; total=Decimal('0')
        for b in bom:
            if b['currency']!=order['currency']: raise HTTPException(422,'Material currency differs from production order currency')
            q=Decimal(order['planned_units'])*Decimal(b['quantity_per_unit'])*(Decimal('1')+Decimal(b['waste_rate']))
            v=_material_valuation(c,org_id,b['material_id'],method)
            available=Decimal(v['quantity'])
            if q>available: raise HTTPException(422,f'Insufficient inventory for material {b["material_id"]}: required {q}, available {available}')
            unit_cost=Decimal(v['average_unit_cost'])
            if method=='fifo':
                # Reconstruct the cost of the next FIFO issue from open receipt layers.
                events=c.execute("SELECT movement_type,quantity,unit_cost,created_at,id FROM inventory_movements WHERE org_id=? AND material_id=? ORDER BY created_at,id",(org_id,b['material_id'])).fetchall()
                layers=[]
                for e in events:
                    eq=Decimal(e['quantity']); ec=Decimal(e['unit_cost'])
                    if e['movement_type'] in ('receipt','adjustment'): layers.append([eq,ec])
                    elif e['movement_type']=='issue':
                        rem=eq
                        while rem>0 and layers:
                            take=min(rem,layers[0][0]); layers[0][0]-=take; rem-=take
                            if layers[0][0]==0: layers.pop(0)
                rem=q; issue_value=Decimal('0')
                for layer in layers:
                    take=min(rem,layer[0]); issue_value+=take*layer[1]; rem-=take
                    if rem==0: break
                unit_cost=issue_value/q if q else Decimal('0')
            line=engine.money(q*unit_cost); total+=line
            required.append((b['material_id'],q,b['unit'],unit_cost,line))
        total=engine.money(total)
        # Atomic posting: all material balances were validated before any movement is inserted.
        t=now(); posted=[]
        for mid,q,unit,unit_cost,line in required:
            movement_id=uid()
            c.execute('INSERT INTO inventory_movements VALUES(?,?,?,?,?,?,?,?,?,?)',(movement_id,org_id,mid,'issue',str(q),unit,str(engine.money(unit_cost)),ref,t,user))
            c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','production_material_issue',movement_id,t))
            posted.append({'material_id':mid,'quantity':str(q),'unit':unit,'unit_cost':str(engine.money(unit_cost)),'issue_cost':str(line)})
        conversion=Decimal(order['conversion_cost']); overhead=Decimal(order['overhead_cost'])
        new_total=engine.money(total+conversion+overhead); unit_cost=engine.unit_cost(new_total,Decimal(order['good_units']))
        c.execute('UPDATE production_orders SET material_cost=?,total_cost=?,unit_cost=? WHERE id=? AND org_id=?',(str(total),str(new_total),str(unit_cost),order_id,org_id))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'update','production_order_material_issue',order_id,t))
    return {'production_order_id':order_id,'method':method,'reference':ref,'issued_materials':posted,'material_cost':str(total),'total_cost':str(new_total),'unit_cost_per_good_unit':str(unit_cost),'notice':'Material issue posted atomically from the BOM including waste allowance. This operation cannot be repeated for the same order; corrections require a separately reviewed stock adjustment.'}

@app.get('/api/v1/organizations/{org_id}/inventory')
def inventory_balances(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        rows=c.execute("SELECT r.id AS material_id,r.name,r.unit,r.currency,r.unit_cost,COALESCE(SUM(CASE m.movement_type WHEN 'receipt' THEN CAST(m.quantity AS REAL) WHEN 'issue' THEN -CAST(m.quantity AS REAL) ELSE CAST(m.quantity AS REAL) END),0) AS on_hand FROM raw_materials r LEFT JOIN inventory_movements m ON m.material_id=r.id AND m.org_id=r.org_id WHERE r.org_id=? GROUP BY r.id,r.name,r.unit,r.currency,r.unit_cost ORDER BY r.name",(org_id,)).fetchall()
    return [dict(r) for r in rows]

@app.post('/api/v1/organizations/{org_id}/products/{product_id}/bom',status_code=201)
def add_bom_item(org_id:str,product_id:str,req:BOMItemIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        product=c.execute('SELECT id,currency FROM products WHERE id=? AND org_id=?',(product_id,org_id)).fetchone()
        material=c.execute('SELECT id,currency FROM raw_materials WHERE id=? AND org_id=?',(req.material_id,org_id)).fetchone()
    if not product or not material: raise HTTPException(404,'Product or material not found in this organization')
    if product['currency']!=material['currency']: raise HTTPException(422,'Product and material currencies must match')
    bid=uid(); t=now()
    try:
        with connect() as c: c.execute('INSERT INTO bom_items VALUES(?,?,?,?,?,?,?)',(bid,org_id,product_id,req.material_id,str(req.quantity_per_unit),str(req.waste_rate),t))
    except Exception: raise HTTPException(409,'BOM item already exists or is invalid')
    return {'id':bid,'product_id':product_id,'material_id':req.material_id,'quantity_per_unit':req.quantity_per_unit,'waste_rate':req.waste_rate}

@app.get('/api/v1/organizations/{org_id}/products/{product_id}/bom')
def list_bom(org_id:str,product_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT b.id,b.material_id,r.name,r.unit,r.currency,r.unit_cost,b.quantity_per_unit,b.waste_rate FROM bom_items b JOIN raw_materials r ON r.id=b.material_id WHERE b.org_id=? AND b.product_id=? ORDER BY r.name',(org_id,product_id)).fetchall()
    return [dict(r) for r in rows]

@app.post('/api/v1/organizations/{org_id}/production-orders',status_code=201)
def create_production_order(org_id:str,req:ProductionOrderIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        product=c.execute('SELECT id,currency FROM products WHERE id=? AND org_id=?',(req.product_id,org_id)).fetchone()
        rows=c.execute('SELECT b.quantity_per_unit,b.waste_rate,r.unit_cost,r.currency FROM bom_items b JOIN raw_materials r ON r.id=b.material_id WHERE b.org_id=? AND b.product_id=?',(org_id,req.product_id)).fetchall()
    if not product: raise HTTPException(404,'Product not found in this organization')
    if product['currency']!=req.currency.upper() or any(r['currency']!=req.currency.upper() for r in rows): raise HTTPException(422,'Product, materials and production order currencies must match')
    if not rows: raise HTTPException(422,'A bill of materials is required before production')
    try:
        planned=Decimal(str(req.planned_units)); good=Decimal(str(req.good_units))
        if good>planned: raise engine.FinancialInputError('Good saleable units cannot exceed planned units')
        material_total=Decimal('0')
        for r in rows:
            gross=planned*Decimal(r['quantity_per_unit'])*(Decimal('1')+Decimal(r['waste_rate']))
            material_total+=gross*Decimal(r['unit_cost'])
        material_total=engine.money(material_total); total=engine.total_cost([material_total,req.conversion_cost,req.overhead_cost]); per_unit=engine.unit_cost(total,good)
    except (engine.FinancialInputError,ArithmeticError,ValueError) as e: raise HTTPException(422,str(e))
    oid=uid(); t=now()
    with connect() as c:
        c.execute('INSERT INTO production_orders VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(oid,org_id,req.product_id,str(planned),str(good),req.period,req.currency.upper(),str(material_total),str(engine.money(engine.D(req.conversion_cost))),str(engine.money(engine.D(req.overhead_cost))),str(total),str(per_unit),'costed',t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','production_order',oid,t))
    return {'id':oid,'product_id':req.product_id,'planned_units':str(planned),'good_saleable_units':str(good),'material_cost':str(material_total),'conversion_cost':str(engine.money(engine.D(req.conversion_cost))),'overhead_cost':str(engine.money(engine.D(req.overhead_cost))),'total_cost':str(total),'unit_cost':str(per_unit),'currency':req.currency.upper(),'status':'costed','notice':'BOM material cost includes the specified waste allowance. Inventory is not posted by this costing endpoint.'}

@app.post('/api/v1/organizations/{org_id}/products/{product_id}/standard-costs',status_code=201)
def create_product_standard_cost(org_id:str,product_id:str,req:ProductStandardCostIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    currency=req.currency.upper()
    with connect() as c:
        product=c.execute('SELECT id,currency FROM products WHERE id=? AND org_id=?',(product_id,org_id)).fetchone()
        if not product: raise HTTPException(404,'Product not found in this organization')
        if product['currency']!=currency: raise HTTPException(422,'Standard cost currency must match product currency')
        seen=set(); standards=[]
        for item in req.materials:
            if item.material_id in seen: raise HTTPException(422,'Each material may appear only once in a standard cost sheet')
            seen.add(item.material_id)
            material=c.execute('SELECT id,unit,currency FROM raw_materials WHERE id=? AND org_id=?',(item.material_id,org_id)).fetchone()
            if not material: raise HTTPException(404,'A standard material was not found in this organization')
            if material['currency']!=currency: raise HTTPException(422,'Standard material currency must match product currency')
            q=Decimal(str(item.quantity_per_good_unit)); rate=Decimal(str(item.standard_unit_cost))
            if not q.is_finite() or not rate.is_finite() or q<=0 or rate<0: raise HTTPException(422,'Standard material quantities and rates must be finite and valid')
            standards.append({'material_id':item.material_id,'unit':material['unit'],'quantity_per_good_unit':str(q),'standard_unit_cost':str(engine.money(rate))})
        hours=Decimal(str(req.labor_hours_per_good_unit)); labor_rate=Decimal(str(req.standard_labor_hourly_rate)); overhead=Decimal(str(req.overhead_per_good_unit))
        if not all(x.is_finite() for x in (hours,labor_rate,overhead)): raise HTTPException(422,'Standard labor and overhead inputs must be finite')
        if hours<0 or labor_rate<0 or overhead<0: raise HTTPException(422,'Standard labor and overhead inputs cannot be negative')
        version=c.execute('SELECT COALESCE(MAX(version),0)+1 v FROM product_standard_costs WHERE org_id=? AND product_id=?',(org_id,product_id)).fetchone()['v']
        sid=uid(); t=now()
        c.execute('INSERT INTO product_standard_costs VALUES(?,?,?,?,?,?,?,?,?,?,?)',(sid,org_id,product_id,currency,json.dumps(standards),str(hours),str(engine.money(labor_rate)),str(engine.money(overhead)),version,t,user))
        machine_values=(req.machine_hours_per_good_unit,req.budgeted_machine_hours,req.fixed_overhead_budget)
        if any(v is not None for v in machine_values):
            if any(v is None for v in machine_values): raise HTTPException(422,'Machine-hour standards require machine hours per good unit, budgeted machine hours, and fixed overhead budget together')
            mh=Decimal(str(req.machine_hours_per_good_unit)); capacity=Decimal(str(req.budgeted_machine_hours)); fixed_budget=Decimal(str(req.fixed_overhead_budget))
            if not all(v.is_finite() for v in (mh,capacity,fixed_budget)) or mh<=0 or capacity<=0 or fixed_budget<0: raise HTTPException(422,'Machine-hour standards must be finite and valid')
            c.execute('INSERT INTO product_machine_standards VALUES(?,?,?,?,?,?,?)',(uid(),org_id,sid,str(mh),str(capacity),str(engine.money(fixed_budget)),t))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','product_standard_cost',sid,t))
    return {'id':sid,'product_id':product_id,'version':version,'currency':currency,'materials':standards,'labor_hours_per_good_unit':str(hours),'standard_labor_hourly_rate':str(engine.money(labor_rate)),'overhead_per_good_unit':str(engine.money(overhead)),'machine_hours_per_good_unit':req.machine_hours_per_good_unit,'budgeted_machine_hours':req.budgeted_machine_hours,'fixed_overhead_budget':None if req.fixed_overhead_budget is None else str(engine.money(engine.D(req.fixed_overhead_budget))),'notice':'Standard costs are versioned benchmarks supplied by the organization; they are not actual costs or forecasts.'}

@app.post('/api/v1/organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/machine-hours',status_code=201)
def record_production_machine_hours(org_id:str,order_id:str,stage_id:str,req:ProductionMachineHoursIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    try:
        hours=Decimal(str(req.machine_hours))
        if not hours.is_finite() or hours<=0: raise ValueError()
    except Exception: raise HTTPException(422,'Machine hours must be a positive finite number')
    with connect() as c:
        order=c.execute('SELECT status FROM production_orders WHERE id=? AND org_id=?',(order_id,org_id)).fetchone()
        stage=c.execute('SELECT status FROM production_stages WHERE id=? AND org_id=? AND order_id=?',(stage_id,org_id,order_id)).fetchone()
        if not order or not stage: raise HTTPException(404,'Production order or stage not found')
        if order['status']=='completed' or stage['status']!='in_progress': raise HTTPException(409,'Machine hours can only be recorded against an in-progress stage')
        mid=uid(); t=now()
        c.execute('INSERT INTO production_machine_entries VALUES(?,?,?,?,?,?,?,?,?,?)',(mid,org_id,order_id,stage_id,req.machine_code,req.description,str(hours),req.occurred_on,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','production_machine_entry',mid,t))
    return {'id':mid,'order_id':order_id,'stage_id':stage_id,'machine_code':req.machine_code,'machine_hours':str(hours),'occurred_on':req.occurred_on,'notice':'Machine time is an operational driver record; no machine depreciation, energy cost, or overhead is posted by this entry.'}

@app.get('/api/v1/organizations/{org_id}/production-orders/{order_id}/machine-hours')
def list_production_machine_hours(org_id:str,order_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        if not c.execute('SELECT 1 FROM production_orders WHERE id=? AND org_id=?',(order_id,org_id)).fetchone(): raise HTTPException(404,'Production order not found')
        rows=c.execute('SELECT id,stage_id,machine_code,description,machine_hours,occurred_on,created_at FROM production_machine_entries WHERE org_id=? AND order_id=? ORDER BY created_at,id',(org_id,order_id)).fetchall()
    total=sum((Decimal(r['machine_hours']) for r in rows),Decimal('0'))
    return {'entries':[dict(r) for r in rows],'total_machine_hours':str(total),'count':len(rows)}

@app.get('/api/v1/organizations/{org_id}/production-orders/{order_id}/variance')
def production_cost_variance(org_id:str,order_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        order=c.execute('SELECT * FROM production_orders WHERE id=? AND org_id=?',(order_id,org_id)).fetchone()
        if not order: raise HTTPException(404,'Production order not found')
        standard=c.execute('SELECT * FROM product_standard_costs WHERE org_id=? AND product_id=? ORDER BY version DESC LIMIT 1',(org_id,order['product_id'])).fetchone()
        if not standard: raise HTTPException(404,'No standard cost sheet exists for this product')
        stages=c.execute('SELECT id,conversion_cost,overhead_cost FROM production_stages WHERE org_id=? AND order_id=?',(org_id,order_id)).fetchall()
        actual_materials=c.execute('SELECT material_id,quantity,total_cost FROM production_stage_materials WHERE org_id=? AND order_id=? ORDER BY created_at,id',(org_id,order_id)).fetchall()
        labor=c.execute('SELECT COALESCE(SUM(CAST(hours AS REAL)),0) hours,COALESCE(SUM(CAST(labor_cost AS REAL)),0) cost FROM production_labor_entries WHERE org_id=? AND order_id=?',(org_id,order_id)).fetchone()
        machine_standard=c.execute('SELECT * FROM product_machine_standards WHERE org_id=? AND standard_id=?',(org_id,standard['id'])).fetchone()
        machine_actual=c.execute('SELECT COALESCE(SUM(CAST(machine_hours AS REAL)),0) hours FROM production_machine_entries WHERE org_id=? AND order_id=?',(org_id,order_id)).fetchone()
    good=Decimal(order['good_units']); currency=order['currency']; std_materials=json.loads(standard['material_standards_json']); actual_by={}
    for row in actual_materials:
        agg=actual_by.setdefault(row['material_id'],[Decimal('0'),Decimal('0')])
        agg[0]+=Decimal(row['quantity']); agg[1]+=Decimal(row['total_cost'])
    material_rows=[]; mat_std_total=Decimal('0'); mat_actual_total=Decimal('0'); material_complete=True
    for item in std_materials:
        sq=Decimal(item['quantity_per_good_unit'])*good; sr=Decimal(item['standard_unit_cost']); sv=sq*sr
        actual=actual_by.get(item['material_id'])
        if actual is None:
            material_complete=False
            material_rows.append({'material_id':item['material_id'],'unit':item['unit'],'standard_quantity':str(sq),'standard_rate':str(sr),'standard_cost':str(engine.money(sv)),'actual_quantity':None,'actual_cost':None,'price_variance':None,'usage_variance':None,'status':'Actual stage consumption not recorded'})
            continue
        aq,av=actual; ar=av/aq if aq else Decimal('0')
        pv=(ar-sr)*aq; uv=(aq-sq)*sr
        mat_std_total+=sv; mat_actual_total+=av
        material_rows.append({'material_id':item['material_id'],'unit':item['unit'],'standard_quantity':str(sq),'standard_rate':str(sr),'standard_cost':str(engine.money(sv)),'actual_quantity':str(aq),'actual_rate':str(engine.money(ar)),'actual_cost':str(engine.money(av)),'price_variance':str(engine.money(pv)),'usage_variance':str(engine.money(uv)),'total_variance':str(engine.money(pv+uv)),'status':'Calculated'})
    actual_hours=Decimal(str(labor['hours'])); actual_labor=Decimal(str(labor['cost'])); std_hours=Decimal(standard['labor_hours_per_unit'])*good; std_labor_rate=Decimal(standard['labor_rate']); std_labor_cost=std_hours*std_labor_rate
    labor_complete=actual_hours>0 or std_hours==0
    if actual_hours>0:
        actual_labor_rate=actual_labor/actual_hours; labor_rate_var=(actual_labor_rate-std_labor_rate)*actual_hours; labor_eff_var=(actual_hours-std_hours)*std_labor_rate
    else: actual_labor_rate=None; labor_rate_var=None; labor_eff_var=None
    actual_overhead=Decimal(order['overhead_cost'])+sum((Decimal(r['overhead_cost']) for r in stages),Decimal('0'))
    std_overhead=Decimal(standard['overhead_per_unit'])*good
    overhead_var=actual_overhead-std_overhead
    machine_analysis=None
    if machine_standard:
        actual_machine_hours=Decimal(str(machine_actual['hours']))
        standard_machine_hours=Decimal(machine_standard['machine_hours_per_good_unit'])*good
        budgeted_machine_hours=Decimal(machine_standard['budgeted_machine_hours'])
        fixed_budget=Decimal(machine_standard['fixed_overhead_budget'])
        fixed_rate=fixed_budget/budgeted_machine_hours if budgeted_machine_hours else Decimal('0')
        efficiency_variance=(actual_machine_hours-standard_machine_hours)*fixed_rate if actual_machine_hours>0 else None
        capacity_variance=(budgeted_machine_hours-standard_machine_hours)*fixed_rate
        idle_capacity_hours=budgeted_machine_hours-actual_machine_hours
        machine_analysis={'standard_machine_hours_allowed':str(standard_machine_hours),'actual_machine_hours':str(actual_machine_hours),'budgeted_machine_hours':str(budgeted_machine_hours),'fixed_overhead_budget':str(engine.money(fixed_budget)),'fixed_overhead_rate_per_capacity_hour':str(engine.money(fixed_rate)),'machine_hour_efficiency_variance':None if efficiency_variance is None else str(engine.money(efficiency_variance)),'capacity_volume_variance':str(engine.money(capacity_variance)),'idle_capacity_hours':str(idle_capacity_hours),'capacity_utilization_percent':None if budgeted_machine_hours==0 else str((actual_machine_hours/budgeted_machine_hours*Decimal('100')).quantize(Decimal('0.01'))),'status':'Calculated' if actual_machine_hours>0 else 'Actual machine hours not recorded','interpretation':'Positive machine-hour efficiency variance means hours exceeded the standard allowed for actual good output. Capacity volume variance compares budgeted capacity hours with standard hours allowed; it is not an actual fixed-overhead spending variance. Idle hours are a capacity indicator, not automatically an accounting loss.'}
    # Favorable means actual < standard; unfavorable means actual > standard.
    material_var=(mat_actual_total-mat_std_total) if material_complete else None
    labor_var=(actual_labor-std_labor_cost) if labor_complete and actual_hours>0 else (Decimal('0') if std_hours==0 else None)
    total_var=None if material_var is None or labor_var is None else material_var+labor_var+overhead_var
    return {'order_id':order_id,'product_id':order['product_id'],'period':order['period'],'currency':currency,'standard_version':standard['version'],'good_saleable_units':str(good),'materials':material_rows,'material_variance':None if material_var is None else str(engine.money(material_var)),'labor':{'standard_hours':str(std_hours),'standard_rate':str(std_labor_rate),'standard_cost':str(engine.money(std_labor_cost)),'actual_hours':str(actual_hours),'actual_rate':None if actual_labor_rate is None else str(engine.money(actual_labor_rate)),'actual_cost':str(engine.money(actual_labor)),'rate_variance':None if labor_rate_var is None else str(engine.money(labor_rate_var)),'efficiency_variance':None if labor_eff_var is None else str(engine.money(labor_eff_var)),'total_variance':None if labor_var is None else str(engine.money(labor_var)),'status':'Calculated' if labor_complete else 'Actual labor not recorded'},'overhead':{'standard_cost':str(engine.money(std_overhead)),'actual_cost':str(engine.money(actual_overhead)),'variance':str(engine.money(overhead_var)),'machine_hours':machine_analysis},'total_variance':None if total_var is None else str(engine.money(total_var)),'interpretation':'Positive variance is unfavorable (actual cost exceeds standard); negative variance is favorable.','completeness':{'materials':material_complete,'labor':labor_complete,'overhead':'Recorded order and stage overhead only'},'notice':'Variance analysis is only as complete as posted actual stage material and labor records. Missing actual consumption is reported as unavailable, never treated as zero. The latest standard sheet is used; historical standards remain versioned.'}

@app.get('/api/v1/organizations/{org_id}/production-orders')
def list_production_orders(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT * FROM production_orders WHERE org_id=? ORDER BY created_at DESC',(org_id,)).fetchall()
    return [dict(r) for r in rows]

@app.post('/api/v1/organizations/{org_id}/production-orders/{order_id}/stages',status_code=201)
def add_production_stage(org_id:str,order_id:str,req:ProductionStageIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        order=c.execute('SELECT id,status FROM production_orders WHERE id=? AND org_id=?',(order_id,org_id)).fetchone()
        if not order: raise HTTPException(404,'Production order not found')
        if order['status']=='completed': raise HTTPException(409,'Completed production order cannot accept new stages')
        sid=uid(); t=now()
        try:
            c.execute('INSERT INTO production_stages VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(sid,org_id,order_id,req.sequence_no,req.stage_name,str(engine.money(engine.D(req.conversion_cost))),str(engine.money(engine.D(req.overhead_cost))),'planned',None,None,t,user))
        except Exception: raise HTTPException(409,'Stage sequence already exists or stage is invalid')
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','production_stage',sid,t))
    return {'id':sid,'order_id':order_id,'sequence_no':req.sequence_no,'stage_name':req.stage_name,'status':'planned'}

@app.get('/api/v1/organizations/{org_id}/production-orders/{order_id}/stages')
def list_production_stages(org_id:str,order_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        if not c.execute('SELECT 1 FROM production_orders WHERE id=? AND org_id=?',(order_id,org_id)).fetchone(): raise HTTPException(404,'Production order not found')
        rows=c.execute('SELECT * FROM production_stages WHERE org_id=? AND order_id=? ORDER BY sequence_no',(org_id,order_id)).fetchall()
    return [dict(r) for r in rows]

@app.post('/api/v1/organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/labor',status_code=201)
def record_production_labor(org_id:str,order_id:str,stage_id:str,req:ProductionLaborIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    try:
        hours=Decimal(str(req.hours)); rate=Decimal(str(req.hourly_rate))
        if not hours.is_finite() or not rate.is_finite() or hours<=0 or rate<0: raise ValueError('Invalid labor inputs')
        cost=engine.money(hours*rate)
    except Exception as e: raise HTTPException(422,'Labor hours and hourly rate must be valid finite numbers')
    with connect() as c:
        order=c.execute('SELECT currency,status FROM production_orders WHERE id=? AND org_id=?',(order_id,org_id)).fetchone()
        stage=c.execute('SELECT status,conversion_cost FROM production_stages WHERE id=? AND org_id=? AND order_id=?',(stage_id,org_id,order_id)).fetchone()
        if not order or not stage: raise HTTPException(404,'Production order or stage not found')
        if order['status']=='completed' or stage['status']!='in_progress': raise HTTPException(409,'Labor can only be recorded against an in-progress stage')
        if req.currency.upper()!=order['currency']: raise HTTPException(422,'Labor currency must match production order currency')
        lid=uid(); t=now()
        c.execute('INSERT INTO production_labor_entries VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(lid,org_id,order_id,stage_id,req.worker_code,req.work_description,str(hours),str(rate),req.currency.upper(),str(cost),req.occurred_on,t,user))
        new_conversion=engine.money(Decimal(stage['conversion_cost'])+cost)
        c.execute('UPDATE production_stages SET conversion_cost=? WHERE id=?',(str(new_conversion),stage_id))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','production_labor_entry',lid,t))
    return {'id':lid,'stage_id':stage_id,'hours':str(hours),'hourly_rate':str(rate),'labor_cost':str(cost),'stage_conversion_cost':str(new_conversion),'currency':req.currency.upper(),'notice':'Recorded labor is included in the stage conversion cost; avoid entering it again in another cost field.'}

@app.get('/api/v1/organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/labor')
def list_production_labor(org_id:str,order_id:str,stage_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        if not c.execute('SELECT 1 FROM production_stages WHERE id=? AND org_id=? AND order_id=?',(stage_id,org_id,order_id)).fetchone(): raise HTTPException(404,'Production stage not found')
        rows=c.execute('SELECT id,worker_code,work_description,hours,hourly_rate,currency,labor_cost,occurred_on,created_at FROM production_labor_entries WHERE org_id=? AND order_id=? AND stage_id=? ORDER BY created_at',(org_id,order_id,stage_id)).fetchall()
    total=sum((Decimal(r['labor_cost']) for r in rows),Decimal('0'))
    return {'entries':[dict(r) for r in rows],'total_labor_cost':str(engine.money(total)),'count':len(rows)}

@app.post('/api/v1/organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/materials',status_code=201)
def record_stage_material(org_id:str,order_id:str,stage_id:str,req:ProductionStageMaterialIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        order=c.execute('SELECT * FROM production_orders WHERE id=? AND org_id=?',(order_id,org_id)).fetchone()
        stage=c.execute('SELECT * FROM production_stages WHERE id=? AND org_id=? AND order_id=?',(stage_id,org_id,order_id)).fetchone()
        material=c.execute('SELECT * FROM raw_materials WHERE id=? AND org_id=?',(req.material_id,org_id)).fetchone()
        if not order or not stage or not material: raise HTTPException(404,'Production order, stage, or material not found')
        if order['status']=='completed' or stage['status']!='in_progress': raise HTTPException(409,'Materials can only be consumed by an in-progress stage')
        if material['currency']!=order['currency']: raise HTTPException(422,'Material currency must match production order currency')
        if material['unit']!=req.unit: raise HTTPException(422,'Material unit must match the registered inventory unit; convert explicitly before posting')
        if c.execute('SELECT 1 FROM production_stage_materials WHERE org_id=? AND reference=?',(org_id,req.reference.strip())).fetchone(): raise HTTPException(409,'Material consumption reference already used')
        valuation=_material_valuation(c,org_id,req.material_id,req.valuation_method)
        q=Decimal(str(req.quantity)); available=Decimal(valuation['quantity'])
        if q>available: raise HTTPException(422,f'Insufficient material inventory: required {q}, available {available}')
        unit_cost=Decimal(valuation['average_unit_cost'])
        if req.valuation_method=='fifo':
            events=c.execute("SELECT movement_type,quantity,unit_cost,created_at,id FROM inventory_movements WHERE org_id=? AND material_id=? ORDER BY created_at,id",(org_id,req.material_id)).fetchall(); layers=[]
            for e in events:
                eq=Decimal(e['quantity']); ec=Decimal(e['unit_cost'])
                if e['movement_type'] in ('receipt','adjustment'): layers.append([eq,ec])
                elif e['movement_type']=='issue':
                    rem=eq
                    while rem>0 and layers:
                        take=min(rem,layers[0][0]); layers[0][0]-=take; rem-=take
                        if layers[0][0]==0: layers.pop(0)
            remaining=q; issue_value=Decimal('0')
            for layer in layers:
                take=min(remaining,layer[0]); issue_value+=take*layer[1]; remaining-=take
                if remaining==0: break
            if remaining>0: raise HTTPException(409,'FIFO layers do not reconcile with available inventory')
            total_cost=engine.money(issue_value); unit_cost=issue_value/q
        else:
            total_cost=engine.money(q*unit_cost)
        t=now(); mid=uid(); ref='stage-material:'+req.reference.strip()
        c.execute('INSERT INTO inventory_movements VALUES(?,?,?,?,?,?,?,?,?,?)',(uid(),org_id,req.material_id,'issue',str(q),req.unit,str(engine.money(unit_cost)),ref,t,user))
        c.execute('INSERT INTO production_stage_materials VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(mid,org_id,order_id,stage_id,req.material_id,str(q),req.unit,req.valuation_method,str(engine.money(unit_cost)),str(total_cost),order['currency'],req.reference.strip(),t,user))
        # Once stage-level actual issues are captured, replace the BOM estimate with the accumulated actual issues.
        prior=c.execute('SELECT COALESCE(SUM(CAST(total_cost AS REAL)),0) AS total FROM production_stage_materials WHERE org_id=? AND order_id=?',(org_id,order_id)).fetchone()['total']
        new_material=engine.money(Decimal(str(prior)))
        total=engine.total_cost([new_material,order['conversion_cost'],order['overhead_cost']])
        per_unit=engine.unit_cost(total,Decimal(order['good_units']))
        c.execute('UPDATE production_orders SET material_cost=?,total_cost=?,unit_cost=? WHERE id=?',(str(new_material),str(total),str(per_unit),order_id))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','production_stage_material',mid,t))
    return {'id':mid,'stage_id':stage_id,'material_id':req.material_id,'quantity':str(q),'unit':req.unit,'valuation_method':req.valuation_method,'unit_cost':str(engine.money(unit_cost)),'total_cost':str(total_cost),'order_material_cost':str(new_material),'order_total_cost':str(total),'order_unit_cost':str(per_unit),'currency':order['currency'],'notice':'Stage material cost is included in the production order material cost. Do not duplicate it in manual cost inputs.'}

@app.get('/api/v1/organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/materials')
def list_stage_materials(org_id:str,order_id:str,stage_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        if not c.execute('SELECT 1 FROM production_stages WHERE id=? AND org_id=? AND order_id=?',(stage_id,org_id,order_id)).fetchone(): raise HTTPException(404,'Production stage not found')
        rows=c.execute('SELECT m.id,m.material_id,r.name AS material_name,m.quantity,m.unit,m.valuation_method,m.unit_cost,m.total_cost,m.currency,m.reference,m.created_at FROM production_stage_materials m JOIN raw_materials r ON r.id=m.material_id WHERE m.org_id=? AND m.order_id=? AND m.stage_id=? ORDER BY m.created_at',(org_id,order_id,stage_id)).fetchall()
    return {'entries':[dict(r) for r in rows],'total_material_cost':str(engine.money(sum((Decimal(r['total_cost']) for r in rows),Decimal('0')))),'count':len(rows)}

@app.post('/api/v1/organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/scrap',status_code=201)
def record_stage_scrap(org_id:str,order_id:str,stage_id:str,req:ProductionStageScrapIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        order=c.execute('SELECT status,product_id FROM production_orders WHERE id=? AND org_id=?',(order_id,org_id)).fetchone()
        stage=c.execute('SELECT status FROM production_stages WHERE id=? AND org_id=? AND order_id=?',(stage_id,org_id,order_id)).fetchone()
        product=c.execute('SELECT unit FROM products WHERE id=? AND org_id=?',(order['product_id'],org_id)).fetchone() if order else None
        if not order or not stage: raise HTTPException(404,'Production order or stage not found')
        if order['status']=='completed' or stage['status']!='in_progress': raise HTTPException(409,'Scrap can only be recorded against an in-progress stage')
        if product['unit']!=req.unit: raise HTTPException(422,'Scrap unit must match the finished product unit')
        sid=uid(); t=now()
        c.execute('INSERT INTO production_stage_scrap VALUES(?,?,?,?,?,?,?,?,?,?)',(sid,org_id,order_id,stage_id,str(req.scrap_units),req.unit,req.reason,req.occurred_on,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','production_stage_scrap',sid,t))
    return {'id':sid,'stage_id':stage_id,'scrap_units':str(req.scrap_units),'unit':req.unit,'reason':req.reason,'occurred_on':req.occurred_on,'notice':'Scrap is tracked separately for analysis; good saleable units and cost denominator are not automatically changed.'}

@app.get('/api/v1/organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/scrap')
def list_stage_scrap(org_id:str,order_id:str,stage_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        if not c.execute('SELECT 1 FROM production_stages WHERE id=? AND org_id=? AND order_id=?',(stage_id,org_id,order_id)).fetchone(): raise HTTPException(404,'Production stage not found')
        rows=c.execute('SELECT id,scrap_units,unit,reason,occurred_on,created_at FROM production_stage_scrap WHERE org_id=? AND order_id=? AND stage_id=? ORDER BY created_at',(org_id,order_id,stage_id)).fetchall()
    return {'entries':[dict(r) for r in rows],'total_scrap_units':str(sum((Decimal(r['scrap_units']) for r in rows),Decimal('0'))),'count':len(rows),'notice':'Scrap records are operational evidence only; they do not change the production order output quantity.'}

@app.get('/api/v1/organizations/{org_id}/production-orders/{order_id}/scrap-analysis')
def production_scrap_analysis(org_id:str,order_id:str,user:str=Depends(user_id)):
    """Return a provisional yield/cost sensitivity view; never post output changes."""
    org_access(org_id,user)
    with connect() as c:
        order=c.execute('SELECT * FROM production_orders WHERE id=? AND org_id=?',(order_id,org_id)).fetchone()
        if not order: raise HTTPException(404,'Production order not found')
        rows=c.execute("""SELECT s.id AS stage_id,s.sequence_no,s.stage_name,
            COALESCE(SUM(CAST(x.scrap_units AS REAL)),0) AS scrap_units,
            COUNT(x.id) AS scrap_entries
            FROM production_stages s LEFT JOIN production_stage_scrap x
            ON x.stage_id=s.id AND x.org_id=s.org_id
            WHERE s.org_id=? AND s.order_id=? GROUP BY s.id
            ORDER BY s.sequence_no""",(org_id,order_id)).fetchall()
        movements=c.execute("SELECT COUNT(*) n FROM finished_goods_movements WHERE org_id=? AND order_id=? AND movement_type='receipt'",(org_id,order_id)).fetchone()['n']
    planned=Decimal(order['planned_units'])
    recorded=sum((Decimal(str(r['scrap_units'])) for r in rows),Decimal('0'))
    if recorded>planned:
        raise HTTPException(409,'Recorded stage scrap exceeds planned production; reconcile stage counts before analysis')
    indicative_good=planned-recorded
    total=Decimal(order['total_cost'])
    current_good=Decimal(order['good_units'])
    stage_data=[{'stage_id':r['stage_id'],'sequence_no':r['sequence_no'],'stage_name':r['stage_name'],'scrap_units':str(Decimal(str(r['scrap_units']))),'scrap_entries':r['scrap_entries']} for r in rows]
    return {
        'order_id':order_id,'currency':order['currency'],'planned_units':str(planned),
        'currently_recorded_good_units':str(current_good),'recorded_stage_scrap_units':str(recorded),
        'indicative_good_units_if_stage_losses_are_distinct':str(indicative_good),
        'scrap_rate_of_planned_units':str((recorded/planned) if planned else Decimal('0')),
        'recorded_total_cost':str(engine.money(total)),
        'current_cost_per_recorded_good_unit':str(engine.money(total/current_good)) if current_good>0 else None,
        'indicative_cost_per_unit_after_scrap':str(engine.money(total/indicative_good)) if indicative_good>0 else None,
        'finished_goods_receipts_exist':bool(movements),'stages':stage_data,
        'status':'provisional_analysis_only',
        'limitations':['Stage scrap quantities may represent the same units at multiple stages; confirm distinct losses before summing.','The indicative yield is planned units less summed stage scrap; it does not update order good units, cost snapshots, inventory, or finished-goods receipts.','Recorded total cost is the current production-order cost and may not include unposted or separately recorded costs.']
    }

@app.patch('/api/v1/organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}')
def update_production_stage(org_id:str,order_id:str,stage_id:str,req:ProductionStageStatusIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        stage=c.execute('SELECT * FROM production_stages WHERE id=? AND org_id=? AND order_id=?',(stage_id,org_id,order_id)).fetchone()
        if not stage: raise HTTPException(404,'Production stage not found')
        if stage['status']=='completed': raise HTTPException(409,'Completed stage is immutable')
        if req.status=='completed' and stage['status']!='in_progress': raise HTTPException(409,'A stage must be started before completion')
        if req.status=='in_progress' and stage['status']!='planned': raise HTTPException(409,'Only planned stages can be started')
        if req.status=='in_progress':
            earlier=c.execute("SELECT COUNT(*) n FROM production_stages WHERE order_id=? AND sequence_no<? AND status!='completed'",(order_id,stage['sequence_no'])).fetchone()['n']
            if earlier: raise HTTPException(409,'Earlier production stages must be completed first')
        t=now(); started=stage['started_at'] or (t if req.status=='in_progress' else None); completed=t if req.status=='completed' else None
        c.execute('UPDATE production_stages SET status=?,started_at=?,completed_at=? WHERE id=?',(req.status,started,completed,stage_id))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'update','production_stage',stage_id,t))
        stage_count=c.execute('SELECT COUNT(*) n FROM production_stages WHERE order_id=?',(order_id,)).fetchone()['n']
        unfinished=c.execute("SELECT COUNT(*) n FROM production_stages WHERE order_id=? AND status!='completed'",(order_id,)).fetchone()['n']
        if stage_count and unfinished==0:
            c.execute("UPDATE production_orders SET status='completed' WHERE id=? AND org_id=?",(order_id,org_id))
        elif req.status=='in_progress':
            c.execute("UPDATE production_orders SET status='in_progress' WHERE id=? AND org_id=? AND status!='completed'",(order_id,org_id))
    return {'id':stage_id,'status':req.status,'order_status':'completed' if stage_count and unfinished==0 else ('in_progress' if req.status=='in_progress' else 'costed'),'started_at':started,'completed_at':completed}

@app.get('/api/v1/organizations/{org_id}/work-in-progress')
def work_in_progress(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        rows=c.execute("SELECT o.id AS order_id,p.name AS product,o.period,o.currency,o.status,o.material_cost,o.conversion_cost,o.overhead_cost,COALESCE(SUM(CAST(s.conversion_cost AS REAL)+CAST(s.overhead_cost AS REAL)),0) AS stage_conversion_overhead,COUNT(s.id) AS stage_count,SUM(CASE WHEN s.status='completed' THEN 1 ELSE 0 END) AS completed_stages FROM production_orders o JOIN products p ON p.id=o.product_id LEFT JOIN production_stages s ON s.order_id=o.id AND s.org_id=o.org_id WHERE o.org_id=? AND o.status!='completed' GROUP BY o.id,p.name ORDER BY o.created_at DESC",(org_id,)).fetchall()
    result=[]
    for r in rows:
        item=dict(r); item['wip_recorded_cost']=str(engine.money(engine.D(item['material_cost'])+engine.D(item['conversion_cost'])+engine.D(item['overhead_cost'])+engine.D(item['stage_conversion_overhead']))); result.append(item)
    return result

@app.post('/api/v1/organizations/{org_id}/production-orders/{order_id}/finished-goods',status_code=201)
def receive_finished_goods(org_id:str,order_id:str,req:FinishedGoodsReceiptIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    quantity=Decimal(str(req.quantity)); reference=req.reference.strip()
    with connect() as c:
        order=c.execute('SELECT o.*,p.unit FROM production_orders o JOIN products p ON p.id=o.product_id WHERE o.id=? AND o.org_id=?',(order_id,org_id)).fetchone()
        if not order: raise HTTPException(404,'Production order not found')
        if order['status']!='completed': raise HTTPException(409,'All production stages must be completed before finished goods receipt')
        received=c.execute("SELECT COALESCE(SUM(CAST(quantity AS REAL)),0) q FROM finished_goods_movements WHERE order_id=? AND movement_type='receipt'",(order_id,)).fetchone()['q']
        remaining=Decimal(order['good_units'])-Decimal(str(received))
        if quantity>remaining: raise HTTPException(422,'Receipt exceeds remaining good saleable units for this order')
        stage_costs=c.execute('SELECT COALESCE(SUM(CAST(conversion_cost AS REAL)+CAST(overhead_cost AS REAL)),0) q FROM production_stages WHERE order_id=?',(order_id,)).fetchone()['q']
        completed_total=engine.money(Decimal(order['total_cost'])+Decimal(str(stage_costs)))
        unit_cost=engine.unit_cost(completed_total,Decimal(order['good_units']))
        mid=uid(); t=now()
        c.execute('INSERT INTO finished_goods_movements VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(mid,org_id,order['product_id'],order_id,'receipt',str(quantity),order['unit'],str(unit_cost),order['currency'],reference,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','finished_goods_movement',mid,t))
    return {'id':mid,'order_id':order_id,'product_id':order['product_id'],'quantity':str(quantity),'unit':order['unit'],'unit_cost':str(unit_cost),'completed_order_cost':str(completed_total),'currency':order['currency'],'reference':reference}

@app.post('/api/v1/organizations/{org_id}/finished-goods/movements',status_code=201)
def finished_goods_issue_or_adjustment(org_id:str,req:FinishedGoodsMovementIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        product=c.execute('SELECT id,unit,currency FROM products WHERE id=? AND org_id=?',(req.product_id,org_id)).fetchone()
        if not product: raise HTTPException(404,'Product not found in this organization')
        if product['unit']!=req.unit or product['currency']!=req.currency.upper(): raise HTTPException(422,'Finished goods unit and currency must match the product')
        balance=c.execute("SELECT COALESCE(SUM(CASE movement_type WHEN 'receipt' THEN CAST(quantity AS REAL) WHEN 'issue' THEN -CAST(quantity AS REAL) ELSE CAST(quantity AS REAL) END),0) q FROM finished_goods_movements WHERE org_id=? AND product_id=?",(org_id,req.product_id)).fetchone()['q']
        if req.movement_type=='issue' and req.quantity>balance: raise HTTPException(422,'Insufficient finished goods inventory')
        mid=uid(); t=now(); cost=engine.money(engine.D(req.unit_cost))
        c.execute('INSERT INTO finished_goods_movements VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(mid,org_id,req.product_id,None,req.movement_type,str(req.quantity),req.unit,str(cost),req.currency.upper(),req.reference,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','finished_goods_movement',mid,t))
    return {'id':mid,'product_id':req.product_id,'movement_type':req.movement_type,'quantity':str(req.quantity),'unit':req.unit,'unit_cost':str(cost),'reference':req.reference}

@app.get('/api/v1/organizations/{org_id}/finished-goods')
def finished_goods_balances(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        rows=c.execute("SELECT p.id AS product_id,p.name,p.unit,p.currency,COALESCE(SUM(CASE m.movement_type WHEN 'receipt' THEN CAST(m.quantity AS REAL) WHEN 'issue' THEN -CAST(m.quantity AS REAL) ELSE CAST(m.quantity AS REAL) END),0) AS on_hand FROM products p LEFT JOIN finished_goods_movements m ON m.product_id=p.id AND m.org_id=p.org_id WHERE p.org_id=? GROUP BY p.id,p.name,p.unit,p.currency ORDER BY p.name",(org_id,)).fetchall()
    return [dict(r) for r in rows]

@app.post('/api/v1/organizations/{org_id}/finished-goods/stocktake',status_code=201)
def finished_goods_stocktake(org_id:str,req:FinishedGoodsStocktakeIn,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        product=c.execute('SELECT id,unit,currency FROM products WHERE id=? AND org_id=?',(req.product_id,org_id)).fetchone()
        if not product: raise HTTPException(404,'Product not found in this organization')
        if product['unit']!=req.unit or product['currency']!=req.currency.upper(): raise HTTPException(422,'Stocktake unit and currency must match the product')
        raw=c.execute("SELECT COALESCE(SUM(CASE movement_type WHEN 'receipt' THEN CAST(quantity AS REAL) WHEN 'issue' THEN -CAST(quantity AS REAL) ELSE CAST(quantity AS REAL) END),0) q FROM finished_goods_movements WHERE org_id=? AND product_id=?",(org_id,req.product_id)).fetchone()['q']
        balance=Decimal(str(raw)); counted=Decimal(str(req.counted_quantity)); delta=counted-balance
        if delta==0: return {'product_id':req.product_id,'book_quantity':str(balance),'counted_quantity':str(counted),'difference':'0','movement_id':None,'notice':'No adjustment required; physical count matches recorded quantity.'}
        movement_type='adjustment' if delta>0 else 'issue'; quantity=abs(delta)
        mid=uid(); t=now(); cost=engine.money(engine.D(req.unit_cost)); ref='stocktake:'+req.reference.strip()
        if c.execute('SELECT 1 FROM finished_goods_movements WHERE org_id=? AND reference=?',(org_id,ref)).fetchone(): raise HTTPException(409,'Stocktake reference already used')
        c.execute('INSERT INTO finished_goods_movements VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(mid,org_id,req.product_id,None,movement_type,str(quantity),req.unit,str(cost),req.currency.upper(),ref,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','finished_goods_stocktake',mid,t))
        return {'product_id':req.product_id,'book_quantity':str(balance),'counted_quantity':str(counted),'difference':str(delta),'movement_type':movement_type,'quantity':str(quantity),'movement_id':mid,'reference':ref,'notes':req.notes,'created_at':t,'notice':'Stocktake posted as a signed difference; negative differences consume inventory layers during valuation replay.'}

def _finished_goods_valuation(c, org_id: str, product_id: str, method: str):
    events=c.execute("SELECT movement_type,quantity,unit_cost,created_at,id FROM finished_goods_movements WHERE org_id=? AND product_id=? ORDER BY created_at,id",(org_id,product_id)).fetchall()
    qty=Decimal('0'); value=Decimal('0'); layers=[]
    for e in events:
        q=Decimal(e['quantity']); cost=Decimal(e['unit_cost'])
        if e['movement_type'] in ('receipt','adjustment'):
            qty+=q; value+=q*cost
            if method=='fifo': layers.append([q,cost])
        elif e['movement_type']=='issue':
            if q>qty: raise HTTPException(409,'Historical finished-goods movements contain a negative-stock sequence; reconcile before valuation')
            if method=='weighted_average':
                avg=value/qty if qty else Decimal('0')
                value-=q*avg
            else:
                remaining=q; issue_value=Decimal('0')
                while remaining>0 and layers:
                    take=min(remaining,layers[0][0]); issue_value+=take*layers[0][1]
                    layers[0][0]-=take; remaining-=take
                    if layers[0][0]==0: layers.pop(0)
                if remaining>0: raise HTTPException(409,'Finished-goods FIFO layers do not reconcile with inventory quantity')
                value-=issue_value
            qty-=q
    if qty==0: value=Decimal('0')
    avg=value/qty if qty else Decimal('0')
    return {'quantity':str(qty),'inventory_value':str(engine.money(value)),'average_unit_cost':str(engine.money(avg))}

@app.get('/api/v1/organizations/{org_id}/finished-goods/valuation')
def finished_goods_valuation(org_id:str,method:Literal['fifo','weighted_average']='weighted_average',user:str=Depends(user_id)):
    org_access(org_id,user)
    result=[]
    with connect() as c:
        products=c.execute('SELECT id,name,unit,currency FROM products WHERE org_id=? ORDER BY name',(org_id,)).fetchall()
        for p in products:
            v=_finished_goods_valuation(c,org_id,p['id'],method)
            result.append({'product_id':p['id'],'name':p['name'],'unit':p['unit'],'currency':p['currency'],'method':method,**v})
    return {'method':method,'items':result,'notice':'Valuation is reconstructed from recorded finished-goods movements in timestamp order. Adjustment movements are treated as positive incoming layers. Production receipts use recorded order cost per good saleable unit. Verify historical completeness and reconcile stock before financial reporting.'}

@app.get('/api/v1/organizations/{org_id}/subscription')
def subscription(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: r=c.execute('SELECT trial_started_at,trial_ends_at,status,payment_status FROM subscriptions WHERE org_id=?',(org_id,)).fetchone()
    if not r: raise HTTPException(404,'Subscription record not found')
    expired=datetime.fromisoformat(r['trial_ends_at'])<=datetime.now(timezone.utc)
    return {**dict(r),'effective_status':'expired' if expired and r['status']=='trial' else r['status'],'server_time':now(),'payment_enabled':False}

@app.post('/api/v1/costs/total')
def calculate_total(req:dict):
    try: return {'total_cost':str(engine.total_cost(req.get('components',[]))),'model_version':engine.MODEL_VERSION}
    except engine.FinancialInputError as e: raise HTTPException(422,str(e))

@app.post('/api/v1/costs/unit')
def calculate_unit(req:dict):
    try: return {'unit_cost':str(engine.unit_cost(req.get('total_allocated_cost'),req.get('good_saleable_units'))),'model_version':engine.MODEL_VERSION}
    except engine.FinancialInputError as e: raise HTTPException(422,str(e))

@app.post('/api/v1/analysis/break-even-units')
def calculate_break_even(req:dict):
    try: return {'break_even_units':str(engine.break_even_units(req.get('fixed_costs'),req.get('selling_price'),req.get('variable_cost_per_unit'))),'model_version':engine.MODEL_VERSION}
    except engine.FinancialInputError as e: raise HTTPException(422,str(e))

@app.post('/api/v1/analysis/target-price')
def target_price(req:dict):
    try:
        basis=req.get('basis','margin')
        if basis=='margin': value=engine.target_price_by_margin(req.get('unit_cost'),req.get('target_rate'))
        elif basis=='markup': value=engine.target_price_by_markup(req.get('unit_cost'),req.get('target_rate'))
        else: raise HTTPException(422,'basis must be margin or markup')
        return {'target_price':str(value),'basis':basis,'model_version':engine.MODEL_VERSION}
    except engine.FinancialInputError as e: raise HTTPException(422,str(e))

@app.post('/api/v1/analysis/profitability')
def profitability(req:dict):
    try:
        profit=engine.profit_per_unit(req.get('selling_price'),req.get('unit_cost'))
        return {'profit_per_unit':str(profit),'margin':str(engine.margin(profit,req.get('selling_price'))),'markup':str(engine.markup(profit,req.get('unit_cost'))),'model_version':engine.MODEL_VERSION}
    except engine.FinancialInputError as e: raise HTTPException(422,str(e))

# Reporting/export endpoints. Exports are generated from the authenticated
# organization's persisted records only; spreadsheet formula prefixes are neutralized.
from fastapi.responses import StreamingResponse, JSONResponse
from io import StringIO
import csv

def _csv_safe(value):
    if value is None: return ''
    value=str(value)
    if value.startswith(('=','+','-','@','\t','\r')): return "'"+value
    return value

def _csv_response(filename, headers, rows):
    stream=StringIO(newline='')
    writer=csv.writer(stream, lineterminator='\r\n')
    writer.writerow(headers)
    for row in rows: writer.writerow([_csv_safe(v) for v in row])
    payload='\ufeff'+stream.getvalue()
    return StreamingResponse(iter([payload]),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="{filename}"','Cache-Control':'no-store'})



# Safe product CSV import: preview is read-only; commit is a separate explicit action.
_PRODUCT_IMPORT_HEADERS = ['name','sku','unit','currency']
_CSV_FORMULA_PREFIXES = ('=', '+', '-', '@', '\t', '\r')

def _parse_product_import_csv(payload:str):
    if len(payload.encode('utf-8')) > 2_000_000:
        raise HTTPException(413, 'CSV file exceeds the 2 MB import limit')
    try:
        reader=csv.DictReader(StringIO(payload, newline=''), strict=True)
        if reader.fieldnames is None:
            raise HTTPException(422, 'CSV header row is required')
        headers=[(h or '').strip().lower() for h in reader.fieldnames]
        if headers != _PRODUCT_IMPORT_HEADERS:
            raise HTTPException(422, 'CSV columns must be exactly: name,sku,unit,currency (in that order)')
        rows=[]
        for line_no,row in enumerate(reader,start=2):
            if len(rows)>=500:
                raise HTTPException(413, 'CSV import is limited to 500 data rows')
            if None in row:
                raise HTTPException(422, f'Row {line_no}: too many columns')
            values={k:(row.get(k) or '').strip() for k in _PRODUCT_IMPORT_HEADERS}
            if not any(values.values()):
                continue
            for key,value in values.items():
                if value.startswith(_CSV_FORMULA_PREFIXES):
                    raise HTTPException(422, f'Row {line_no}: formula-like value is not allowed in {key}')
            if not values['name'] or not values['unit']:
                raise HTTPException(422, f'Row {line_no}: name and unit are required')
            if len(values['name'])>180 or len(values['unit'])>30 or len(values['sku'])>80:
                raise HTTPException(422, f'Row {line_no}: a field exceeds its maximum length')
            currency=values['currency'].upper() or 'SDG'
            if len(currency)!=3 or not currency.isalpha() or not currency.isascii():
                raise HTTPException(422, f'Row {line_no}: currency must be a 3-letter code')
            rows.append({'name':values['name'],'sku':values['sku'] or None,'unit':values['unit'],'currency':currency,'source_row':line_no})
        return rows
    except csv.Error as exc:
        raise HTTPException(422, f'Invalid CSV structure: {exc}')

def _parse_product_import_xlsx(encoded:str):
    try:
        raw=base64.b64decode(encoded,validate=True)
    except (binascii.Error,ValueError):
        raise HTTPException(422,'Invalid base64-encoded XLSX file')
    if len(raw)>2_000_000:
        raise HTTPException(413,'XLSX import is limited to 2 MB')
    try:
        from openpyxl import load_workbook
        from io import BytesIO
        wb=load_workbook(BytesIO(raw),read_only=True,data_only=False)
        if len(wb.sheetnames)!=1:
            raise HTTPException(422,'XLSX must contain exactly one worksheet')
        ws=wb[wb.sheetnames[0]]
        iterator=ws.iter_rows(values_only=False)
        header_cells=next(iterator,None)
        if not header_cells:
            raise HTTPException(422,'XLSX header row is required')
        headers=[str(c.value or '').strip().lower() for c in header_cells]
        while headers and headers[-1]=='': headers.pop()
        if headers!=_PRODUCT_IMPORT_HEADERS:
            raise HTTPException(422,'XLSX columns must be exactly: name,sku,unit,currency (in that order)')
        rows=[]
        for line_no,cells in enumerate(iterator,start=2):
            if len(rows)>=500: raise HTTPException(413,'XLSX import is limited to 500 data rows')
            cells=list(cells[:4])
            values={k:(str(cells[i].value).strip() if i<len(cells) and cells[i].value is not None else '') for i,k in enumerate(_PRODUCT_IMPORT_HEADERS)}
            if any(c.data_type=='f' for c in cells): raise HTTPException(422,f'Row {line_no}: formulas are not allowed')
            if not any(values.values()): continue
            for key,value in values.items():
                if value.startswith(_CSV_FORMULA_PREFIXES): raise HTTPException(422,f'Row {line_no}: formula-like value is not allowed in {key}')
            if not values['name'] or not values['unit']: raise HTTPException(422,f'Row {line_no}: name and unit are required')
            if len(values['name'])>180 or len(values['unit'])>30 or len(values['sku'])>80: raise HTTPException(422,f'Row {line_no}: a field exceeds its maximum length')
            currency=values['currency'].upper() or 'SDG'
            if len(currency)!=3 or not currency.isalpha() or not currency.isascii(): raise HTTPException(422,f'Row {line_no}: currency must be a 3-letter code')
            rows.append({'name':values['name'],'sku':values['sku'] or None,'unit':values['unit'],'currency':currency,'source_row':line_no})
        wb.close()
        if not rows: raise HTTPException(422,'XLSX contains no product rows')
        return rows
    except HTTPException: raise
    except Exception as exc:
        raise HTTPException(422,f'Unable to read XLSX workbook: {type(exc).__name__}')

@app.post('/api/v1/organizations/{org_id}/imports/products/xlsx/preview')
def preview_product_xlsx_import(org_id:str,req:ProductXlsxImportPreview,user:str=Depends(user_id)):
    org_access(org_id,user)
    rows=_parse_product_import_xlsx(req.xlsx_base64)
    seen=set(); issues=[]
    with connect() as c:
        existing={r['sku'].casefold() for r in c.execute('SELECT sku FROM products WHERE org_id=? AND sku IS NOT NULL AND sku<>""',(org_id,)).fetchall()}
    for row in rows:
        sku=row['sku']
        if sku:
            key=sku.casefold()
            if key in existing: issues.append({'row':row['source_row'],'field':'sku','message':'SKU already exists in this organization'})
            elif key in seen: issues.append({'row':row['source_row'],'field':'sku','message':'Duplicate SKU within this file'})
            seen.add(key)
    return {'import_type':'products_xlsx','row_count':len(rows),'valid':not issues,'issues':issues,'rows':rows,'notice':'Preview only. No records were created. Use the existing explicit commit endpoint after reviewing the rows.'}

@app.post('/api/v1/organizations/{org_id}/imports/products/preview')
def preview_product_import(org_id:str,req:ProductImportPreview,user:str=Depends(user_id)):
    org_access(org_id,user)
    rows=_parse_product_import_csv(req.csv_text)
    seen=set(); issues=[]
    with connect() as c:
        existing={r['sku'].casefold() for r in c.execute('SELECT sku FROM products WHERE org_id=? AND sku IS NOT NULL AND sku<>""',(org_id,)).fetchall()}
    for row in rows:
        sku=row['sku']
        if sku:
            key=sku.casefold()
            if key in existing:
                issues.append({'row':row['source_row'],'field':'sku','message':'SKU already exists in this organization'})
            elif key in seen:
                issues.append({'row':row['source_row'],'field':'sku','message':'Duplicate SKU within this file'})
            seen.add(key)
    return {'import_type':'products','row_count':len(rows),'valid':not issues and bool(rows),'issues':issues,'rows':rows,'notice':'Preview only. No records were created. Confirm with the separate commit endpoint after reviewing the rows.'}

@app.post('/api/v1/organizations/{org_id}/imports/products/commit',status_code=201)
def commit_product_import(org_id:str,req:ProductImportCommit,user:str=Depends(user_id)):
    org_access(org_id,user,True); require_active_subscription(org_id)
    rows=[r.model_dump() for r in req.rows]
    seen=set()
    for index,row in enumerate(rows,start=1):
        row['currency']=row['currency'].upper()
        for key in ('name','sku','unit'):
            value=row.get(key) or ''
            if value.startswith(_CSV_FORMULA_PREFIXES):
                raise HTTPException(422,f'Row {index}: formula-like value is not allowed in {key}')
        if len(row['currency'])!=3 or not row['currency'].isalpha() or not row['currency'].isascii():
            raise HTTPException(422,f'Row {index}: currency must be a 3-letter code')
        if row.get('sku'):
            sku=row['sku'].casefold()
            if sku in seen: raise HTTPException(422,f'Row {index}: duplicate SKU within import')
            seen.add(sku)
    created=[]; timestamp=now()
    try:
        with connect() as c:
            existing={r['sku'].casefold() for r in c.execute('SELECT sku FROM products WHERE org_id=? AND sku IS NOT NULL AND sku<>""',(org_id,)).fetchall()}
            conflict=existing & seen
            if conflict: raise HTTPException(409,'One or more SKUs already exist in this organization; nothing was imported')
            for row in rows:
                pid=uid()
                c.execute('INSERT INTO products VALUES(?,?,?,?,?,?,?)',(pid,org_id,row['name'],row.get('sku') or None,row['unit'],row['currency'],timestamp))
                created.append({'id':pid,'name':row['name'],'sku':row.get('sku') or None,'unit':row['unit'],'currency':row['currency']})
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(409,'Import failed; transaction rolled back. Check SKU uniqueness and retry after correcting the file.')
    return {'imported_count':len(created),'products':created,'notice':'Products were imported atomically. No costs or inventory balances were created.'}

@app.get('/api/v1/organizations/{org_id}/reports/costing.csv')
def export_costing_csv(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        rows=c.execute('SELECT s.id,p.name,s.period,s.currency,s.inputs_json,s.results_json,s.formula_version,s.created_at FROM cost_snapshots s JOIN products p ON p.id=s.product_id WHERE s.org_id=? ORDER BY s.created_at DESC',(org_id,)).fetchall()
    output=[]
    for r in rows:
        inp=json.loads(r['inputs_json']); result=json.loads(r['results_json'])
        output.append((r['id'],r['name'],r['period'],r['currency'],json.dumps(inp.get('components',{}),ensure_ascii=False),inp.get('good_saleable_units',''),inp.get('selling_price',''),result.get('total_cost',''),result.get('unit_cost',''),result.get('profit_per_unit',''),result.get('total_profit',''),result.get('margin',''),result.get('markup',''),r['formula_version'],r['created_at']))
    return _csv_response('fvg-costing-report.csv',['snapshot_id','product','period','currency','cost_components_json','good_saleable_units','selling_price','total_cost','unit_cost','profit_per_unit','total_profit','margin','markup','formula_version','created_at'],output)

@app.get('/api/v1/organizations/{org_id}/reports/research.json')
def export_research_report(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        tables={
          'evidence':('SELECT id,title,status,source_ref,notes,created_at FROM research_evidence WHERE org_id=? ORDER BY created_at',(org_id,)),
          'establishments':('SELECT id,pseudonym,sector,region,participation_status,notes,created_at FROM research_establishments WHERE org_id=? ORDER BY created_at',(org_id,)),
          'permissions':('SELECT id,establishment_id,permission_type,permission_status,reference,valid_from,valid_until,notes,created_at FROM research_permissions WHERE org_id=? ORDER BY created_at',(org_id,)),
          'interactions':('SELECT id,establishment_id,interaction_type,participant_code,occurred_on,permission_id,record_status,notes,created_at FROM research_interactions WHERE org_id=? ORDER BY occurred_on',(org_id,)),
          'hypotheses':('SELECT id,statement,status,evidence_refs_json,notes,created_at,updated_at FROM research_hypotheses WHERE org_id=? ORDER BY created_at',(org_id,)),
          'data_dictionary':('SELECT id,variable_name,definition,data_type,unit,allowed_values,sensitivity,created_at FROM research_dictionary WHERE org_id=? ORDER BY variable_name',(org_id,)),
          'instruments':('SELECT id,title,instrument_type,version,fields_json,status,created_at FROM research_instruments WHERE org_id=? ORDER BY title,version',(org_id,)),
          'responses':('SELECT id,instrument_id,interaction_id,response_json,review_status,created_at FROM research_responses WHERE org_id=? ORDER BY created_at',(org_id,)),
          'cleaning_logs':('SELECT id,response_id,variable_name,issue_type,action_taken,outcome,reviewer_note,created_at FROM research_cleaning_logs WHERE org_id=? ORDER BY created_at',(org_id,))
        }
        data={}
        for name,(sql,args) in tables.items():
            data[name]=[dict(row) for row in c.execute(sql,args).fetchall()]
    for row in data['hypotheses']:
        row['evidence_refs']=json.loads(row.pop('evidence_refs_json'))
    for row in data['instruments']:
        row['fields']=json.loads(row.pop('fields_json'))
    for row in data['responses']:
        row['response']=json.loads(row.pop('response_json'))
    return JSONResponse({'report_type':'FVG research workspace export','organization_id':org_id,'generated_at':now(),'notice':'Research workspace records only. This export does not assert findings. Verify permissions, consent, anonymization and evidence before external publication.','data':data},headers={'Content-Disposition':'attachment; filename="fvg-research-workspace.json"','Cache-Control':'no-store'})

@app.get('/api/v1/organizations/{org_id}/reports/production.csv')
def export_production_csv(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c:
        rows=c.execute('SELECT o.id,p.name,o.period,o.planned_units,o.good_units,o.currency,o.material_cost,o.conversion_cost,o.overhead_cost,o.total_cost,o.unit_cost,o.status,o.created_at FROM production_orders o JOIN products p ON p.id=o.product_id WHERE o.org_id=? ORDER BY o.created_at DESC',(org_id,)).fetchall()
    return _csv_response('fvg-production-cost-report.csv',['order_id','product','period','planned_units','good_saleable_units','currency','material_cost','conversion_cost','overhead_cost','total_cost','unit_cost','status','created_at'],[tuple(r) for r in rows])

# XLSX/PDF exports. Optional libraries are declared in requirements; failures
# are explicit rather than silently returning a different format.
from io import BytesIO
from fastapi.responses import Response

@app.get('/api/v1/organizations/{org_id}/reports/costing.xlsx')
def export_costing_xlsx(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
    except ImportError: raise HTTPException(503,'Excel export dependency is not installed')
    with connect() as c:
        rows=c.execute('SELECT s.id,p.name,s.period,s.currency,s.inputs_json,s.results_json,s.formula_version,s.created_at FROM cost_snapshots s JOIN products p ON p.id=s.product_id WHERE s.org_id=? ORDER BY s.created_at DESC',(org_id,)).fetchall()
    wb=Workbook(); ws=wb.active; ws.title='Costing'
    headers=['Snapshot ID','Product','Period','Currency','Cost components','Good units','Selling price','Total cost','Unit cost','Profit per unit','Total profit','Margin','Markup','Formula version','Created at']
    ws.append(headers)
    for r in rows:
        inp=json.loads(r['inputs_json']); out=json.loads(r['results_json'])
        ws.append([r['id'],r['name'],r['period'],r['currency'],json.dumps(inp.get('components',{}),ensure_ascii=False),inp.get('good_saleable_units',''),inp.get('selling_price',''),out.get('total_cost',''),out.get('unit_cost',''),out.get('profit_per_unit',''),out.get('total_profit',''),out.get('margin',''),out.get('markup',''),r['formula_version'],r['created_at']])
    ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
    for cell in ws[1]: cell.font=Font(bold=True,color='FFFFFF'); cell.fill=PatternFill('solid',fgColor='15423A'); cell.alignment=Alignment(wrap_text=True)
    for col in ws.columns:
        width=min(max(max(len(str(x.value or '')) for x in col)+2,12),42); ws.column_dimensions[get_column_letter(col[0].column)].width=width
    bio=BytesIO(); wb.save(bio)
    return Response(bio.getvalue(),media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',headers={'Content-Disposition':'attachment; filename="fvg-costing-report.xlsx"','Cache-Control':'no-store'})

@app.get('/api/v1/organizations/{org_id}/reports/costing.pdf')
def export_costing_pdf(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
    except ImportError: raise HTTPException(503,'PDF export dependency is not installed')
    with connect() as c:
        rows=c.execute('SELECT p.name,s.period,s.currency,s.results_json,s.created_at FROM cost_snapshots s JOIN products p ON p.id=s.product_id WHERE s.org_id=? ORDER BY s.created_at DESC',(org_id,)).fetchall()
    buf=BytesIO(); doc=SimpleDocTemplate(buf,pagesize=landscape(A4),rightMargin=24,leftMargin=24,topMargin=24,bottomMargin=24)
    styles=getSampleStyleSheet(); story=[Paragraph('FVG — Costing Report',styles['Title']),Paragraph('Organization-scoped saved cost snapshots. Values are taken from stored calculation records; no missing data is estimated.',styles['BodyText']),Spacer(1,12)]
    data=[['Product','Period','Currency','Total cost','Unit cost','Profit / unit','Total profit','Margin','Markup','Created']]
    for r in rows:
        out=json.loads(r['results_json']); data.append([str(r['name']),str(r['period']),str(r['currency']),str(out.get('total_cost','')),str(out.get('unit_cost','')),str(out.get('profit_per_unit','')),str(out.get('total_profit','')),str(out.get('margin','')),str(out.get('markup','')),str(r['created_at'])[:19]])
    if len(data)==1: data.append(['No saved records','','','','','','','','',''])
    table=Table(data,repeatRows=1)
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#15423A')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#DCD7C8')),('FONTSIZE',(0,0),(-1,-1),7),('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#FAF2E8')])]))
    story.append(table); doc.build(story)
    return Response(buf.getvalue(),media_type='application/pdf',headers={'Content-Disposition':'attachment; filename="fvg-costing-report.pdf"','Cache-Control':'no-store'})


# Research instruments and immutable raw field responses
@app.post('/api/v1/organizations/{org_id}/research/instruments',status_code=201)
def create_research_instrument(org_id:str,req:ResearchInstrumentIn,user:str=Depends(user_id)):
    org_access(org_id,user,write=True); require_active_subscription(org_id)
    names=[]
    for field in req.fields:
        if not isinstance(field,dict) or not isinstance(field.get('name'),str) or not field['name'].strip(): raise HTTPException(422,'Every instrument field needs a non-empty name')
        if field.get('type') not in ('text','integer','decimal','date','boolean','category'): raise HTTPException(422,'Unsupported instrument field type')
        if field['name'] in names: raise HTTPException(422,'Duplicate instrument field name')
        names.append(field['name'])
    iid=uid(); t=now()
    with connect() as c:
        version=c.execute('SELECT COALESCE(MAX(version),0)+1 v FROM research_instruments WHERE org_id=? AND title=?',(org_id,req.title)).fetchone()['v']
        c.execute('INSERT INTO research_instruments VALUES(?,?,?,?,?,?,?,?,?)',(iid,org_id,req.title,req.instrument_type,version,json.dumps(req.fields,ensure_ascii=False),'active' if req.status=='active' else 'draft',t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','research_instrument',iid,t))
    return {'id':iid,'title':req.title,'instrument_type':req.instrument_type,'version':version,'fields':req.fields,'status':req.status}

@app.get('/api/v1/organizations/{org_id}/research/instruments')
def list_research_instruments(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,title,instrument_type,version,fields_json,status,created_at FROM research_instruments WHERE org_id=? ORDER BY title,version DESC',(org_id,)).fetchall()
    return [{**dict(r),'fields':json.loads(r['fields_json'])} for r in rows]

@app.post('/api/v1/organizations/{org_id}/research/responses',status_code=201)
def create_research_response(org_id:str,req:ResearchResponseIn,user:str=Depends(user_id)):
    org_access(org_id,user,write=True); require_active_subscription(org_id)
    with connect() as c:
        instrument=c.execute("SELECT * FROM research_instruments WHERE id=? AND org_id=? AND status='active'",(req.instrument_id,org_id)).fetchone()
        interaction=c.execute('SELECT * FROM research_interactions WHERE id=? AND org_id=?',(req.interaction_id,org_id)).fetchone()
        if not instrument or not interaction: raise HTTPException(404,'Active instrument or interaction not found in this organization')
        if instrument['instrument_type']!=interaction['interaction_type']: raise HTTPException(422,'Instrument type must match the recorded interaction type')
        fields=json.loads(instrument['fields_json']); allowed={f['name']:f for f in fields}
        unknown=set(req.response)-set(allowed)
        if unknown: raise HTTPException(422,'Response contains fields not defined in the instrument')
        for name,f in allowed.items():
            value=req.response.get(name)
            if f.get('required') and (value is None or value==''): raise HTTPException(422,f'Required response missing: {name}')
            if value is not None:
                typ=f['type']
                valid=(isinstance(value,str) if typ in ('text','date','category') else isinstance(value,bool) if typ=='boolean' else isinstance(value,int) and not isinstance(value,bool) if typ=='integer' else isinstance(value,(int,float)) and not isinstance(value,bool))
                if not valid: raise HTTPException(422,f'Invalid value type for {name}')
                choices=f.get('allowed_values') or []
                if choices and value not in choices: raise HTTPException(422,f'Value not allowed for {name}')
        rid=uid(); t=now()
        c.execute('INSERT INTO research_responses VALUES(?,?,?,?,?,?,?,?)',(rid,org_id,req.instrument_id,req.interaction_id,json.dumps(req.response,ensure_ascii=False,allow_nan=False),req.review_status,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','research_response',rid,t))
    return {'id':rid,'review_status':req.review_status,'notice':'Raw response preserved unchanged. Cleaning actions are separate and do not overwrite source responses.'}

@app.get('/api/v1/organizations/{org_id}/research/responses')
def list_research_responses(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,instrument_id,interaction_id,response_json,review_status,created_at FROM research_responses WHERE org_id=? ORDER BY created_at DESC',(org_id,)).fetchall()
    return [{**dict(r),'response':json.loads(r['response_json'])} for r in rows]

@app.post('/api/v1/organizations/{org_id}/research/responses/{response_id}/cleaning-log',status_code=201)
def create_research_cleaning_log(org_id:str,response_id:str,req:ResearchCleaningIn,user:str=Depends(user_id)):
    org_access(org_id,user,write=True); require_active_subscription(org_id)
    with connect() as c:
        response=c.execute('SELECT id,response_json FROM research_responses WHERE id=? AND org_id=?',(response_id,org_id)).fetchone()
        if not response: raise HTTPException(404,'Research response not found')
        raw=json.loads(response['response_json'])
        if req.variable_name not in raw: raise HTTPException(422,'Variable is not present in the original response')
        lid=uid(); t=now()
        c.execute('INSERT INTO research_cleaning_logs VALUES(?,?,?,?,?,?,?,?,?,?)',(lid,org_id,response_id,req.variable_name,req.issue_type,req.action_taken,req.outcome,req.reviewer_note,t,user))
        c.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?,?)',(uid(),org_id,user,'create','research_cleaning_log',lid,t))
    return {'id':lid,'response_id':response_id,'outcome':req.outcome,'notice':'Cleaning log recorded separately; immutable raw response was not modified.'}

@app.get('/api/v1/organizations/{org_id}/research/cleaning-logs')
def list_research_cleaning_logs(org_id:str,user:str=Depends(user_id)):
    org_access(org_id,user)
    with connect() as c: rows=c.execute('SELECT id,response_id,variable_name,issue_type,action_taken,outcome,reviewer_note,created_at FROM research_cleaning_logs WHERE org_id=? ORDER BY created_at DESC',(org_id,)).fetchall()
    return [dict(r) for r in rows]
