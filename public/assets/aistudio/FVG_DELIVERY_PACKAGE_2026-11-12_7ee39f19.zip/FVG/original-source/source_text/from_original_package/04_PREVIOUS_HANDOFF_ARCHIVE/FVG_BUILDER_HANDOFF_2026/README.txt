# FVG Builder Handoff Package

This package is the **clean, implementation-focused specification** for Financial Vision Guide. It replaces the earlier approach of making the builder sift through a large merged document with repeated appendices.

## Start here
Open `00_READ_FIRST_HANDOFF.md`, then follow the reading order listed there. The other files define the product, financial logic, research integrity, visual design, architecture/security, acceptance tests, and asset/deployment requirements.

## Important
The package also includes the supplied researcher portrait in `assets/`; it does not include product/factory assets that were not verified as available.

This ZIP contains requirements, not a prebuilt implementation. Claude Code or Verdent must use the specification to inspect the actual project/assets, implement the system, run tests and report the real result. A specification cannot prove a feature is already working.

## Package contents
- `00_READ_FIRST_HANDOFF.md` — builder instructions and project identity
- `01_PRODUCT_AND_FUNCTIONAL_SPEC.md` — pages, roles, workflows and features
- `02_FINANCIAL_ENGINE_SPEC.md` — formulas and accounting decision tools
- `03_NOBO_RESEARCH_SPEC.md` — research method, data integrity and ethics
- `04_UI_UX_AND_CONTENT_SPEC.md` — brand, layout, accessibility and approved About copy
- `05_TECHNICAL_SECURITY_SPEC.md` — architecture, authorization, integrations and security
- `06_TESTING_ACCEPTANCE_AND_TRACEABILITY.md` — tests and completion evidence
- `07_ASSETS_AND_DEPLOYMENT.md` — asset rules, delivery and hosting
- `DECISIONS_AND_BLOCKERS.md` — canonical choices and unresolved dependencies
- `MANIFEST.sha256` — integrity hashes for package documents

## Suggested use
1. Extract this ZIP into the project workspace.
2. Copy the real project assets into a dedicated `assets/` folder without altering originals.
3. Ask the builder to read all documents before coding and inventory the existing repository.
4. Have the builder create `REQUIREMENTS_TRACEABILITY.md` and `ASSET_REGISTRY.md` from the templates/rules here.
5. Implement in small phases, run tests after each phase, and keep a clear blocker list.
