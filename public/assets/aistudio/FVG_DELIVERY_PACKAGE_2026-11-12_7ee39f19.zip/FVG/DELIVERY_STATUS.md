# FVG Delivery Status — 2026-11-11

## Latest increment
Arabic/English inventory and WIP frontend workflows were added for raw-material balances, physical stocktake, inventory valuation, WIP cost listing, finished-goods balances, finished-goods stocktake and finished-goods issue. Manual inventory movement writes now acquire SQLite `BEGIN IMMEDIATE` before checking balances and inserting movements.

## Implemented in this increment
- Inventory balances table for raw materials.
- Physical stocktake UI for raw materials, posting signed differences through the existing API.
- FIFO and moving weighted-average valuation UI for raw materials.
- WIP order list with stage progress and recorded cost.
- Finished-goods balances, stocktake and issue UI.
- FIFO and moving weighted-average finished-goods valuation UI.
- Initial organization data loading uses the newly issued session token rather than stale React state.
- Raw-material creation supports zero opening quantity without attempting a zero-quantity receipt.
- Explicit notice that the manually entered finished-goods issue unit cost is a movement reference; valuation reconstructs costs from history.
- SQLite write locking (`BEGIN IMMEDIATE`) around raw-material and finished-goods movement balance-check/write flows.

## Verification
- Backend test suite: **58 passed**.
- `python -m py_compile app/*.py`: passed.
- TypeScript `transpileModule` TSX/JSX syntax diagnostics: **0**.
- ZIP integrity will be checked for this delivery.

## Important limitations
- `npm install --no-audit --no-fund` timed out. React/Vite dependency-backed type-check and production build are not verified; browser E2E, accessibility and cross-browser tests are not run.
- No concurrency stress/load test was run; SQLite write locking is a targeted race mitigation, not production concurrency certification.
- Finished-goods issue cost entered in the form is not the authoritative FIFO/weighted-average cost; valuation replay reconstructs that cost from historical movements.
- Finished-goods receipt is still initiated by completed production-order receipt API; a dedicated UI receipt action is not yet provided.
- WIP and inventory screens are basic operational views, not a complete warehouse management system. Lots/expiry, multi-warehouse, returns, rework, full count-session approval and stock valuation accounting journals remain incomplete.
- Standard-vs-actual variance, scrap analysis, machine-hour capacity and production stage capture remain limited as described in `docs/KNOWN_LIMITATIONS.md`.
- Security review, backup/restore drill, production database, deployment and live release remain outstanding.

This is a development increment, not a final or production-ready release.

## Latest increment — Production stage capture and finished-goods receipt UI
- Added bilingual stage-level material consumption controls. The form uses registered material unit, selected FIFO or moving weighted-average valuation, and a unique generated reference; the backend validates stage status, stock, currency, unit, and duplicate reference.
- Added bilingual scrap entry controls tied to the production order's actual product unit, with required reason and date.
- Added a scrap-analysis action and summary display, preserving the backend's limitations about potentially repeated losses across stages and not automatically changing good units.
- Added a finished-goods receipt action tied to the selected production order. The interface disables it unless the order is completed; backend validation remains authoritative and caps receipts at remaining good units.
- Fixed scrap unit selection to derive from the product on the selected production order, not the independently selected product in the costing form.

## Verification for this increment
- Backend suite: **58 passed**.
- Python compilation: passed.
- TypeScript TSX transpilation syntax diagnostics: **0**.
- ZIP integrity: verified after packaging.

## Remaining limitations
- `npm install` has timed out in prior attempts; dependency-backed TypeScript type-check and Vite production build remain unverified.
- Browser E2E, accessibility, mobile, and cross-browser tests have not been run.
- Stage material and scrap entries are posted, but the interface does not yet show a per-stage historical ledger of those entries.
- Scrap is not automatically reconciled to distinct physical losses, good output, or inventory; users must reconcile before treating aggregate scrap as unique lost units.
- Finished-goods receipt remains constrained to completed orders and the order's remaining good units.
- This is a development increment, not a final or production-ready release.

## Latest increment — Research Workspace fieldwork UI (2026-11-11)
- Added bilingual UI for pseudonymous industrial establishments and participation tracking.
- Added permission metadata capture with type/status/reference/validity dates; granted status requires a document reference.
- Added permission-gated interview, survey and observation metadata logging. Matching permission must be granted, in-date and tied to the same establishment.
- Added hypothesis register and same-organization evidence-reference validation at creation.
- Added data dictionary with variable definition/type/unit/allowed values/sensitivity; dictionary creation is audit logged.
- Added list refresh and tables for all six research datasets (evidence, establishments, permissions, interactions, hypotheses and variables).
- Backend tests: **61 passed**. Python compilation: passed. TypeScript TSX syntax diagnostics: **0**.
- npm dependency install failed with `EAI_AGAIN` (registry DNS/network unavailable); no full type-check, production build or browser testing is claimed.
- Still incomplete: survey/interview instrument builder, field response capture, coding/cleaning/anonymization pipeline, consent document vault, research report export and validated analysis. This is a development increment, not final or production-ready.

## Latest increment — Research instruments, response capture and cleaning log (2026-11-11)
- Added versioned survey/interview instrument API with field type, required-field and allowed-value validation.
- Added structured response capture linked to a same-organization interaction and matching active instrument type; existing interaction requires an approved matching permission.
- Added immutable raw response storage and separate review status.
- Added cleaning issue/action/outcome log without overwriting source response data.
- Expanded research JSON export with instruments, raw responses and cleaning logs.
- Added tenant isolation, field validation, raw-response preservation and successful capture tests.
- Backend test suite: 63 passed. Python compilation and ZIP integrity verified after packaging.
- Limitations: no respondent-facing portal/offline capture/consent signature, no automated cleaned dataset or statistical analysis, and no frontend UI for the new instrument/response/cleaning endpoints yet.
- npm-based production build and browser tests remain unverified due prior registry DNS failure. This is a development increment, not final release.

## Latest increment — Research instruments and data-quality frontend (2026-11-11)
- Added Arabic/English screens to create versioned interview/survey instruments, select draft/active status, and list stored versions.
- Added structured raw-response entry linked to an active instrument and a previously recorded interaction; the backend enforces matching interaction type and validates field names/types/required values/allowed values.
- Added response register with review status and a separate cleaning log form for variable issue/action/outcome/reviewer note.
- The UI displays original responses and cleaning history separately; cleaning entries do not mutate raw responses.
- Research refresh now loads instruments, responses and cleaning logs for the selected organization.
- Backend tests: **63 passed**. Python compilation passed. TypeScript TSX transpilation syntax diagnostics: **0**.
- Limitation: field definitions and response values are entered as JSON in this increment; a guided per-question form, automated cleaned analysis dataset, coding/statistical analysis, consent document storage, and privacy export profiles are not implemented. Full TypeScript type-check/Vite build and browser tests remain unverified because frontend dependencies are not installed (previous registry DNS failure). Not production-ready.

## 2026-11-11 — Reference-led visual identity increment
- Replaced the text-only FVG placeholder mark in the frontend header with the supplied original app-icon JPEG. The copied asset is byte-identical to the source image; no redraw, crop, recolor, or artwork modification was performed.
- Added the same supplied icon as the browser favicon and Apple touch icon.
- Added an opening splash screen using the original icon, FVG name, Arabic product name, and supplied tagline, with a cream/gold/deep-green composition inspired by the supplied composite reference.
- Reworked frontend styling toward the reference palette and presentation: deep-green hero, warm ivory/cream cards, gold accents, refined cards/tables/forms, responsive spacing, dark theme, and reduced-motion support.
- Important scope limit: the composite image is a visual reference board, not source design files or a fully specified pixel-perfect UI kit. This increment is a reference-led implementation, not a claim of pixel-identical recreation. The remaining screens, data visualizations, bottom navigation, and complete design-system details still need dedicated implementation and visual QA.
- Verification: backend tests 63 passed; Python compile passed; TSX transpilation diagnostics 0; icon source/copy byte comparison passed. Browser/Vite production build remains unverified because frontend dependencies are not installed in this environment.
- The application remains a development build. Not all originally requested business, accounting, research, authentication, subscription, security, integration, and deployment requirements are complete. Do not describe it as production-ready.

## 2026-11-11 — Reference-led six-screen navigation refinement
- Reworked the primary navigation to the six screens shown in the composite reference: Dashboard, Costing & Pricing, Financial Analysis, Scenario Analysis, Research Workspace, and Reports.
- Added a responsive five-item mobile bottom tab bar matching the reference's mobile navigation pattern (Home, Analysis, Costing, Research, Reports); the Scenario screen remains accessible from the responsive top-level navigation/section flow on wider screens and via its section anchor.
- Added dashboard KPI tiles that display only actual counts loaded from the active organization (products, production orders, saved costing snapshots, and raw materials); no fabricated financial amounts or demo activity are shown.
- Added an explicit Scenario Analysis anchor and responsive section spacing.
- Preserved the supplied app-icon JPEG byte-for-byte in `frontend/public/brand/app-icon-source.jpeg`; `index.html` references that exact asset for favicon and Apple touch icon. No redrawing, recoloring, or cropping was performed.
- Retained the approved palette and added responsive styles for desktop/tablet/mobile, dark theme, focus states, and safe-area padding.
- Verification: backend pytest 63 passed; TypeScript TSX transpilation diagnostics 0; original icon and public icon compare byte-for-byte equal.
- Not verified: full Vite production build, browser/e2e visual regression, iOS/Android install packaging. Frontend dependencies are not installed in this environment. This increment is a reference-led responsive implementation, not a claim of pixel-identical rendering across devices.

## 2026-11-11 — Financial analysis trend and scenario comparison increment
- Replaced the analysis-history heading with a dedicated Financial Analysis section title and added a responsive SVG trend chart using the latest six real saved costing snapshots from the active organization. No synthetic values are introduced; the chart shows an explicit empty state until snapshots exist.
- The trend chart includes saved period labels, cost values in SVG tooltips, a highest-cost summary, and a record count. It respects the app's light/dark palette and mobile layout.
- Scenario creation now retains the server response in the interface and displays base total, scenario total, and difference. The input rejects invalid percentages and changes below -100%; the scenario remains labeled as a what-if, not a forecast.
- Verification: backend tests **63 passed**; Python compilation passed; TypeScript TSX transpilation syntax diagnostics **0**.
- Build limitation: frontend dependencies are absent and offline npm installation failed because the required packages are not cached. Vite build, type-check, browser tests, and visual regression remain unverified.
- This is another development increment; it does not complete every requirement or establish production readiness.

## 2026-11-12 — Dedicated six-screen application navigation
- Converted the six reference destinations from in-page anchor links into explicit screen-state navigation: Dashboard, Costing & Pricing, Financial Analysis, Scenario Analysis, Research Workspace, and Reports.
- Added active-screen styling for desktop/tablet navigation and a six-destination mobile bottom bar, including direct access to Scenario Analysis on mobile.
- Separated content visibility by destination while keeping the underlying React sections mounted. Existing form state and loaded records are therefore preserved when switching screens.
- Grouped product registry, production capture, inventory, WIP, and finished-goods operations under Costing & Pricing so these existing operational functions remain reachable rather than being removed.
- Kept organization selection and session controls visible across screens. Dashboard KPI tiles continue to use actual organization counts only; no financial values or research activity are fabricated.
- Verification: backend tests **63 passed**; Python compilation passed; TypeScript TSX transpilation syntax diagnostics **0**.
- Not verified: dependency-backed Vite build, browser interaction tests, accessibility review, and visual regression. Frontend packages remain unavailable in the current environment.
- Remaining design work: richer dashboard content, guided research response forms, and further per-screen visual refinement. Remaining product gaps are unchanged; this increment is not production-ready.

## 2026-11-12 — App identity / install metadata pass
- Confirmed the supplied original 1254×1254 JPEG app-icon asset is present byte-for-byte at `frontend/public/brand/app-icon-source.jpeg`; it is used for the browser favicon, Apple touch icon, launch screen and app header.
- Added a web app manifest with FVG name, Arabic RTL metadata, approved theme/background colors, standalone display mode and the original icon asset.
- Expanded mobile viewport support (`viewport-fit=cover`) and Apple web-app metadata.
- This is identity/packaging metadata, not proof of a native iOS/Android app or store-ready installation package.
- The six-screen interface remains a partial visual implementation. Pixel-level matching against the composite reference, guided research forms, full functional scope, production security, dependency-backed frontend build, browser E2E and deployment remain outstanding. Do not call this a final approved production release.

## 2026-11-12 — Dashboard and reference-aligned UI refinement
- Added a dedicated dashboard welcome panel using the supplied FVG icon, brand naming, and bilingual introduction.
- Added a live saved-cost trend panel that reads only actual saved snapshots. It shows an explicit empty state when the organization has no saved cost history.
- Added quick-action cards linking to Costing & Pricing, Financial Analysis, Research Workspace, and Reports.
- Refined the application shell toward the composite reference: sticky warm-ivory header, deep-green navigation rail, gold active state, more consistent card radii/shadows, dark-mode equivalents, and mobile-safe responsive dashboard layout.
- Preserved the supplied original app icon asset unchanged. Existing six destinations and operational modules remain available.
- Verification: backend pytest **63 passed**; Python compilation passed; TSX transpilation diagnostics **0**.
- Not verified: Vite build/full TypeScript project check, browser/E2E visual tests, accessibility, and native iOS/Android packaging. Dependencies are still not installed in this environment.
- This increment improves the reference-led visual implementation but is not pixel-identical to the reference board and does not complete all business/security/research requirements. Not production-ready.

## 2026-11-12 — Guided research response capture increment
- Replaced JSON-only field response entry with a guided form generated from the selected active instrument schema.
- Text, integer, decimal, date, boolean, and category fields render with suitable controls; category fields use their declared allowed values.
- Required fields are marked and checked before submission. Values are submitted using the existing tenant-scoped API; raw responses remain immutable and cleaning records remain separate.
- Added a visual instrument builder: define question keys, choose supported answer types, mark required fields, specify allowed category values, add/remove questions, and save a versioned instrument. Response entry is generated from the saved schema. No respondent portal or offline mode is claimed.
- Verification: backend pytest **63 passed**; Python compilation and TSX transpilation are checked for this package. A full npm/Vite build remains unverified because dependency installation timed out in the current environment.
- This is a development increment, not a final or production-ready release.


## 2026-11-12 — Product CSV import increment
- Added product CSV preview and separate explicit transactional commit endpoints.
- Added bounded CSV parsing (2 MB / 500 rows), strict columns, validation, formula-like input rejection, duplicate SKU detection, and organization access/trial gating.
- Added frontend CSV file selection, preview table, issue list, confirm and discard actions.
- Tests: **67 passed**; Python compilation passed; TSX syntax transpilation **0 diagnostics**.
- Still outstanding: XLSX import, templates, import history/undo, full frontend build/browser QA, and all other previously documented release gates.
- Status remains development-only; not complete or production-approved.

## 2026-11-12 — Cross-screen design-system refinement
- Added a consistent visual system for panels, headings, forms, inputs, buttons, tables, KPI/result cards, notices, focus states, and mobile layouts across the FVG interface.
- Improved responsive desktop/tablet/mobile spacing, mobile safe-area handling, and reduced-motion support; preserved the approved palette and original icon file.
- Verification: backend suite **69 passed** (`PYTHONPATH=. python -m pytest -q`); Python source compilation passed.
- Frontend Vite build, full project type-check, browser/E2E screenshots, accessibility review, and visual regression remain unverified because frontend dependencies are not installed. This does not establish pixel-perfect matching or production readiness.
