# Changelog

## 0.2.0-development — 2026-11-09
- Added SQLite persistence schema for users, organizations, memberships, sessions, products, cost snapshots, scenarios, research evidence, audit log and trial subscriptions.
- Added registration/login/logout, scrypt password hashing, expiring bearer sessions and tenant membership checks.
- Added server-timed 72-hour trial with write blocking after expiration.
- Added tenant-scoped product and costing APIs, immutable cost snapshot history, what-if scenarios and evidence register.
- Expanded frontend to connect to these API flows; frontend build still unverified due dependency installation timeout.
- Added platform tests, API documentation, actual test report, limitations and SQLite backup script.

## 0.1.0-foundation — 2026-11-07
- Initial development foundation with Decimal calculation engine, minimal FastAPI API, reference-based frontend and preserved source assets.

## 2026-11-09 — Production and inventory development increment

- Added organization-scoped raw-material master records with explicit base units and currencies.
- Added product BOM records with per-unit quantities and explicit waste-rate bounds.
- Added production-order costing: planned quantity, BOM material requirement including waste, conversion cost, overhead, good saleable output and unit cost.
- Added receipt/issue/positive-adjustment inventory movement ledger and computed on-hand balances; prevent issues that exceed available quantity and reject unit mismatch.
- Added automated tests for BOM costing, yield, currency validation, missing BOM, inventory receipts/issues and negative-stock prevention.
- Verification: 35 backend tests passed in this environment. Frontend dependency installation/build, browser tests and full security/E2E validation remain unverified.


## 0.3.0-development — 2026-11-09
- Added a generalized, organization-scoped research establishment register using pseudonyms and sector metadata.
- Added permission metadata with pending/granted/denied/withdrawn states and validity windows.
- Added interview/survey/observation metadata intake gated by matching granted permission; participant identifiers are pseudonymous codes only.
- Added hypothesis tracking with evidence references constrained to the same organization. Hypotheses remain distinct from findings.
- Added a research data dictionary with variable definitions, units, types and sensitivity labels.
- Added tests for permission gating, tenant isolation, evidence-linked hypothesis assessment and duplicate dictionary variables.
- Verification: 38 backend tests passed; frontend build and broader security/E2E validation remain unverified.

## 2026-11-09 — PDF and Excel costing exports
- Added organization-scoped XLSX costing snapshot export with frozen header, filter and readable column widths.
- Added organization-scoped PDF costing snapshot report.
- Added export authentication regression test.
- PDF Arabic font shaping/embedding and complete multi-sheet Excel reports remain limitations.

## 2026-11-10 — Frontend costing report screen
- Added an authenticated Reports & Exports section to the React interface.
- Added PDF, XLSX and CSV download actions using the current organization's session token.
- Download controls remain disabled until the organization has at least one saved costing snapshot; empty or failed requests show explicit status/errors.
- Added Arabic/English labels and a visible notice that Arabic PDF font shaping is not yet supported.
- Updated the dashboard note to distinguish implemented costing exports from advanced inventory/production work still in development.
- Frontend dependency installation timed out in this environment, so no frontend build or browser test is claimed.

## 2026-11-10 — WIP stages and finished-goods workflow
- Added ordered production-stage records with controlled planned → in-progress → completed transitions; later stages cannot start until earlier stages are complete, and completed stages cannot be edited.
- Added WIP listing with recorded order and stage costs.
- Added finished-goods receipts gated on completed production orders and capped at the order's remaining good saleable quantity.
- Finished-goods receipt unit cost includes the original order cost plus recorded stage costs divided by good saleable units.
- Added organization-scoped finished-goods balance and issue/positive-adjustment endpoints with negative-stock prevention.
- Added regression coverage for stage sequencing, WIP cost, completion gates, finished-goods quantity limits and stock issue validation.
- Verification: 44 backend tests passed; Python syntax compilation passed. Frontend UI for these new workflows is not yet implemented.

## 2026-11-10 — Raw-material valuation and production material issue
- Added raw-material inventory valuation reconstruction using FIFO receipt layers and moving weighted average.
- Added authenticated, tenant-scoped atomic production BOM issue with waste allowance, sufficient-stock validation, duplicate prevention, and updated production-order material/total/unit cost.
- Added regression tests for FIFO/weighted-average values and one-time production issue.
- Verification: 46 backend tests passed; Python syntax compilation passed. Finished-goods valuation, negative stock correction, opening-balance migration and frontend screens remain outstanding.

## 2026-11-10 — Finished-goods valuation
- Added organization-scoped finished-goods valuation reconstruction using FIFO and moving weighted average across production receipts, manual positive adjustments and issues.
- Valuation rejects historical sequences that imply negative stock and reports quantity, inventory value and average unit cost by product.
- Added tests for FIFO versus weighted-average outcomes and tenant isolation.
- Verification: 48 backend tests passed; Python syntax compilation passed. Valuation remains dependent on complete, correctly ordered movement history; manual issue unit cost is not authoritative for reconstructed valuation.


## 2026-11-10 — Inventory stocktake and opening quantity workflow
- Added organization-scoped physical stocktake endpoints for raw materials and finished goods.
- Stocktake compares current book quantity to a counted quantity and atomically posts the signed difference; positive differences create valued incoming layers and negative differences post issues.
- Supports initial quantity entry from a zero book balance, with unique stocktake references and audit records. This is not historical backdating or a full count-session/approval workflow.
- Added regression coverage for positive and negative differences and FIFO valuation reconciliation.


## 2026-11-10 — Production-stage labor capture
- Added tenant-scoped labor entries linked to a specific production order and stage, recording worker code (optional), work description, hours, hourly rate, currency and work date.
- Labor cost is calculated deterministically as hours × hourly rate and added to the stage conversion cost, so WIP and finished-goods receipt costing include it without separate manual re-entry.
- Labor can only be recorded while its stage is in progress; completed stages and completed orders reject further labor entries. Currency must match the production order.
- Added authenticated labor listing with stage total and tests for costing flow, stage-state restrictions, currency validation and tenant isolation.
- Verification: 52 backend tests passed; Python syntax compilation passed. Frontend screens and payroll/time-clock integrations remain unimplemented.

## 2026-11-10 — Production-stage material issues and scrap records
- Added atomic stage-level raw-material consumption with FIFO or moving weighted-average valuation, stock validation, unit/currency checks, duplicate-reference protection, audit logging, and order material-cost recalculation.
- When actual stage material issues are captured, the order material-cost amount is based on the accumulated actual stage issues rather than retaining the BOM estimate as well; this avoids double counting the estimate and actual consumption.
- Added stage scrap quantity/reason/date records and list endpoint. Scrap remains operationally tracked and does not automatically change good output or cost denominator.
- Added automated coverage for stage lifecycle, valuation, stock balance, cost integration, scrap capture, and tenant isolation.


## 2026-11-10 — Scrap yield and cost analysis
- Added authenticated, tenant-scoped production-order scrap analysis with stage-by-stage quantities, scrap rate, provisional good-yield estimate, and cost-per-unit sensitivity.
- Analysis is read-only: it does not change the production order's authoritative good units, cost denominator, inventory, snapshots, or finished-goods receipts.
- Explicitly warns that scrap at multiple stages may represent the same underlying units; users must reconcile distinct losses before using the summed estimate.
- Rejects analysis when recorded scrap exceeds planned units; added regression tests for calculations, immutability and tenant isolation.

## 2026-11-11 — Standard vs actual production cost variance
- Added append-only, versioned product standard-cost sheets for per-good-unit material quantities and rates, labor hours and hourly rate, and overhead.
- Added production-order variance analysis for material price/usage, labor rate/efficiency, overhead, and combined variance where actual data is complete.
- Positive variance is labeled unfavorable and negative variance favorable. Missing actual consumption/labor is surfaced as unavailable; it is never silently treated as zero.
- Added tests for standard versioning, component variance calculations, missing actual data, and endpoint behavior. Backend suite: 56 passed.


## 2026-11-11 — Machine-hour efficiency and capacity analysis
- Added optional, version-linked machine-hour standards: machine hours per good unit, budgeted machine capacity hours, and fixed-overhead budget (all required together).
- Added stage-level actual machine-hour capture and authenticated order-level machine-hour listing. Records can only be added while the stage is in progress and are tenant-scoped/audited.
- Extended read-only variance analysis with standard hours allowed, machine-hour efficiency variance, fixed-overhead capacity volume variance, idle capacity hours and utilization percentage.
- Clearly separates capacity volume variance from actual fixed-overhead spending variance; machine-hour entries do not post costs.
- Added regression tests for stage-state restrictions, capacity calculations, incomplete standards and tenant isolation.
- Verification: 58 backend tests passed; Python compilation and ZIP integrity checked.


## 2026-11-11 — Production and standard-cost frontend increment
- Added Arabic/English frontend workflows for raw-material registration and opening receipt, BOM component entry, append-only product standard-cost creation (including machine-hour/capacity standards), production-order creation, ordered stage creation/status transitions, stage labor capture, machine-hour capture, and read-only variance report display.
- Added UI-level input controls and surfaced backend errors rather than creating local-only success states.
- Frontend package installation timed out in this environment; TypeScript/React production build and browser tests remain unverified. No production release is claimed.

## 2026-11-11 — Inventory, stocktake and WIP frontend increment
- Added Arabic/English inventory screens for raw-material balances, physical stocktake posting, FIFO/moving-weighted-average valuation, WIP cost listing, finished-goods balances, finished-goods stocktake, and finished-goods issue.
- Added refresh actions and organization-scoped data loading for the new inventory/WIP views. Opening quantity is optional when creating a raw material; zero opening quantity no longer attempts an invalid receipt.
- Added explicit UI notice that manual finished-goods issue cost is stored as movement reference while the valuation report reconstructs cost from movement history.
- Hardened raw-material and finished-goods manual issue/receipt movement writes with SQLite `BEGIN IMMEDIATE` transaction locking around balance checks and inserts to reduce concurrent overselling/negative-stock races.
- Verification: backend suite 58 passed; Python syntax compilation passed; TypeScript `transpileModule` parsed TSX with zero syntax diagnostics. `npm install` timed out, so dependency-backed type-check/build, browser E2E, accessibility and cross-browser tests remain unverified.

## 2026-11-11 — Production stage capture and finished-goods receipt UI
- Added bilingual controls to record actual raw-material consumption for an in-progress production stage, selecting FIFO or moving weighted-average valuation.
- Added stage scrap entry with reason and date supplied by the interface; added scrap-analysis display with explicit limitations.
- Added finished-goods receipt UI for a selected production order. The action is enabled only when the order status is completed; the API remains authoritative and enforces remaining good saleable quantity.
- Scrap records remain operational records and do not automatically alter good output, inventory, or finished-goods receipts.

## 2026-11-11 — Research Workspace fieldwork UI increment
- Added bilingual UI for pseudonymous industrial-establishment registry and participation status.
- Added permission metadata capture for site access, interviews, surveys, records review, photography and publication, including status, reference and validity dates. A granted permission requires a document reference; the app stores metadata only and does not validate the underlying signed document.
- Added interview/survey/observation metadata log. The API requires a matching granted and in-date permission before an interaction can be recorded.
- Added hypothesis register with evidence-reference input and explicit non-finding status messaging.
- Added research data dictionary UI for variable definition, type, unit, allowed values and sensitivity classification.
- Added reloadable organization-scoped research lists for evidence, establishments, permissions, interactions, hypotheses and variables.
- Backend now validates evidence references at hypothesis creation against the same organization and writes audit entries for data-dictionary creation.
- Verification: 61 backend tests passed; Python compilation passed; TypeScript TSX syntax transpilation reported 0 diagnostics. npm install failed with EAI_AGAIN (registry DNS/network unavailable); dependency-backed type-check, production build, browser/E2E, accessibility and cross-browser tests remain unverified.

## 2026-11-11 — Research instruments and immutable field responses
- Added versioned interview/survey instruments with validated field names, types, required flags, and optional allowed-value constraints.
- Added field response capture linked to an existing, permission-gated interaction and matching instrument type.
- Added organization-scoped response listing and review statuses.
- Added separate data-cleaning logs for missing values, outliers, inconsistent values, invalid formats, duplicates and other review issues.
- Raw response JSON is immutable through the cleaning workflow; cleaning actions are logged separately and do not silently overwrite source observations.
- Expanded research JSON export to include instruments, raw responses and cleaning logs.
- Added tests for successful response capture, validation failures, immutable source data and tenant isolation.

## 2026-11-12 — Guided research response form
- Added dynamic question controls generated from active interview/survey instrument definitions.
- Added required-field validation and typed value submission for text, integer, decimal, date, boolean, and allowed-value category fields.
- Preserved raw-response immutability and separate cleaning-log workflow.
- Added visual instrument authoring controls for question keys, types, required flags and category values. Frontend production build and browser E2E are not verified.
