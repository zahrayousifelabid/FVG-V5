# Reporting/export status — 2026-11-10

Implemented backend endpoints: costing CSV, costing XLSX, costing PDF, production CSV, research workspace JSON.

The React interface now includes a Reports & Exports section with authenticated download actions for costing PDF, XLSX and CSV. It uses the currently selected organization and the active bearer session. Controls stay disabled until at least one saved costing snapshot exists. Errors are surfaced in the interface rather than silently downloading an error response.

XLSX/PDF exports query persisted snapshots for the authenticated organization and do not generate placeholder business figures. Both endpoints require a bearer session and organization membership. Empty reports display an explicit empty-record row in PDF and a header-only workbook in XLSX. CSV exports are also organization-scoped.

Verification performed: backend test suite and Python syntax compilation. Authentication regression coverage added for the XLSX/PDF routes. Dependency import smoke test passed for openpyxl and ReportLab in the build environment. Latest backend suite: 42 passed.

Limitations: PDF currently uses ReportLab's default font and does not promise Arabic shaping or embedded Arabic fonts. Excel export currently covers costing snapshots only; production and research are not yet available as XLSX. Production CSV and research JSON remain backend endpoints without dedicated frontend download controls. Frontend dependency installation timed out in this environment, so the React/TypeScript production build and browser behavior remain unverified. No production deployment was performed.
