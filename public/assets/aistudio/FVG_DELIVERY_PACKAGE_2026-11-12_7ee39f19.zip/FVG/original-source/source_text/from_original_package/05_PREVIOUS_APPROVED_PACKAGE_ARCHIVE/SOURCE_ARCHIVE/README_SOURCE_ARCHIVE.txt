# FVG source archive

This folder preserves the prior FVG specification documents used to build the consolidated master. Do not delete these source files while implementing. The DOCX research specification is included in original form and as a Markdown extraction for easier reading. `SOURCE_MANIFEST.json` records byte sizes and SHA-256 hashes of the source files.

Start with `FVG_FINAL_APPROVED_MASTER_SPECIFICATION_AR_EN_2026.md` in the parent package, then read the source documents as needed. If the sources appear to conflict, document the conflict and do not silently discard requirements.
