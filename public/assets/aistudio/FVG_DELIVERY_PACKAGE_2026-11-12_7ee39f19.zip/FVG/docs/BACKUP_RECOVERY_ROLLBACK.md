# Backup, recovery and rollback

## Development SQLite backup

From `backend/`, with the application database path configured:

```bash
FVG_DATABASE_FILE=./fvg.db python scripts/backup_sqlite.py ../backups/fvg-backup.db
```

The script uses SQLite's online backup API and runs `PRAGMA integrity_check`. Keep backups outside the public web root, encrypt them at rest, restrict access, and define a retention schedule appropriate to applicable law and business needs.

## Restore (manual, offline only)

1. Stop the API process and confirm no writer is connected.
2. Preserve a copy of the current database before replacing anything.
3. Verify the backup with `sqlite3 backup.db 'PRAGMA integrity_check;'` and confirm it returns `ok`.
4. Copy the selected backup into the configured database path.
5. Start the service and run health checks plus a controlled read-only record check.

## Rollback

For code rollback, stop the service, preserve the current database and package, restore the previous reviewed source package, and only then restart. The current schema initializer is additive/idempotent, not a versioned migration framework. Do not run an older application against a newer schema without a separately tested compatibility plan.

No automated backup schedule or disaster recovery drill has been executed for this project.
