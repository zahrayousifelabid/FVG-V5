"""Deterministic FVG financial calculations. Decimal arithmetic; no AI dependency."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, ROUND_CEILING
from typing import Iterable

MODEL_VERSION = "1.0.0"

class FinancialInputError(ValueError):
    pass

def D(value) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise FinancialInputError(f"Invalid numeric input: {value!r}")
    if not result.is_finite():
        raise FinancialInputError("Numeric inputs must be finite")
    return result

def money(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

def total_cost(components: Iterable, allow_negative: bool = False) -> Decimal:
    values = [D(x) for x in components]
    if not allow_negative and any(x < 0 for x in values):
        raise FinancialInputError("Cost components cannot be negative")
    return money(sum(values, Decimal(0)))

def unit_cost(total_allocated_cost, good_saleable_units) -> Decimal:
    cost, units = D(total_allocated_cost), D(good_saleable_units)
    if cost < 0: raise FinancialInputError("Allocated cost cannot be negative")
    if units <= 0: raise FinancialInputError("Good saleable units must be greater than zero")
    return money(cost / units)

def profit_per_unit(selling_price, unit_cost_value) -> Decimal:
    return money(D(selling_price) - D(unit_cost_value))

def total_profit(total_revenue, total_cost_value) -> Decimal:
    return money(D(total_revenue) - D(total_cost_value))

def margin(profit, selling_price):
    p, s = D(profit), D(selling_price)
    if s <= 0: raise FinancialInputError("Selling price must be greater than zero")
    return (p / s).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)

def markup(profit, cost):
    p, c = D(profit), D(cost)
    if c <= 0: raise FinancialInputError("Cost must be greater than zero")
    return (p / c).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)

def target_price_by_margin(unit_cost_value, target_margin):
    c, m = D(unit_cost_value), D(target_margin)
    if c < 0 or not (Decimal(0) <= m < Decimal(1)):
        raise FinancialInputError("Cost must be nonnegative and target margin in [0, 1)")
    return money(c / (Decimal(1) - m))

def target_price_by_markup(unit_cost_value, target_markup):
    c, m = D(unit_cost_value), D(target_markup)
    if c < 0 or m < 0: raise FinancialInputError("Cost and markup must be nonnegative")
    return money(c * (Decimal(1) + m))

def break_even_units(fixed_costs, selling_price, variable_cost_per_unit):
    fixed, price, variable = D(fixed_costs), D(selling_price), D(variable_cost_per_unit)
    contribution = price - variable
    if fixed < 0 or price < 0 or variable < 0: raise FinancialInputError("Break-even inputs cannot be negative")
    if contribution <= 0: raise FinancialInputError("Contribution per unit must be greater than zero")
    return (fixed / contribution).quantize(Decimal("1"), rounding=ROUND_CEILING)

def break_even_revenue(units, selling_price):
    u, p = D(units), D(selling_price)
    if u < 0 or p < 0: raise FinancialInputError("Units and price cannot be negative")
    return money(u * p)

def convert_units(quantity, from_unit, to_unit, conversions):
    q = D(quantity)
    if q < 0: raise FinancialInputError("Quantity cannot be negative")
    if from_unit == to_unit: return q
    key = (from_unit, to_unit)
    if key in conversions: return q * D(conversions[key])
    reverse = (to_unit, from_unit)
    if reverse in conversions:
        factor = D(conversions[reverse])
        if factor == 0: raise FinancialInputError("Conversion factor cannot be zero")
        return q / factor
    raise FinancialInputError(f"Incompatible or undefined units: {from_unit} -> {to_unit}")

def allocate_cost(pool_cost, driver_quantities, selected_driver_quantity):
    pool, quantities, selected = D(pool_cost), [D(x) for x in driver_quantities], D(selected_driver_quantity)
    if pool < 0 or selected < 0 or any(x < 0 for x in quantities):
        raise FinancialInputError("Allocation values cannot be negative")
    total_driver = sum(quantities, Decimal(0))
    if total_driver <= 0: raise FinancialInputError("Total allocation driver must be greater than zero")
    if selected > total_driver: raise FinancialInputError("Selected driver cannot exceed total driver")
    return money(pool * selected / total_driver)

def scenario(base_components: dict, changes: dict):
    """Apply explicit percentage changes by cost component; preserve the input base."""
    result = {}
    for key, value in base_components.items():
        base = D(value)
        pct = D(changes.get(key, 0))
        if base < 0 or pct < -1: raise FinancialInputError("Invalid scenario input")
        result[key] = money(base * (Decimal(1) + pct))
    return {"model_version": MODEL_VERSION, "base_total": total_cost(base_components.values()),
            "scenario_components": result, "scenario_total": total_cost(result.values())}
