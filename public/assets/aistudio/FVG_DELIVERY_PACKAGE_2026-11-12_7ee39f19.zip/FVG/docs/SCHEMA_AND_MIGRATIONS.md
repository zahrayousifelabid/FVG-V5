# Database schema and migration status

The current SQLite schema is initialized by `backend/app/storage.py::initialize()` using idempotent `CREATE TABLE IF NOT EXISTS` statements. `backend/schema_reference.sql` is a human-readable snapshot of that schema.

**Important:** a versioned migration runner, production PostgreSQL adapter, migration rollback scripts and upgrade rehearsal have not been implemented or tested. Do not treat the schema snapshot as a production migration system. Before production, establish versioned migrations, backup the database, test upgrades on a copy, and rehearse rollback/restore.
