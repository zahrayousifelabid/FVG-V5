# External dependency register

| Dependency | Current status | Required before activation |
|---|---|---|
| Email verification / password recovery | Not integrated | Approved email provider, credentials, templates, domain verification, abuse controls and tests |
| AI advisor | Not integrated | Provider choice, server-side credentials, privacy review, prompt-injection controls, source verification and evaluation suite |
| Payment processing | Not integrated; payments disabled | Approved provider, merchant onboarding, server credentials, webhook verification, refund/reconciliation and compliance review |
| Live FX rates | Not integrated | Authoritative provider, credentials, rate type/time/quote metadata, fallback and audit controls |
| OCR/document extraction | Not integrated | Provider/model, secure upload pipeline, human verification and malicious-file scanning |
| Cloud object storage | Not integrated | Provider credentials, private buckets, encryption, lifecycle and access policies |
| Production database | SQLite only in this build | Managed PostgreSQL or equivalent, migrations, backups, connection pooling and load tests |

No external provider has been represented as connected or active. Empty `.env.example` values are placeholders, not credentials.
