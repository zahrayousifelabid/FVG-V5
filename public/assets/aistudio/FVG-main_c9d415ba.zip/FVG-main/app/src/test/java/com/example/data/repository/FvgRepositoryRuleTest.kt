package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.Organization
import com.example.domain.engine.FvgFinancialEngine
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.*
import org.junit.Test
import java.math.BigDecimal

class FvgRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createOrg_andRecordPriceObservation_persistsAndObserves() = runBlocking {
        val aliceUid = signInTestUser("alice_fvg@test.com")
        val repo = FvgRepository(firestore)

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.ensureUserProfile(aliceUid, "alice_fvg@test.com", "Alice").getOrThrow()
        }
        val orgId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createOrganization(aliceUid, "alice_fvg@test.com", "FVG Test Corp", "USD").getOrThrow()
        }
        val org = Organization(
            id = orgId,
            name = "FVG Test Corp",
            baseCurrency = "USD",
            ownerId = aliceUid,
            memberUids = listOf(aliceUid),
            roles = mapOf(aliceUid to "owner")
        )

        val obsId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.recordProductAndPriceObservation(
                org = org,
                actorUid = aliceUid,
                actorEmail = "alice_fvg@test.com",
                existingProduct = null,
                name = "Refined Sugar",
                sku = "SUG-50",
                category = "Commodities",
                description = "50kg bag",
                unit = "bag",
                currency = "USD",
                location = "Khartoum",
                source = "Wholesale Market",
                newPriceStr = "45.00",
                observationDate = "2026-11-15",
                notes = "Initial observation"
            ).getOrThrow()
        }
        assertTrue(obsId.isNotBlank())

        val products = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeProducts(orgId, aliceUid).first { it.isNotEmpty() }
        }
        assertEquals("Refined Sugar", products.first().name)
    }

    @Test
    fun crossOrgAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser("alice_iso@test.com")
        val repo = FvgRepository(firestore)
        val orgId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createOrganization(aliceUid, "alice_iso@test.com", "Alice Org", "USD").getOrThrow()
        }
        val org = Organization(
            id = orgId,
            name = "Alice Org",
            baseCurrency = "USD",
            ownerId = aliceUid,
            memberUids = listOf(aliceUid),
            roles = mapOf(aliceUid to "owner")
        )
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.recordProductAndPriceObservation(
                org, aliceUid, "alice_iso@test.com", null,
                "Wheat", "WHT-1", "Grain", "", "ton", "USD", "Port", "Supplier A",
                "300.00", "2026-11-15", ""
            ).getOrThrow()
        }

        val bobUid = signInTestUser("bob_iso@test.com")
        val unauthorizedAttempt = repo.recordProductAndPriceObservation(
            org.copy(memberUids = listOf(aliceUid, bobUid)),
            bobUid, "bob_iso@test.com", null,
            "Tampered", "TMP-1", "Grain", "", "ton", "USD", "Port", "Supplier A",
            "100.00", "2026-11-15", ""
        )
        assertTrue(unauthorizedAttempt.isFailure)
        val fsErr = unauthorizedAttempt.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull(fsErr)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsErr?.code)
    }

    @Test
    fun unauthenticatedObserve_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = FvgRepository(firestore)
        val exception = try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeProducts("org_any", "fake_uid").first()
            }
            null
        } catch (e: Exception) {
            e
        }
        assertNotNull(exception)
        val fsErr = exception!!.unwrapFirestoreException()
        assertNotNull("Expected nested FirebaseFirestoreException, got $exception", fsErr)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsErr?.code)
    }

    @Test
    fun balancedJournalAndFifoInventory_succeedsThroughRepository() = runBlocking {
        val aliceUid = signInTestUser("alice_acc@test.com")
        val repo = FvgRepository(firestore)
        val orgId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createOrganization(aliceUid, "alice_acc@test.com", "Accounting Org", "USD").getOrThrow()
        }
        val org = Organization(
            id = orgId,
            name = "Accounting Org",
            baseCurrency = "USD",
            ownerId = aliceUid,
            memberUids = listOf(aliceUid),
            roles = mapOf(aliceUid to "owner")
        )

        val jeId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.postJournalEntry(
                org = org,
                actorUid = aliceUid,
                actorEmail = "alice_acc@test.com",
                referenceNo = "JE-100",
                entryDate = "2026-11-15",
                period = "2026-11",
                description = "Owner capital injection",
                currency = "USD",
                exchangeRateStr = "1.0000",
                originalCurrency = "USD",
                originalAmountStr = "5000.00",
                lines = listOf(
                    FvgFinancialEngine.JournalLineInput("1010", "Cash & Bank", BigDecimal("5000.00"), BigDecimal.ZERO),
                    FvgFinancialEngine.JournalLineInput("3010", "Owner Equity", BigDecimal.ZERO, BigDecimal("5000.00"))
                )
            ).getOrThrow()
        }
        assertTrue(jeId.isNotBlank())

        val itemId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createInventoryItem(
                org, aliceUid, "alice_acc@test.com",
                "RAW-01", "Packaging Film", "raw_material", "kg",
                "Main Warehouse", "fifo", "100", "2.50", "3.00"
            ).getOrThrow()
        }
        val items = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeInventoryItems(orgId, aliceUid).first { list -> list.any { it.id == itemId } }
        }
        val item = items.first { it.id == itemId }
        val moveId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.recordInventoryMovement(
                org, aliceUid, "alice_acc@test.com", item,
                "issue", "20", "0", "Main Warehouse",
                "Production order #1", "ISS-01", "2026-11-15", true
            ).getOrThrow()
        }
        assertTrue(moveId.isNotBlank())
    }

    @Test
    fun standardCostsProductionOrdersScrapApprovalAndDraftJournal_succeedThroughRepository() = runBlocking {
        val aliceUid = signInTestUser("alice_mfg@test.com")
        val repo = FvgRepository(firestore)
        val orgId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createOrganization(aliceUid, "alice_mfg@test.com", "Mfg Org", "USD").getOrThrow()
        }
        val orgs = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeOrganizations(aliceUid).first { list -> list.any { it.id == orgId } }
        }
        val org = orgs.first { it.id == orgId }
        val trialEndMs = org.trialEndsAt?.toDate()?.time ?: 0L
        val trialStartMs = org.trialStartedAt?.toDate()?.time ?: System.currentTimeMillis()
        val diffHours = (trialEndMs - trialStartMs) / 3600_000L
        assertTrue("Expected ~72h (3-day) trial window, got ${diffHours}h", diffHours in 70L..73L)

        // 1. Standard Cost Sheet
        val stdId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createStandardCostSheet(
                org, aliceUid, "alice_mfg@test.com",
                "prod_coffee", "Ben Al-Zahra 500g", 0L,
                "3.20", "0.25", "8.00", "0.80", "Standard batch"
            ).getOrThrow()
        }
        assertTrue(stdId.isNotBlank())

        // 2. Production Order create & complete
        val poId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createProductionOrder(
                org, aliceUid, "alice_mfg@test.com",
                "prod_coffee", "Ben Al-Zahra 500g", "2026-11",
                "100", "95", "5", "340.00", "200.00", "85.00",
                listOf("Roasting", "Grinding", "Packaging")
            ).getOrThrow()
        }
        assertTrue(poId.isNotBlank())
        val orders = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeProductionOrders(orgId, aliceUid).first { list -> list.any { it.id == poId } }
        }
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.completeProductionOrder(
                org, aliceUid, "alice_mfg@test.com",
                orders.first { it.id == poId },
                "4", "335.00", "195.00", "80.00"
            ).getOrThrow()
        }

        // 3. Scrap loss request & admin approval (deducts inventory & posts loss JE)
        val invId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createInventoryItem(
                org, aliceUid, "alice_mfg@test.com",
                "BEAN-1", "Green Beans", "raw_material", "kg",
                "Main Warehouse", "moving_avg", "50", "4.00", "4.50"
            ).getOrThrow()
        }
        val invItems = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeInventoryItems(orgId, aliceUid).first { list -> list.any { it.id == invId } }
        }
        val item = invItems.first { it.id == invId }
        val scrapId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.submitScrapLossRequest(
                org, aliceUid, "alice_mfg@test.com",
                item, "scrap", "5", "Spillage", "2026-11-15"
            ).getOrThrow()
        }
        val scraps = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeScrapLosses(orgId, aliceUid).first { list -> list.any { it.id == scrapId } }
        }
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.reviewScrapLossRequest(
                org, aliceUid, "alice_mfg@test.com",
                scraps.first { it.id == scrapId }, item, "approved"
            ).getOrThrow()
        }

        // 4. Draft Journal Entry -> Approve & Post
        val draftJeId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.postJournalEntry(
                org, aliceUid, "alice_mfg@test.com",
                "JE-DRAFT-1", "2026-11-15", "2026-11", "Accrued utility",
                "USD", "1.0000", "USD", "150.00",
                listOf(
                    FvgFinancialEngine.JournalLineInput("6010", "Operating Expenses", BigDecimal("150.00"), BigDecimal.ZERO),
                    FvgFinancialEngine.JournalLineInput("2010", "Accounts Payable", BigDecimal.ZERO, BigDecimal("150.00"))
                ),
                sourceModule = "manual",
                status = "draft"
            ).getOrThrow()
        }
        val entries = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeJournalEntries(orgId, aliceUid).first { list -> list.any { it.id == draftJeId } }
        }
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.approveAndPostDraftJournalEntry(
                org, aliceUid, "alice_mfg@test.com", entries.first { it.id == draftJeId }
            ).getOrThrow()
        }
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 12000L
        const val FLOW_TIMEOUT_MS = 8000L
    }
}
