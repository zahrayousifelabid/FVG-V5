"""Create and integrity-check a consistent SQLite backup using SQLite's backup API."""
import os, sqlite3, sys
from datetime import datetime, timezone
from pathlib import Path
source=Path(os.getenv('FVG_DATABASE_FILE','./fvg.db')).resolve()
if not source.exists():
    raise SystemExit(f'Database not found: {source}')
out=Path(sys.argv[1] if len(sys.argv)>1 else f'fvg-backup-{datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")}.db').resolve()
out.parent.mkdir(parents=True,exist_ok=True)
with sqlite3.connect(source) as src, sqlite3.connect(out) as dst:
    src.backup(dst)
    result=dst.execute('PRAGMA integrity_check').fetchone()[0]
    if result!='ok':
        out.unlink(missing_ok=True)
        raise SystemExit(f'Backup integrity check failed: {result}')
print(f'Backup created and integrity-checked: {out} ({out.stat().st_size} bytes)')
