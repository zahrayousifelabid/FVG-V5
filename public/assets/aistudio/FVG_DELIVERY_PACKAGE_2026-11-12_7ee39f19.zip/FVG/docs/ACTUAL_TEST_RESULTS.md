# Actual test results — 2026-11-09

Command executed from `backend/`:

```bash
PYTHONPATH=. pytest -q
```

Result: **38 passed** (1.43 seconds) in the current local test environment.

Coverage includes deterministic financial calculations, API validation, registration/login/logout, 72-hour trial enforcement, organization isolation, immutable costing snapshots, what-if scenarios, traceable allocations, explicit unit conversions, research evidence status handling, establishment pseudonyms, permission-gated interaction metadata, evidence-linked hypothesis workflow, data dictionary and sensitivity labels, raw-material creation, BOM costing with waste, production yield and currency/BOM validation, inventory receipts/issues, computed balances and prevention of negative stock.

Not executed / not verified in this environment: frontend production build (dependency installation timed out), browser/E2E tests, accessibility checks, penetration/security testing, load/concurrency tests, email delivery, live payment/FX/AI integrations, deployment, production database migration/restore drill, and end-to-end inventory-to-production posting. Raw-material and finished-goods valuation and signed stocktake API workflows are now covered by the later increments below, but browser/UI integration is not verified. Passing backend tests do not certify production readiness.


## 2026-11-09 — PDF/XLSX increment
- `PYTHONPATH=. pytest -q`: 42 passed.
- `python -m py_compile app/*.py`: passed.
- Import smoke test: openpyxl and ReportLab available in the build environment.
- Added unauthenticated-access regression checks for costing PDF/XLSX routes (both must return 401).
- No browser build, Arabic PDF rendering, deployment, or full export content integration test is claimed.

## 2026-11-10 — Frontend reports screen increment
- Backend regression rerun: `PYTHONPATH=. pytest -q`: 42 passed in 2.14 seconds.
- `python -m py_compile app/*.py`: passed.
- Frontend reports screen source updated for authenticated PDF/XLSX/CSV downloads.
- `npm install --no-audit --no-fund` timed out; `node_modules/.bin/tsc` unavailable. No frontend build, browser test, or runtime download test is claimed.

## 2026-11-10 — WIP and finished-goods increment
- `PYTHONPATH=. pytest -q`: **44 passed** (2.50 seconds).
- `python -m py_compile app/*.py`: passed.
- Added tests for sequential stage workflow, WIP cost accumulation, completion and finished-goods receipt limits, completed cost/unit cost, and prevention of negative finished-goods stock.
- Not verified at that increment: frontend UI for stage/WIP/finished goods, material inventory auto-issue, browser/E2E, Arabic PDF output, deployment and security audit. Valuation and stocktake were added and tested in later increments below.

## 2026-11-10 — Raw-material valuation and production issue
Command: `PYTHONPATH=. pytest -q` from `backend/`
Result: **46 passed**.
Command: `python -m py_compile app/*.py` from `backend/`
Result: passed.
Coverage added: FIFO and moving weighted-average valuation reconstruction; production BOM issue using FIFO; BOM waste allowance; stock sufficiency; updated order cost; duplicate issue rejection.

## 2026-11-10 — Finished-goods valuation increment
- `PYTHONPATH=. pytest -q`: **48 passed** (2.62 seconds).
- `python -m py_compile app/*.py`: passed.
- Added FIFO and moving weighted-average finished-goods valuation tests, including tenant isolation.
- Frontend build/E2E, Arabic PDF rendering, production deployment and security review remain unverified.


## 2026-11-10 — Inventory stocktake increment
- Added tests for raw-material stocktake decrement and FIFO valuation reconciliation, duplicate reference rejection, and finished-goods stocktake positive/negative differences with FIFO valuation.
- Full backend suite: **50 passed** (after final run).


## 2026-11-10 — Production-stage labor capture increment
- `PYTHONPATH=. pytest -q` from `backend/`: **52 passed** (2.97 seconds).
- Added regression coverage for hours × hourly-rate calculation, stage conversion cost accumulation, WIP/finished-goods cost path, currency match, in-progress-only entry, completed-stage rejection and organization isolation.
- Python syntax compilation and archive integrity are recorded in the delivery report for this increment.
- Not verified: frontend build/browser flow, payroll or time-clock integration, overtime policy, production deployment or independent security review.

## 2026-11-10 — Production-stage material/scrap increment
- Command: `PYTHONPATH=. pytest -q`
- Result: **53 passed**.
- Command: `python -m py_compile app/*.py`
- Result: passed.
- Scope added: FIFO stage material issue, inventory decrease, order actual material cost replacement (avoids BOM estimate double-counting), scrap capture/listing, and tenant isolation.


## 2026-11-10 — Scrap yield/cost analysis increment
- `PYTHONPATH=. pytest -q` from `backend/`: **54 passed**.
- `python -m py_compile app/*.py`: passed.
- Added coverage for stage-level scrap aggregation, provisional good-yield and cost-per-unit calculation, non-mutation of authoritative production order values, and organization isolation.
- Analysis remains provisional where the same units may be recorded as scrap at multiple production stages; no automatic output/inventory posting is performed.

## 2026-11-11 — Standard vs actual variance increment
- `PYTHONPATH=. pytest -q`: **56 passed**.
- Covered standard sheet creation and version increments, material price and usage variance, labor rate and efficiency variance, overhead variance, total variance, and unavailable results when actual material issues are missing.
- Python syntax compilation and archive integrity are checked for this delivery.
- Frontend build/browser tests remain unverified; no production deployment is claimed.


## 2026-11-11 — Machine-hour efficiency and capacity increment
- `PYTHONPATH=. pytest -q` from `backend/`: **58 passed**.
- Added coverage for machine-hour entry lifecycle, stage restrictions, machine-hour totals, standard hours allowed, efficiency variance, capacity volume variance, idle capacity and tenant isolation.
- Added validation that machine-capacity standard fields must be supplied as a complete set.
- `python -m py_compile app/*.py`: passed.
- Frontend build/browser tests, Arabic PDF shaping, deployment and independent security review remain unverified.


## 2026-11-11 — Production and standard-cost frontend source increment
- Backend regression suite rerun after frontend changes: `PYTHONPATH=. pytest -q`: **58 passed**.
- `python -m py_compile app/*.py`: passed.
- TypeScript compiler parser transpilation: JSX/TSX syntax parsed without syntax diagnostics; module resolution/type-check not completed because React/Vite dependencies are not installed.
- `npm install --no-audit --no-fund` timed out again. Therefore no frontend production build, browser runtime, E2E, accessibility or cross-browser result is claimed.

## 2026-11-11 — Inventory/WIP frontend and stock movement transaction increment
- `PYTHONPATH=. pytest -q`: **58 passed** after the API transaction changes.
- `python -m py_compile app/*.py`: passed.
- TypeScript compiler `transpileModule` on `frontend/src/main.tsx`: **0 TSX/JSX syntax diagnostics**.
- `npm install --no-audit --no-fund` timed out; React/Vite module resolution, static type-check, production build and browser execution remain unverified.
- No concurrency stress test was run; `BEGIN IMMEDIATE` now serializes the manual inventory movement balance-check/write path in SQLite, but this does not constitute a production load/concurrency certification.

## 2026-11-11 — Production stage capture UI increment
- Backend suite: 58 passed.
- Python compilation (`python -m py_compile app/*.py`): passed.
- TypeScript TSX transpilation syntax diagnostics: 0.
- Frontend dependency-backed typecheck and production build: not run; dependency installation previously timed out and `node_modules` is not present.
- Browser end-to-end, accessibility, mobile, and cross-browser tests: not run.

## 2026-11-11 — Research Workspace fieldwork UI increment
- `cd backend && PYTHONPATH=. pytest -q`: **61 passed**.
- `python -m py_compile app/*.py`: passed.
- TypeScript compiler `transpileModule` on `frontend/src/main.tsx`: **0 TSX/JSX syntax diagnostics**.
- Research regression coverage added for pseudonymous establishment creation, denial of interaction without matching permission, successful metadata-only interaction with granted permission, cross-tenant evidence-reference rejection on hypothesis creation, and tenant-scoped research dictionary records.
- Data-dictionary creation now writes an audit-log event.
- Frontend dependency install attempt failed with `EAI_AGAIN` resolving `registry.npmjs.org`; no dependency-backed TypeScript type-check or Vite build is claimed. No browser E2E, accessibility, mobile, cross-browser or production deployment test was run.


## 2026-11-12 package verification rerun
- Command: `cd backend && PYTHONPATH=. pytest -q`
- Result: **63 passed in 4.05s**.
- Command: `cd backend && python -m py_compile app/*.py`
- Result: passed.
- Frontend TSX syntax transpilation using the installed global TypeScript compiler: **0 diagnostics**.
- Not run: full `tsc -b`, Vite production build, browser E2E, accessibility, screenshot regression, load/concurrency, penetration, backup/restore, deployment.


## 2026-11-12 — Secure product CSV import increment
- Added authenticated, organization-scoped product CSV preview endpoint and a separate explicit commit endpoint.
- CSV preview enforces a 2 MB payload limit, 500-row limit, exact ordered header schema, required fields, field lengths, 3-letter ASCII currency codes, strict CSV parsing, and rejection of formula-like cell prefixes.
- Preview reports duplicate SKUs against the organization and within the file; preview does not write records.
- Commit revalidates values, requires write membership and an active trial/subscription, checks tenant SKU conflicts, and writes all products in one transaction. Costs and inventory are deliberately not fabricated or imported.
- Added frontend file selection, preview table, row issue display, explicit commit and discard controls.
- Regression suite: `PYTHONPATH=. pytest -q`: **67 passed in 4.65s**. Python compilation passed. TypeScript TSX transpilation: **0 diagnostics**.
- XLSX import, import history, import templates, full `tsc`/Vite build, browser E2E and accessibility tests remain outstanding.


## 2026-11-12 — XLSX import verification rerun
- Full backend suite after XLSX implementation: **69 passed in 5.39s**.
- This verifies backend tests only; it does not establish browser-level XLSX interaction or full frontend build.
