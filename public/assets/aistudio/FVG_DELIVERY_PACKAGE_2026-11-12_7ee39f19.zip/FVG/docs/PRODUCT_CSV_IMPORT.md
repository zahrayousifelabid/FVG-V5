# FVG Product CSV Import

## Supported schema

The import accepts UTF-8 CSV with exactly these headers in this order:

```csv
name,sku,unit,currency
Coffee 250g,CF250,pack,SDG
Tea 100g,TEA100,pack,SDG
```

`currency` may be blank (defaults to SDG) or a three-letter ASCII code. `sku` may be blank. Name and unit are required.

## Workflow

1. Authenticated organization member submits CSV text to `POST /api/v1/organizations/{org_id}/imports/products/preview`.
2. Preview validates syntax, size (2 MB maximum), row count (500 maximum), columns, required fields, field lengths, currency codes, formula-like prefixes and duplicate SKUs. It returns normalized rows and row-specific issues. It does not write records.
3. After reviewing a valid preview, a write-authorized member submits normalized rows to `POST /api/v1/organizations/{org_id}/imports/products/commit`.
4. Commit revalidates the rows and tenant SKU uniqueness, requires an active trial/subscription, and inserts all products in one SQLite transaction. A conflict or error rolls back the batch.

## Deliberate limits

- Only product master records are imported. No cost, material, BOM, inventory or research data is inferred.
- XLSX import, template download, import history, undo, background processing and streaming large-file support are not included.
- CSV parsing is strict and bounded. This is not a general spreadsheet sanitizer or a substitute for a full security review.
