from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    response = client.get('/health')
    assert response.status_code == 200
    assert response.json()['status'] == 'ok'

def test_total_cost_api():
    response = client.post('/api/v1/costs/total', json={'components':[10,20,5]})
    assert response.status_code == 200
    assert response.json()['total_cost'] == '35.00'

def test_unit_cost_api_rejects_zero_units():
    response = client.post('/api/v1/costs/unit', json={'total_allocated_cost':100,'good_saleable_units':0})
    assert response.status_code == 422

def test_break_even_api():
    response = client.post('/api/v1/analysis/break-even-units', json={'fixed_costs':1000,'selling_price':50,'variable_cost_per_unit':30})
    assert response.status_code == 200
    assert response.json()['break_even_units'] == '50'

def test_report_exports_require_authentication():
    for suffix in ('costing.xlsx','costing.pdf'):
        response=client.get(f'/api/v1/organizations/not-an-org/reports/{suffix}')
        assert response.status_code == 401
