# FVG Asset Registry

| Asset | Source | Treatment | Status / limitation |
|---|---|---|---|
| `brand/reference-screens/fvg-composite-reference.jpeg` | User-supplied `C3FC98AC-00B6-49F6-876E-CA4A164F22C3.jpeg` | Preserved byte-for-byte | Composite master reference |
| `brand/reference-screens/dashboard-reference.jpeg` | User-supplied `8E046484-5A30-47A6-A028-9224C5004DBB.jpeg` | Preserved byte-for-byte | Dashboard/brand reference |
| `brand/app-icon/app-icon-source.jpeg` | User-supplied `71212B78-C136-436B-84C8-D2436EE507C0.jpeg` | Preserved byte-for-byte | Supplied icon source; JPEG, not an original transparent PNG/vector |
| `brand/reference-screens/*-reference.jpeg` | Crops of composite reference | Cropped by listed visual regions; no redraw/recolor | Reference crops only; small labels/details inherit source resolution |
| `founder/01_zahra_researcher_portrait.png` | Original archive `assets/01_zahra_researcher_portrait.png` | Copied unchanged | Preserved; publication rights still require owner confirmation |
| `ben-alzahra/02_ben_alzahra_products.png` | Original archive `assets/02_ben_alzahra_products.png` | Copied unchanged | Separate commercial context; do not use as industrial field data |
| `quarantine-nobo/03_nobo_pasta_products.png` | Original archive | Preserved unchanged, excluded from active app/research | Specified for removal from active content, not deleted from original archive |
| `quarantine-nobo/04_nobo_noodles_products.png` | Original archive | Preserved unchanged, excluded from active app/research | Specified for removal from active content, not deleted from original archive |

No standalone original logo file or vector master was present as a separate file in the archive. The composite reference contains logo depictions; no claim is made that a standalone original SVG/vector has been extracted. No synthetic founder or product photography was created.
