# Deployment

Production deployment is not performed. Before deployment, complete authentication/RBAC/tenant isolation, persistence and migrations, security review, production CORS/HTTPS, backups and restore tests, monitoring, privacy/terms, and full regression/E2E testing. Configure secrets only in the hosting secret manager. Use PostgreSQL for production as recommended by the source technical specification. Do not expose the current development API publicly.
