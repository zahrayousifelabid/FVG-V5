import os, tempfile, uuid
from fastapi.testclient import TestClient

# Isolate persistent records for this test module before importing app.
_db=tempfile.mktemp(prefix='fvg-test-',suffix='.db')
os.environ['FVG_DATABASE_URL']='sqlite:///'+_db
from app.main import app
from app import storage
storage.DB_PATH=_db
storage.initialize()
client=TestClient(app)

def setup_user():
    r=client.post('/api/v1/auth/register',json={'email':f'{uuid.uuid4().hex}@example.com','password':'Long-Password-2026!','organization_name':'Factory A'})
    assert r.status_code==201, r.text
    data=r.json(); return data['organization_id'], {'Authorization':'Bearer '+data['session_token']}

def test_register_and_trial_72_hours():
    org,headers=setup_user()
    r=client.get(f'/api/v1/organizations/{org}/subscription',headers=headers)
    assert r.status_code==200
    assert r.json()['effective_status']=='trial'
    assert r.json()['payment_enabled'] is False

def test_tenant_scoped_product_and_cost_snapshot():
    org,headers=setup_user()
    p=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Coffee 250g','sku':'CF250','unit':'pack','currency':'SDG'})
    assert p.status_code==201,p.text
    r=client.post(f'/api/v1/organizations/{org}/costing',headers=headers,json={'product_id':p.json()['id'],'period':'2026-11','currency':'SDG','components':{'beans':1000,'packaging':100,'labor':200},'good_saleable_units':100,'selling_price':20})
    assert r.status_code==201,r.text
    assert r.json()['results']['unit_cost']=='13.00'
    assert r.json()['results']['profit_per_unit']=='7.00'
    other_org,other_headers=setup_user()
    denied=client.get(f'/api/v1/organizations/{org}/products',headers=other_headers)
    assert denied.status_code==404

def test_research_evidence_status_is_not_a_finding():
    org,headers=setup_user()
    r=client.post(f'/api/v1/organizations/{org}/research/evidence',headers=headers,json={'title':'Public inflation series','status':'Verified Public Source','source_ref':'official-source-id','notes':'To be reviewed'})
    assert r.status_code==201,r.text
    assert 'does not establish a research finding' in r.json()['notice']

def test_scenario_does_not_overwrite_base():
    org,headers=setup_user()
    p=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Product','sku':'P1','unit':'unit','currency':'SDG'}).json()
    snap=client.post(f'/api/v1/organizations/{org}/costing',headers=headers,json={'product_id':p['id'],'period':'2026-11','currency':'SDG','components':{'materials':100,'labor':50},'good_saleable_units':10,'selling_price':25}).json()
    scenario=client.post(f'/api/v1/organizations/{org}/scenarios',headers=headers,json={'snapshot_id':snap['snapshot_id'],'name':'Materials +10%','changes':{'materials':0.1}})
    assert scenario.status_code==201,scenario.text
    assert scenario.json()['label']=='What-if scenario — not a forecast'
    history=client.get(f'/api/v1/organizations/{org}/costing',headers=headers).json()
    assert history[0]['results']['total_cost']=='150.00'

def test_logout_revokes_session():
    org,headers=setup_user()
    assert client.get('/api/v1/organizations',headers=headers).status_code==200
    assert client.post('/api/v1/auth/logout',headers=headers).status_code==200
    assert client.get('/api/v1/organizations',headers=headers).status_code==401

def test_trial_expiration_blocks_new_cost_records():
    org,headers=setup_user()
    with storage.connect() as c:
        c.execute("UPDATE subscriptions SET trial_ends_at='2000-01-01T00:00:00+00:00' WHERE org_id=?",(org,))
    response=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Expired Trial Product','sku':'EXP','unit':'unit','currency':'SDG'})
    assert response.status_code==402

def test_login_returns_new_session():
    email=f'{uuid.uuid4().hex}@example.com'
    registered=client.post('/api/v1/auth/register',json={'email':email,'password':'Long-Password-2026!','organization_name':'Login Factory'})
    assert registered.status_code==201
    login=client.post('/api/v1/auth/login',json={'email':email,'password':'Long-Password-2026!'})
    assert login.status_code==200
    assert len(login.json()['session_token'])>30
    invalid=client.post('/api/v1/auth/login',json={'email':email,'password':'wrong-password'})
    assert invalid.status_code==401

def test_allocation_is_traceable_and_tenant_scoped():
    org,headers=setup_user()
    r=client.post(f'/api/v1/organizations/{org}/allocations',headers=headers,json={'pool_name':'Factory electricity','pool_cost':1000,'basis':'machine hours','driver':'machine hours','period':'2026-11','driver_quantities':[20,30,50],'selected_driver_quantity':20,'source_quantities':{'line_a_hours':20,'total_hours':100},'assumptions':'Metered hours supplied by user'})
    assert r.status_code==201,r.text
    data=r.json()
    assert data['allocated_cost']=='200.00'
    assert 'Selected Driver Quantity' in data['formula']
    other_org,other_headers=setup_user()
    assert client.get(f'/api/v1/organizations/{org}/allocations',headers=other_headers).status_code==404

def test_unit_conversion_requires_explicit_compatible_mapping():
    good=client.post('/api/v1/units/convert',json={'quantity':2,'from_unit':'kg','to_unit':'g','conversions':{'kg|g':1000}})
    assert good.status_code==200
    assert good.json()['quantity']=='2000.00'
    bad=client.post('/api/v1/units/convert',json={'quantity':2,'from_unit':'kg','to_unit':'litre','conversions':{}})
    assert bad.status_code==422

def test_bom_and_production_order_costing_includes_waste_and_saleable_yield():
    org,headers=setup_user()
    p=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Roasted coffee','sku':'RC1','unit':'bag','currency':'SDG'})
    assert p.status_code==201,p.text
    material=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Green beans','sku':'GB1','unit':'kg','currency':'SDG','unit_cost':100})
    assert material.status_code==201,material.text
    bom=client.post(f"/api/v1/organizations/{org}/products/{p.json()['id']}/bom",headers=headers,json={'material_id':material.json()['id'],'quantity_per_unit':0.5,'waste_rate':0.1})
    assert bom.status_code==201,bom.text
    order=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':p.json()['id'],'planned_units':100,'good_units':90,'period':'2026-11','currency':'SDG','conversion_cost':500,'overhead_cost':300})
    assert order.status_code==201,order.text
    data=order.json()
    assert data['material_cost']=='5500.00'
    assert data['total_cost']=='6300.00'
    assert data['unit_cost']=='70.00'
    assert data['good_saleable_units']=='90.0'
    assert 'Inventory is not posted' in data['notice']

def test_production_rejects_missing_bom_and_currency_mismatch():
    org,headers=setup_user()
    p=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Widget','sku':'W1','unit':'piece','currency':'SDG'}).json()
    missing=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':p['id'],'planned_units':10,'good_units':10,'period':'2026-11','currency':'SDG'})
    assert missing.status_code==422
    mat=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Resin','sku':'R1','unit':'kg','currency':'USD','unit_cost':4}).json()
    bom=client.post(f"/api/v1/organizations/{org}/products/{p['id']}/bom",headers=headers,json={'material_id':mat['id'],'quantity_per_unit':1})
    assert bom.status_code==422

def test_inventory_receipt_issue_balance_and_prevent_negative_stock():
    org,headers=setup_user()
    mat=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Sugar','sku':'SUGAR1','unit':'kg','currency':'SDG','unit_cost':50}).json()
    receipt=client.post(f'/api/v1/organizations/{org}/inventory/movements',headers=headers,json={'material_id':mat['id'],'movement_type':'receipt','quantity':20,'unit':'kg','unit_cost':50,'reference':'GRN-001'})
    assert receipt.status_code==201,receipt.text
    assert receipt.json()['on_hand']=='20.0'
    issue=client.post(f'/api/v1/organizations/{org}/inventory/movements',headers=headers,json={'material_id':mat['id'],'movement_type':'issue','quantity':7,'unit':'kg','unit_cost':50,'reference':'ISS-001'})
    assert issue.status_code==201,issue.text
    assert issue.json()['on_hand']=='13.0'
    too_much=client.post(f'/api/v1/organizations/{org}/inventory/movements',headers=headers,json={'material_id':mat['id'],'movement_type':'issue','quantity':14,'unit':'kg','unit_cost':50,'reference':'ISS-002'})
    assert too_much.status_code==422
    balances=client.get(f'/api/v1/organizations/{org}/inventory',headers=headers)
    assert balances.status_code==200
    assert balances.json()[0]['on_hand']==13.0

def test_research_permission_required_before_interaction_and_org_scoped():
    org,headers=setup_user()
    est=client.post(f'/api/v1/organizations/{org}/research/establishments',headers=headers,json={'pseudonym':'Plant-A','sector':'Food manufacturing','region':'River Nile'} )
    assert est.status_code==201,est.text
    eid=est.json()['id']
    denied=client.post(f'/api/v1/organizations/{org}/research/interactions',headers=headers,json={'establishment_id':eid,'interaction_type':'interview','participant_code':'P-01','occurred_on':'2026-11-09','permission_id':'missing'})
    assert denied.status_code==403
    pending=client.post(f'/api/v1/organizations/{org}/research/permissions',headers=headers,json={'establishment_id':eid,'permission_type':'interview','permission_status':'pending'})
    assert pending.status_code==201
    blocked=client.post(f'/api/v1/organizations/{org}/research/interactions',headers=headers,json={'establishment_id':eid,'interaction_type':'interview','participant_code':'P-01','occurred_on':'2026-11-09','permission_id':pending.json()['id']})
    assert blocked.status_code==403
    granted=client.post(f'/api/v1/organizations/{org}/research/permissions',headers=headers,json={'establishment_id':eid,'permission_type':'interview','permission_status':'granted','reference':'AUTH-001'})
    assert granted.status_code==201,granted.text
    interaction=client.post(f'/api/v1/organizations/{org}/research/interactions',headers=headers,json={'establishment_id':eid,'interaction_type':'interview','participant_code':'P-01','occurred_on':'2026-11-09','permission_id':granted.json()['id']})
    assert interaction.status_code==201,interaction.text
    other_org,other_headers=setup_user()
    assert client.get(f'/api/v1/organizations/{org}/research/interactions',headers=other_headers).status_code==404


def test_research_hypothesis_requires_org_evidence_for_assessed_status():
    org,headers=setup_user()
    hypothesis=client.post(f'/api/v1/organizations/{org}/research/hypotheses',headers=headers,json={'statement':'Input cost volatility affects industrial pricing decisions'})
    assert hypothesis.status_code==201,hypothesis.text
    hid=hypothesis.json()['id']
    no_evidence=client.patch(f'/api/v1/organizations/{org}/research/hypotheses/{hid}',headers=headers,json={'status':'supported','evidence_refs':[]})
    assert no_evidence.status_code==422
    evidence=client.post(f'/api/v1/organizations/{org}/research/evidence',headers=headers,json={'title':'Official published inflation series','status':'Verified Public Source','source_ref':'official-reference'})
    assert evidence.status_code==201
    assessed=client.patch(f'/api/v1/organizations/{org}/research/hypotheses/{hid}',headers=headers,json={'status':'under_review','evidence_refs':[evidence.json()['id']]})
    assert assessed.status_code==200,assessed.text
    foreign_org,foreign_headers=setup_user()
    assert client.patch(f'/api/v1/organizations/{foreign_org}/research/hypotheses/{hid}',headers=foreign_headers,json={'status':'supported','evidence_refs':[evidence.json()['id']]}).status_code==404


def test_research_dictionary_unique_variables_and_sensitivity_label():
    org,headers=setup_user()
    payload={'variable_name':'material_unit_cost','definition':'Recorded cost per base unit of material','data_type':'decimal','unit':'SDG/kg','sensitivity':'confidential_business'}
    created=client.post(f'/api/v1/organizations/{org}/research/data-dictionary',headers=headers,json=payload)
    assert created.status_code==201,created.text
    assert created.json()['sensitivity']=='confidential_business'
    duplicate=client.post(f'/api/v1/organizations/{org}/research/data-dictionary',headers=headers,json=payload)
    assert duplicate.status_code==409

def test_costing_csv_export_is_tenant_scoped_and_formula_safe():
    org,headers=setup_user()
    p=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'=HYPERLINK("bad")','sku':'SAFE1','unit':'unit','currency':'SDG'}).json()
    calc=client.post(f'/api/v1/organizations/{org}/costing',headers=headers,json={'product_id':p['id'],'period':'2026-11','currency':'SDG','components':{'materials':100,'labor':50},'good_saleable_units':10,'selling_price':20})
    assert calc.status_code==201,calc.text
    exported=client.get(f'/api/v1/organizations/{org}/reports/costing.csv',headers=headers)
    assert exported.status_code==200
    assert 'text/csv' in exported.headers['content-type']
    assert "'=HYPERLINK" in exported.text
    assert '150.00' in exported.text
    other,other_headers=setup_user()
    assert client.get(f'/api/v1/organizations/{org}/reports/costing.csv',headers=other_headers).status_code==404

def test_research_json_export_contains_only_org_records_and_labels_limitations():
    org,headers=setup_user()
    evidence=client.post(f'/api/v1/organizations/{org}/research/evidence',headers=headers,json={'title':'Test source','status':'Demo/Synthetic','source_ref':'demo-ref'})
    assert evidence.status_code==201
    exported=client.get(f'/api/v1/organizations/{org}/reports/research.json',headers=headers)
    assert exported.status_code==200
    data=exported.json()
    assert data['data']['evidence'][0]['title']=='Test source'
    assert 'does not assert findings' in data['notice']
    other,other_headers=setup_user()
    assert client.get(f'/api/v1/organizations/{org}/reports/research.json',headers=other_headers).status_code==404

def test_production_csv_export():
    org,headers=setup_user()
    p=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Product','sku':'P1','unit':'piece','currency':'SDG'}).json()
    mat=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Material','sku':'M1','unit':'kg','currency':'SDG','unit_cost':10}).json()
    client.post(f"/api/v1/organizations/{org}/products/{p['id']}/bom",headers=headers,json={'material_id':mat['id'],'quantity_per_unit':1})
    order=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':p['id'],'planned_units':5,'good_units':5,'period':'2026-11','currency':'SDG'})
    assert order.status_code==201
    report=client.get(f'/api/v1/organizations/{org}/reports/production.csv',headers=headers)
    assert report.status_code==200 and '10.00' in report.text


def test_production_stages_wip_completion_and_finished_goods_receipts():
    org,headers=setup_user()
    p=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Canned beans','sku':'CB1','unit':'case','currency':'SDG'}).json()
    m=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Beans','sku':'BEANS1','unit':'kg','currency':'SDG','unit_cost':20}).json()
    assert client.post(f"/api/v1/organizations/{org}/products/{p['id']}/bom",headers=headers,json={'material_id':m['id'],'quantity_per_unit':2,'waste_rate':0.05}).status_code==201
    order=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':p['id'],'planned_units':10,'good_units':9,'period':'2026-11','currency':'SDG','conversion_cost':100,'overhead_cost':50})
    assert order.status_code==201,order.text
    oid=order.json()['id']
    stage1=client.post(f'/api/v1/organizations/{org}/production-orders/{oid}/stages',headers=headers,json={'sequence_no':1,'stage_name':'Preparation','conversion_cost':30,'overhead_cost':10})
    stage2=client.post(f'/api/v1/organizations/{org}/production-orders/{oid}/stages',headers=headers,json={'sequence_no':2,'stage_name':'Packing','conversion_cost':20,'overhead_cost':5})
    assert stage1.status_code==201 and stage2.status_code==201
    wip=client.get(f'/api/v1/organizations/{org}/work-in-progress',headers=headers)
    assert wip.status_code==200 and wip.json()[0]['stage_count']==2
    assert wip.json()[0]['wip_recorded_cost']=='635.00'
    assert client.patch(f"/api/v1/organizations/{org}/production-orders/{oid}/stages/{stage1.json()['id']}",headers=headers,json={'status':'completed'}).status_code==409
    sid2=stage2.json()['id']
    assert client.patch(f'/api/v1/organizations/{org}/production-orders/{oid}/stages/{sid2}',headers=headers,json={'status':'in_progress'}).status_code==409
    for stage in (stage1,stage2):
        sid=stage.json()['id']
        assert client.patch(f'/api/v1/organizations/{org}/production-orders/{oid}/stages/{sid}',headers=headers,json={'status':'in_progress'}).status_code==200
        result=client.patch(f'/api/v1/organizations/{org}/production-orders/{oid}/stages/{sid}',headers=headers,json={'status':'completed'})
        assert result.status_code==200,result.text
    orders=client.get(f'/api/v1/organizations/{org}/production-orders',headers=headers).json()
    assert next(x for x in orders if x['id']==oid)['status']=='completed'
    receipt=client.post(f'/api/v1/organizations/{org}/production-orders/{oid}/finished-goods',headers=headers,json={'quantity':7,'reference':'FG-001'})
    assert receipt.status_code==201,receipt.text
    assert receipt.json()['completed_order_cost']=='635.00'
    assert receipt.json()['unit_cost']=='70.56'
    too_many=client.post(f'/api/v1/organizations/{org}/production-orders/{oid}/finished-goods',headers=headers,json={'quantity':3,'reference':'FG-002'})
    assert too_many.status_code==422
    stock=client.get(f'/api/v1/organizations/{org}/finished-goods',headers=headers)
    assert stock.status_code==200 and stock.json()[0]['on_hand']==7.0

def test_finished_goods_issue_cannot_make_negative_stock():
    org,headers=setup_user()
    p=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Bottle','sku':'B1','unit':'piece','currency':'SDG'}).json()
    issue=client.post(f'/api/v1/organizations/{org}/finished-goods/movements',headers=headers,json={'product_id':p['id'],'movement_type':'issue','quantity':1,'unit':'piece','unit_cost':5,'currency':'SDG','reference':'OUT-1'})
    assert issue.status_code==422

def test_inventory_fifo_and_weighted_average_valuations():
    org,headers=setup_user()
    mat=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Oil','sku':'OIL-LAYERS','unit':'litre','currency':'SDG','unit_cost':10}).json()
    for qty,cost,ref in [(10,10,'GRN-A'),(10,20,'GRN-B')]:
        r=client.post(f'/api/v1/organizations/{org}/inventory/movements',headers=headers,json={'material_id':mat['id'],'movement_type':'receipt','quantity':qty,'unit':'litre','unit_cost':cost,'reference':ref})
        assert r.status_code==201,r.text
    issue=client.post(f'/api/v1/organizations/{org}/inventory/movements',headers=headers,json={'material_id':mat['id'],'movement_type':'issue','quantity':5,'unit':'litre','unit_cost':10,'reference':'ISS-A'})
    assert issue.status_code==201
    fifo=client.get(f'/api/v1/organizations/{org}/inventory/valuation?method=fifo',headers=headers)
    avg=client.get(f'/api/v1/organizations/{org}/inventory/valuation?method=weighted_average',headers=headers)
    assert fifo.status_code==200 and avg.status_code==200
    assert fifo.json()['items'][0]['inventory_value']=='250.00'
    assert avg.json()['items'][0]['inventory_value']=='225.00'
    assert fifo.json()['items'][0]['quantity']=='15.0'


def test_production_order_can_atomically_issue_bom_materials_once():
    org,headers=setup_user()
    product=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Soap','sku':'SOAP-ISSUE','unit':'bar','currency':'SDG'}).json()
    material=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Base oil','sku':'BASE-OIL','unit':'kg','currency':'SDG','unit_cost':10}).json()
    assert client.post(f"/api/v1/organizations/{org}/products/{product['id']}/bom",headers=headers,json={'material_id':material['id'],'quantity_per_unit':0.5,'waste_rate':0.1}).status_code==201
    assert client.post(f'/api/v1/organizations/{org}/inventory/movements',headers=headers,json={'material_id':material['id'],'movement_type':'receipt','quantity':20,'unit':'kg','unit_cost':12,'reference':'GRN-PROD'}).status_code==201
    order=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':product['id'],'planned_units':10,'good_units':9,'period':'2026-11','currency':'SDG','conversion_cost':20,'overhead_cost':10})
    assert order.status_code==201,order.text
    issue=client.post(f"/api/v1/organizations/{org}/production-orders/{order.json()['id']}/issue-materials?method=fifo",headers=headers)
    assert issue.status_code==201,issue.text
    assert issue.json()['material_cost']=='66.00'
    assert issue.json()['unit_cost_per_good_unit']=='10.67'
    duplicate=client.post(f"/api/v1/organizations/{org}/production-orders/{order.json()['id']}/issue-materials",headers=headers)
    assert duplicate.status_code==409
    balances=client.get(f'/api/v1/organizations/{org}/inventory',headers=headers)
    assert balances.json()[0]['on_hand']==14.5


def test_finished_goods_fifo_and_weighted_average_valuation():
    org,headers=setup_user()
    product=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Glass jar','sku':'JAR-VALUATION','unit':'piece','currency':'SDG'}).json()
    for qty,cost,ref in [(10,10,'FG-REC-A'),(10,20,'FG-REC-B')]:
        r=client.post(f'/api/v1/organizations/{org}/finished-goods/movements',headers=headers,json={'product_id':product['id'],'movement_type':'adjustment','quantity':qty,'unit':'piece','unit_cost':cost,'currency':'SDG','reference':ref})
        assert r.status_code==201,r.text
    issue=client.post(f'/api/v1/organizations/{org}/finished-goods/movements',headers=headers,json={'product_id':product['id'],'movement_type':'issue','quantity':5,'unit':'piece','unit_cost':10,'currency':'SDG','reference':'FG-ISS-A'})
    assert issue.status_code==201,issue.text
    fifo=client.get(f'/api/v1/organizations/{org}/finished-goods/valuation?method=fifo',headers=headers)
    avg=client.get(f'/api/v1/organizations/{org}/finished-goods/valuation?method=weighted_average',headers=headers)
    assert fifo.status_code==200 and avg.status_code==200
    assert fifo.json()['items'][0]['quantity']=='15.0'
    assert fifo.json()['items'][0]['inventory_value']=='250.00'
    assert avg.json()['items'][0]['inventory_value']=='225.00'


def test_finished_goods_valuation_is_tenant_scoped():
    org,headers=setup_user()
    other_org,other_headers=setup_user()
    response=client.get(f'/api/v1/organizations/{org}/finished-goods/valuation',headers=other_headers)
    assert response.status_code==404

def test_material_stocktake_posts_signed_difference_and_reconciles_valuation():
    org,headers=setup_user()
    material=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Flour','sku':'FLR-ST','unit':'kg','currency':'SDG','unit_cost':10}).json()
    receipt=client.post(f'/api/v1/organizations/{org}/inventory/movements',headers=headers,json={'material_id':material['id'],'movement_type':'receipt','quantity':20,'unit':'kg','unit_cost':10,'reference':'opening-receipt'})
    assert receipt.status_code==201,receipt.text
    stocktake=client.post(f'/api/v1/organizations/{org}/inventory/stocktake',headers=headers,json={'material_id':material['id'],'counted_quantity':15,'unit':'kg','unit_cost':10,'reference':'count-001','notes':'Physical count reviewed'})
    assert stocktake.status_code==201,stocktake.text
    assert stocktake.json()['difference']=='-5.0'
    valuation=client.get(f'/api/v1/organizations/{org}/inventory/valuation?method=fifo',headers=headers)
    item=next(x for x in valuation.json()['items'] if x['material_id']==material['id'])
    assert item['quantity']=='15.0'
    assert item['inventory_value']=='150.00'
    duplicate=client.post(f'/api/v1/organizations/{org}/inventory/stocktake',headers=headers,json={'material_id':material['id'],'counted_quantity':12,'unit':'kg','unit_cost':10,'reference':'count-001'})
    assert duplicate.status_code==409


def test_finished_goods_stocktake_supports_positive_and_negative_differences():
    org,headers=setup_user()
    product=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Soap','sku':'SOAP-ST','unit':'piece','currency':'SDG'}).json()
    add=client.post(f'/api/v1/organizations/{org}/finished-goods/movements',headers=headers,json={'product_id':product['id'],'movement_type':'adjustment','quantity':10,'unit':'piece','unit_cost':25,'currency':'SDG','reference':'opening-stock'})
    assert add.status_code==201,add.text
    down=client.post(f'/api/v1/organizations/{org}/finished-goods/stocktake',headers=headers,json={'product_id':product['id'],'counted_quantity':8,'unit':'piece','unit_cost':25,'currency':'SDG','reference':'fg-count-1'})
    assert down.status_code==201,down.text
    assert down.json()['difference']=='-2.0'
    up=client.post(f'/api/v1/organizations/{org}/finished-goods/stocktake',headers=headers,json={'product_id':product['id'],'counted_quantity':12,'unit':'piece','unit_cost':30,'currency':'SDG','reference':'fg-count-2'})
    assert up.status_code==201,up.text
    valuation=client.get(f'/api/v1/organizations/{org}/finished-goods/valuation?method=fifo',headers=headers)
    item=next(x for x in valuation.json()['items'] if x['product_id']==product['id'])
    assert item['quantity']=='12.0'
    assert item['inventory_value']=='320.00'


def test_stage_labor_capture_is_costed_audited_and_tenant_scoped():
    org,headers=setup_user()
    product=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Bottled juice','sku':'JUICE-LAB','unit':'bottle','currency':'SDG'}).json()
    material=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Juice concentrate','sku':'JC-LAB','unit':'kg','currency':'SDG','unit_cost':10}).json()
    assert client.post(f"/api/v1/organizations/{org}/products/{product['id']}/bom",headers=headers,json={'material_id':material['id'],'quantity_per_unit':1}).status_code==201
    order=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':product['id'],'planned_units':10,'good_units':10,'period':'2026-11','currency':'SDG'}).json()
    stage=client.post(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages",headers=headers,json={'sequence_no':1,'stage_name':'Filling','conversion_cost':5,'overhead_cost':2})
    assert stage.status_code==201,stage.text
    sid=stage.json()['id']
    started=client.patch(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{sid}",headers=headers,json={'status':'in_progress'})
    assert started.status_code==200
    labor=client.post(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{sid}/labor",headers=headers,json={'worker_code':'W-01','work_description':'Filling line operation','hours':2.5,'hourly_rate':40,'currency':'SDG','occurred_on':'2026-11-10'})
    assert labor.status_code==201,labor.text
    assert labor.json()['labor_cost']=='100.00'
    stages=client.get(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages",headers=headers).json()
    assert stages[0]['conversion_cost']=='105.00'
    entries=client.get(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{sid}/labor",headers=headers)
    assert entries.status_code==200
    assert entries.json()['total_labor_cost']=='100.00'
    assert entries.json()['count']==1
    mismatch=client.post(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{sid}/labor",headers=headers,json={'work_description':'Wrong currency','hours':1,'hourly_rate':10,'currency':'USD','occurred_on':'2026-11-10'})
    assert mismatch.status_code==422
    other,other_headers=setup_user()
    assert client.get(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{sid}/labor",headers=other_headers).status_code==404


def test_stage_labor_rejected_until_stage_is_started_and_after_completion():
    org,headers=setup_user()
    product=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Soap','sku':'SOAP-LAB','unit':'bar','currency':'SDG'}).json()
    material=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Oil','sku':'OIL-LAB','unit':'kg','currency':'SDG','unit_cost':2}).json()
    client.post(f"/api/v1/organizations/{org}/products/{product['id']}/bom",headers=headers,json={'material_id':material['id'],'quantity_per_unit':1})
    order=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':product['id'],'planned_units':2,'good_units':2,'period':'2026-11','currency':'SDG'}).json()
    stage=client.post(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages",headers=headers,json={'sequence_no':1,'stage_name':'Mixing'}).json()
    url=f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{stage['id']}/labor"
    payload={'work_description':'Mixing work','hours':1,'hourly_rate':10,'currency':'SDG','occurred_on':'2026-11-10'}
    assert client.post(url,headers=headers,json=payload).status_code==409
    assert client.patch(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{stage['id']}",headers=headers,json={'status':'in_progress'}).status_code==200
    assert client.post(url,headers=headers,json=payload).status_code==201
    assert client.patch(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{stage['id']}",headers=headers,json={'status':'completed'}).status_code==200
    assert client.post(url,headers=headers,json=payload).status_code==409

def test_stage_material_consumption_and_scrap_are_tracked_and_costed():
    org,headers=setup_user()
    product=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Biscuit','sku':'BIS1','unit':'pack','currency':'SDG'}).json()
    material=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Flour','sku':'FLR1','unit':'kg','currency':'SDG','unit_cost':10}).json()
    receipt=client.post(f'/api/v1/organizations/{org}/inventory/movements',headers=headers,json={'material_id':material['id'],'movement_type':'receipt','quantity':20,'unit':'kg','unit_cost':10,'reference':'opening-flour'})
    assert receipt.status_code==201,receipt.text
    bom=client.post(f'/api/v1/organizations/{org}/products/{product["id"]}/bom',headers=headers,json={'material_id':material['id'],'quantity_per_unit':0.1,'waste_rate':0})
    assert bom.status_code==201,bom.text
    order=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':product['id'],'planned_units':10,'good_units':9,'period':'2026-11','currency':'SDG','conversion_cost':20,'overhead_cost':5})
    assert order.status_code==201,order.text
    stage=client.post(f'/api/v1/organizations/{org}/production-orders/{order.json()["id"]}/stages',headers=headers,json={'sequence_no':1,'stage_name':'Mixing'})
    assert stage.status_code==201,stage.text
    sid=stage.json()['id']; oid=order.json()['id']
    assert client.patch(f'/api/v1/organizations/{org}/production-orders/{oid}/stages/{sid}',headers=headers,json={'status':'in_progress'}).status_code==200
    used=client.post(f'/api/v1/organizations/{org}/production-orders/{oid}/stages/{sid}/materials',headers=headers,json={'material_id':material['id'],'quantity':3,'unit':'kg','valuation_method':'fifo','reference':'mix-flour-001'})
    assert used.status_code==201,used.text
    assert used.json()['total_cost']=='30.00'
    assert used.json()['order_material_cost']=='30.00'
    scrap=client.post(f'/api/v1/organizations/{org}/production-orders/{oid}/stages/{sid}/scrap',headers=headers,json={'scrap_units':1,'unit':'pack','reason':'Batch quality rejection','occurred_on':'2026-11-10'})
    assert scrap.status_code==201,scrap.text
    listing=client.get(f'/api/v1/organizations/{org}/production-orders/{oid}/stages/{sid}/materials',headers=headers)
    assert listing.json()['total_material_cost']=='30.00'
    assert client.get(f'/api/v1/organizations/{org}/inventory/valuation?method=fifo',headers=headers).json()['items'][0]['quantity']=='17.0'
    other_org,other_headers=setup_user()
    assert client.get(f'/api/v1/organizations/{org}/production-orders/{oid}/stages/{sid}/materials',headers=other_headers).status_code==404

def test_scrap_analysis_reports_provisional_yield_and_cost_without_posting_changes():
    org,headers=setup_user()
    product=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Juice','sku':'JCE-SCRAP-AN','unit':'bottle','currency':'SDG'}).json()
    mat=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Fruit','sku':'FRUIT-SCRAP-AN','unit':'kg','currency':'SDG','unit_cost':0}).json()
    assert client.post(f"/api/v1/organizations/{org}/products/{product['id']}/bom",headers=headers,json={'material_id':mat['id'],'quantity_per_unit':0.1}).status_code==201
    order=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':product['id'],'planned_units':100,'good_units':94,'period':'2026-11','currency':'SDG','conversion_cost':300,'overhead_cost':100}).json()
    oid=order['id']
    stage1=client.post(f'/api/v1/organizations/{org}/production-orders/{oid}/stages',headers=headers,json={'sequence_no':1,'stage_name':'Filling'}).json()
    stage2=client.post(f'/api/v1/organizations/{org}/production-orders/{oid}/stages',headers=headers,json={'sequence_no':2,'stage_name':'Packing'}).json()
    for index,(stage,qty) in enumerate([(stage1,3),(stage2,2)]):
        assert client.patch(f"/api/v1/organizations/{org}/production-orders/{oid}/stages/{stage['id']}",headers=headers,json={'status':'in_progress'}).status_code==200
        result=client.post(f"/api/v1/organizations/{org}/production-orders/{oid}/stages/{stage['id']}/scrap",headers=headers,json={'scrap_units':qty,'unit':'bottle','reason':'Quality rejection','occurred_on':'2026-11-10'})
        assert result.status_code==201,result.text
        if index==0:
            assert client.patch(f"/api/v1/organizations/{org}/production-orders/{oid}/stages/{stage['id']}",headers=headers,json={'status':'completed'}).status_code==200
    analysis=client.get(f'/api/v1/organizations/{org}/production-orders/{oid}/scrap-analysis',headers=headers)
    assert analysis.status_code==200,analysis.text
    data=analysis.json()
    assert data['recorded_stage_scrap_units']=='5.0'
    assert data['indicative_good_units_if_stage_losses_are_distinct']=='95.0'
    assert data['indicative_cost_per_unit_after_scrap']=='4.21'
    assert data['status']=='provisional_analysis_only'
    # Analysis must not mutate the authoritative order output or cost.
    with storage.connect() as db:
        saved=db.execute('SELECT good_units,total_cost FROM production_orders WHERE id=?',(oid,)).fetchone()
    assert saved['good_units']=='94.0'
    assert saved['total_cost']=='400.00'
    other_org,other_headers=setup_user()
    assert client.get(f'/api/v1/organizations/{org}/production-orders/{oid}/scrap-analysis',headers=other_headers).status_code==404

def test_standard_vs_actual_production_variances_are_componentized_and_versioned():
    org,headers=setup_user()
    product=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Standard widget','sku':'STD-W','unit':'piece','currency':'SDG'}).json()
    material=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Steel','sku':'STL','unit':'kg','currency':'SDG','unit_cost':5}).json()
    standard_payload={'currency':'SDG','materials':[{'material_id':material['id'],'quantity_per_good_unit':2,'standard_unit_cost':5}],'labor_hours_per_good_unit':0.5,'standard_labor_hourly_rate':10,'overhead_per_good_unit':3}
    standard=client.post(f"/api/v1/organizations/{org}/products/{product['id']}/standard-costs",headers=headers,json=standard_payload)
    assert standard.status_code==201,standard.text
    standard2=client.post(f"/api/v1/organizations/{org}/products/{product['id']}/standard-costs",headers=headers,json=standard_payload)
    assert standard2.status_code==201 and standard2.json()['version']==2
    client.post(f"/api/v1/organizations/{org}/products/{product['id']}/bom",headers=headers,json={'material_id':material['id'],'quantity_per_unit':2})
    order=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':product['id'],'planned_units':10,'good_units':10,'period':'2026-11','currency':'SDG','conversion_cost':0,'overhead_cost':20}).json()
    stage=client.post(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages",headers=headers,json={'sequence_no':1,'stage_name':'Assembly'}).json()
    started=client.patch(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{stage['id']}",headers=headers,json={'status':'in_progress'})
    assert started.status_code==200
    receipt=client.post(f'/api/v1/organizations/{org}/inventory/movements',headers=headers,json={'material_id':material['id'],'movement_type':'receipt','quantity':30,'unit':'kg','unit_cost':6,'reference':'STD-VAR-GRN'})
    assert receipt.status_code==201
    consumption=client.post(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{stage['id']}/materials",headers=headers,json={'material_id':material['id'],'quantity':22,'unit':'kg','valuation_method':'weighted_average','reference':'STD-VAR-ISS'})
    assert consumption.status_code==201,consumption.text
    labor=client.post(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{stage['id']}/labor",headers=headers,json={'work_description':'Assembly work','hours':6,'hourly_rate':12,'currency':'SDG','occurred_on':'2026-11-11'})
    assert labor.status_code==201,labor.text
    variance=client.get(f"/api/v1/organizations/{org}/production-orders/{order['id']}/variance",headers=headers)
    assert variance.status_code==200,variance.text
    data=variance.json()
    assert data['standard_version']==2
    assert data['materials'][0]['price_variance']=='22.00'
    assert data['materials'][0]['usage_variance']=='10.00'
    assert data['labor']['rate_variance']=='12.00'
    assert data['labor']['efficiency_variance']=='10.00'
    assert data['overhead']['variance']=='-10.00'
    assert data['total_variance']=='44.00'


def test_variance_does_not_assume_missing_actual_material_is_zero():
    org,headers=setup_user()
    product=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Incomplete actual','sku':'INC-A','unit':'piece','currency':'SDG'}).json()
    material=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Copper','sku':'COP','unit':'kg','currency':'SDG','unit_cost':10}).json()
    standard=client.post(f"/api/v1/organizations/{org}/products/{product['id']}/standard-costs",headers=headers,json={'currency':'SDG','materials':[{'material_id':material['id'],'quantity_per_good_unit':1,'standard_unit_cost':10}]})
    assert standard.status_code==201
    client.post(f"/api/v1/organizations/{org}/products/{product['id']}/bom",headers=headers,json={'material_id':material['id'],'quantity_per_unit':1})
    order=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':product['id'],'planned_units':5,'good_units':5,'period':'2026-11','currency':'SDG'}).json()
    result=client.get(f"/api/v1/organizations/{org}/production-orders/{order['id']}/variance",headers=headers)
    assert result.status_code==200
    assert result.json()['material_variance'] is None
    assert result.json()['completeness']['materials'] is False
    assert result.json()['total_variance'] is None


def test_machine_hours_efficiency_and_capacity_analysis():
    org,headers=setup_user()
    product=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Machine part','sku':'MCH-PART','unit':'piece','currency':'SDG'}).json()
    material=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Alloy','sku':'MCH-ALLOY','unit':'kg','currency':'SDG','unit_cost':2}).json()
    standard=client.post(f"/api/v1/organizations/{org}/products/{product['id']}/standard-costs",headers=headers,json={'currency':'SDG','materials':[{'material_id':material['id'],'quantity_per_good_unit':1,'standard_unit_cost':2}],'machine_hours_per_good_unit':0.2,'budgeted_machine_hours':50,'fixed_overhead_budget':500})
    assert standard.status_code==201,standard.text
    client.post(f"/api/v1/organizations/{org}/products/{product['id']}/bom",headers=headers,json={'material_id':material['id'],'quantity_per_unit':1})
    order=client.post(f'/api/v1/organizations/{org}/production-orders',headers=headers,json={'product_id':product['id'],'planned_units':12,'good_units':10,'period':'2026-11','currency':'SDG'}).json()
    stage=client.post(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages",headers=headers,json={'sequence_no':1,'stage_name':'Machining'}).json()
    denied=client.post(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{stage['id']}/machine-hours",headers=headers,json={'description':'CNC operation','machine_hours':3,'occurred_on':'2026-11-11'})
    assert denied.status_code==409
    assert client.patch(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{stage['id']}",headers=headers,json={'status':'in_progress'}).status_code==200
    logged=client.post(f"/api/v1/organizations/{org}/production-orders/{order['id']}/stages/{stage['id']}/machine-hours",headers=headers,json={'machine_code':'CNC-01','description':'Cutting operation','machine_hours':3,'occurred_on':'2026-11-11'})
    assert logged.status_code==201,logged.text
    listing=client.get(f"/api/v1/organizations/{org}/production-orders/{order['id']}/machine-hours",headers=headers)
    assert listing.json()['total_machine_hours']=='3.0'
    variance=client.get(f"/api/v1/organizations/{org}/production-orders/{order['id']}/variance",headers=headers)
    assert variance.status_code==200,variance.text
    machine=variance.json()['overhead']['machine_hours']
    assert machine['standard_machine_hours_allowed']=='2.00'
    assert machine['actual_machine_hours']=='3.0'
    assert machine['machine_hour_efficiency_variance']=='10.00'
    assert machine['capacity_volume_variance']=='480.00'
    assert machine['idle_capacity_hours']=='47.0'
    other_org,other_headers=setup_user()
    assert client.get(f"/api/v1/organizations/{org}/production-orders/{order['id']}/machine-hours",headers=other_headers).status_code==404


def test_machine_standard_requires_complete_capacity_inputs():
    org,headers=setup_user()
    product=client.post(f'/api/v1/organizations/{org}/products',headers=headers,json={'name':'Press item','sku':'PRESS-1','unit':'piece','currency':'SDG'}).json()
    material=client.post(f'/api/v1/organizations/{org}/materials',headers=headers,json={'name':'Sheet','sku':'SHEET-1','unit':'kg','currency':'SDG','unit_cost':1}).json()
    response=client.post(f"/api/v1/organizations/{org}/products/{product['id']}/standard-costs",headers=headers,json={'currency':'SDG','materials':[{'material_id':material['id'],'quantity_per_good_unit':1,'standard_unit_cost':1}],'machine_hours_per_good_unit':0.5})
    assert response.status_code==422


def test_research_fieldwork_requires_permission_and_keeps_pseudonyms():
    org, headers = setup_user()
    establishment = client.post(
        f'/api/v1/organizations/{org}/research/establishments', headers=headers,
        json={'pseudonym':'EST-001','sector':'Food manufacturing','region':'Khartoum','participation_status':'approved','notes':'Pseudonym only'}
    )
    assert establishment.status_code == 201, establishment.text
    eid = establishment.json()['id']
    no_permission = client.post(
        f'/api/v1/organizations/{org}/research/interactions', headers=headers,
        json={'establishment_id':eid,'interaction_type':'interview','participant_code':'P-001','occurred_on':'2026-11-11','permission_id':'missing','record_status':'metadata_only','notes':''}
    )
    assert no_permission.status_code == 403
    permission = client.post(
        f'/api/v1/organizations/{org}/research/permissions', headers=headers,
        json={'establishment_id':eid,'permission_type':'interview','permission_status':'granted','reference':'CONSENT-001','valid_from':'2026-11-01','valid_until':'2026-12-01','notes':'Verified outside system'}
    )
    assert permission.status_code == 201, permission.text
    interaction = client.post(
        f'/api/v1/organizations/{org}/research/interactions', headers=headers,
        json={'establishment_id':eid,'interaction_type':'interview','participant_code':'P-001','occurred_on':'2026-11-11','permission_id':permission.json()['id'],'record_status':'metadata_only','notes':'Metadata only'}
    )
    assert interaction.status_code == 201, interaction.text
    assert 'no research finding' in interaction.json()['notice']


def test_research_hypothesis_rejects_foreign_evidence_reference():
    org, headers = setup_user()
    other_org, other_headers = setup_user()
    evidence = client.post(
        f'/api/v1/organizations/{other_org}/research/evidence', headers=other_headers,
        json={'title':'External record','status':'Verified Public Source','source_ref':'REF-1','notes':''}
    ).json()
    response = client.post(
        f'/api/v1/organizations/{org}/research/hypotheses', headers=headers,
        json={'statement':'Material price changes affect unit costs','status':'proposed','evidence_refs':[evidence['id']],'notes':''}
    )
    assert response.status_code == 422


def test_research_dictionary_is_tenant_scoped_and_audited():
    org, headers = setup_user()
    other_org, other_headers = setup_user()
    created = client.post(
        f'/api/v1/organizations/{org}/research/data-dictionary', headers=headers,
        json={'variable_name':'material_price','definition':'Observed purchase price per kilogram','data_type':'decimal','unit':'SDG/kg','allowed_values':'','sensitivity':'confidential_business'}
    )
    assert created.status_code == 201, created.text
    assert len(client.get(f'/api/v1/organizations/{org}/research/data-dictionary',headers=headers).json()) == 1
    assert client.get(f'/api/v1/organizations/{org}/research/data-dictionary',headers=other_headers).status_code == 404

def test_research_instrument_response_and_immutable_cleaning_log():
    org,headers=setup_user()
    est=client.post(f'/api/v1/organizations/{org}/research/establishments',headers=headers,json={'pseudonym':'Factory-01','sector':'Food processing'}).json()
    perm=client.post(f'/api/v1/organizations/{org}/research/permissions',headers=headers,json={'establishment_id':est['id'],'permission_type':'survey','permission_status':'granted','reference':'CONSENT-01'}).json()
    interaction=client.post(f'/api/v1/organizations/{org}/research/interactions',headers=headers,json={'establishment_id':est['id'],'interaction_type':'survey','participant_code':'P-001','occurred_on':'2026-11-11','permission_id':perm['id']}).json()
    instrument=client.post(f'/api/v1/organizations/{org}/research/instruments',headers=headers,json={'title':'Pricing Practices','instrument_type':'survey','status':'active','fields':[{'name':'pricing_method','type':'category','required':True,'allowed_values':['cost_plus','market_based']},{'name':'monthly_output','type':'integer','required':False} ]})
    assert instrument.status_code==201,instrument.text
    response=client.post(f'/api/v1/organizations/{org}/research/responses',headers=headers,json={'instrument_id':instrument.json()['id'],'interaction_id':interaction['id'],'response':{'pricing_method':'cost_plus','monthly_output':120},'review_status':'pending_review'})
    assert response.status_code==201,response.text
    rid=response.json()['id']
    clean=client.post(f'/api/v1/organizations/{org}/research/responses/{rid}/cleaning-log',headers=headers,json={'variable_name':'monthly_output','issue_type':'outlier','action_taken':'Flag for verification against source record','outcome':'flagged_only'})
    assert clean.status_code==201,clean.text
    listed=client.get(f'/api/v1/organizations/{org}/research/responses',headers=headers).json()
    assert listed[0]['response']['monthly_output']==120
    assert client.get(f'/api/v1/organizations/{org}/research/cleaning-logs',headers=headers).json()[0]['outcome']=='flagged_only'

def test_research_response_rejects_undefined_field_and_cross_tenant():
    org,headers=setup_user()
    est=client.post(f'/api/v1/organizations/{org}/research/establishments',headers=headers,json={'pseudonym':'Factory-02','sector':'Textiles'}).json()
    perm=client.post(f'/api/v1/organizations/{org}/research/permissions',headers=headers,json={'establishment_id':est['id'],'permission_type':'interview','permission_status':'granted','reference':'CONSENT-02'}).json()
    interaction=client.post(f'/api/v1/organizations/{org}/research/interactions',headers=headers,json={'establishment_id':est['id'],'interaction_type':'interview','participant_code':'P-002','occurred_on':'2026-11-11','permission_id':perm['id']}).json()
    instrument=client.post(f'/api/v1/organizations/{org}/research/instruments',headers=headers,json={'title':'Interview Guide','instrument_type':'interview','status':'active','fields':[{'name':'cost_system','type':'text','required':True}] }).json()
    invalid=client.post(f'/api/v1/organizations/{org}/research/responses',headers=headers,json={'instrument_id':instrument['id'],'interaction_id':interaction['id'],'response':{'cost_system':'standard','unapproved':'secret'}})
    assert invalid.status_code==422
    other_org,other_headers=setup_user()
    hidden=client.get(f'/api/v1/organizations/{org}/research/responses',headers=other_headers)
    assert hidden.status_code==404

def test_product_csv_preview_is_read_only_and_reports_duplicate_skus():
    org,headers=setup_user()
    csv_text='name,sku,unit,currency\nCoffee,CF1,bag,sdg\nTea,CF1,box,SDG\n'
    preview=client.post(f'/api/v1/organizations/{org}/imports/products/preview',headers=headers,json={'csv_text':csv_text})
    assert preview.status_code==200,preview.text
    data=preview.json()
    assert data['row_count']==2 and data['valid'] is False
    assert data['issues'][0]['message']=='Duplicate SKU within this file'
    assert client.get(f'/api/v1/organizations/{org}/products',headers=headers).json()==[]

def test_product_csv_preview_rejects_formula_like_cells_and_bad_headers():
    org,headers=setup_user()
    formula=client.post(f'/api/v1/organizations/{org}/imports/products/preview',headers=headers,json={'csv_text':'name,sku,unit,currency\n=HYPERLINK("x"),A1,bag,SDG\n'})
    assert formula.status_code==422
    headers_bad=client.post(f'/api/v1/organizations/{org}/imports/products/preview',headers=headers,json={'csv_text':'name,unit,sku,currency\nCoffee,bag,C1,SDG\n'})
    assert headers_bad.status_code==422

def test_product_csv_commit_is_explicit_atomic_and_tenant_scoped():
    org,headers=setup_user()
    rows=[{'name':'Coffee','sku':'CF1','unit':'bag','currency':'SDG'},{'name':'Tea','sku':'T1','unit':'box','currency':'SDG'}]
    preview=client.post(f'/api/v1/organizations/{org}/imports/products/preview',headers=headers,json={'csv_text':'name,sku,unit,currency\nCoffee,CF1,bag,SDG\nTea,T1,box,SDG\n'})
    assert preview.status_code==200 and preview.json()['valid'] is True
    committed=client.post(f'/api/v1/organizations/{org}/imports/products/commit',headers=headers,json={'rows':rows})
    assert committed.status_code==201,committed.text
    assert committed.json()['imported_count']==2
    assert len(client.get(f'/api/v1/organizations/{org}/products',headers=headers).json())==2
    duplicate=client.post(f'/api/v1/organizations/{org}/imports/products/commit',headers=headers,json={'rows':[{'name':'New','sku':'CF1','unit':'unit','currency':'SDG'}]})
    assert duplicate.status_code==409
    assert len(client.get(f'/api/v1/organizations/{org}/products',headers=headers).json())==2
    other_org,other_headers=setup_user()
    denied=client.post(f'/api/v1/organizations/{org}/imports/products/commit',headers=other_headers,json={'rows':[{'name':'No','sku':'N1','unit':'unit','currency':'SDG'}]})
    assert denied.status_code==404

def test_product_csv_commit_rejects_duplicate_rows_before_writing():
    org,headers=setup_user()
    rows=[{'name':'A','sku':'DUP','unit':'unit','currency':'SDG'},{'name':'B','sku':'DUP','unit':'unit','currency':'SDG'}]
    response=client.post(f'/api/v1/organizations/{org}/imports/products/commit',headers=headers,json={'rows':rows})
    assert response.status_code==422
    assert client.get(f'/api/v1/organizations/{org}/products',headers=headers).json()==[]

def test_xlsx_product_import_preview_is_read_only_and_validates_rows():
    import base64
    from io import BytesIO
    from openpyxl import Workbook
    org,headers=setup_user()
    wb=Workbook(); ws=wb.active
    ws.append(['name','sku','unit','currency'])
    ws.append(['Coffee 250g','CF250','pack','SDG'])
    buf=BytesIO(); wb.save(buf)
    response=client.post(f'/api/v1/organizations/{org}/imports/products/xlsx/preview',headers=headers,json={'xlsx_base64':base64.b64encode(buf.getvalue()).decode()})
    assert response.status_code==200,response.text
    body=response.json()
    assert body['valid'] is True and body['row_count']==1
    assert body['rows'][0]['sku']=='CF250'
    products=client.get(f'/api/v1/organizations/{org}/products',headers=headers)
    assert products.status_code==200
    assert all(p.get('sku')!='CF250' for p in products.json())


def test_xlsx_product_import_rejects_formula_cells():
    import base64
    from io import BytesIO
    from openpyxl import Workbook
    org,headers=setup_user()
    wb=Workbook(); ws=wb.active
    ws.append(['name','sku','unit','currency'])
    ws.append(['=1+1','SKU1','pack','SDG'])
    buf=BytesIO(); wb.save(buf)
    response=client.post(f'/api/v1/organizations/{org}/imports/products/xlsx/preview',headers=headers,json={'xlsx_base64':base64.b64encode(buf.getvalue()).decode()})
    assert response.status_code==422
