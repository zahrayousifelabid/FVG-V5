package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.example.domain.engine.FvgFinancialEngine
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

@Composable
fun FvgTopHeaderBanner(
    title: String,
    subtitle: String,
    icon: ImageVector,
    isArabic: Boolean,
    isDark: Boolean,
    onToggleLanguage: () -> Unit,
    onToggleTheme: () -> Unit,
    orgName: String? = null,
    roleBadge: String? = null,
    userInitials: String? = null,
    unreadNotificationsCount: Int = 0,
    onNotificationsClick: (() -> Unit)? = null
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(24.dp),
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(FvgDeepGreen, FvgForestGreen)
                    )
                )
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = FvgWarmGold.copy(alpha = 0.16f),
                        border = BorderStroke(1.dp, FvgWarmGold.copy(alpha = 0.45f)),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (!userInitials.isNullOrBlank()) {
                                Text(
                                    text = userInitials.take(2).uppercase(),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = FvgWarmGold
                                )
                            } else {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = title,
                                    tint = FvgWarmGold,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleLarge,
                            color = FvgWarmIvory,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (!orgName.isNullOrBlank()) "$orgName • $subtitle" else subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = FvgWarmGold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (!roleBadge.isNullOrBlank()) {
                                Spacer(Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = FvgWarmIvory.copy(alpha = 0.14f)
                                ) {
                                    Text(
                                        text = roleBadge.uppercase(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = FvgWarmIvory,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onNotificationsClick != null) {
                        IconButton(
                            onClick = onNotificationsClick,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("notifications_bell_button")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (unreadNotificationsCount > 0) {
                                        Badge(containerColor = FvgWarmGold, contentColor = FvgDeepGreen) {
                                            Text(unreadNotificationsCount.coerceAtMost(99).toString())
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Notifications,
                                    contentDescription = if (isArabic) "الإشعارات" else "Notifications",
                                    tint = FvgWarmIvory,
                                    modifier = Modifier.size(21.dp)
                                )
                            }
                        }
                    }
                    IconButton(
                        onClick = onToggleLanguage,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("toggle_language_button")
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Filled.Language,
                                contentDescription = if (isArabic) "Switch to English" else "التبديل إلى العربية",
                                tint = FvgWarmGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = if (isArabic) "EN" else "AR",
                                style = MaterialTheme.typography.labelSmall,
                                color = FvgWarmIvory
                            )
                        }
                    }
                    IconButton(
                        onClick = onToggleTheme,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("toggle_theme_button")
                    ) {
                        Icon(
                            imageVector = if (isDark) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                            contentDescription = "Toggle theme",
                            tint = FvgWarmIvory,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FvgSubTabRow(
    tabs: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    testTagPrefix: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        tabs.forEachIndexed { idx, label ->
            val selected = idx == selectedIndex
            Surface(
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .clickable(role = Role.Tab) { onSelect(idx) }
                    .testTag("${testTagPrefix}_tab_$idx"),
                shape = RoundedCornerShape(24.dp),
                color = if (selected) FvgDeepGreen else MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(
                    1.dp,
                    if (selected) FvgWarmGold else MaterialTheme.colorScheme.outline
                )
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (selected) FvgWarmGold else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun FvgCard(
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
fun FvgField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    numeric: Boolean = false,
    singleLine: Boolean = true,
    enabled: Boolean = true,
    testTag: String? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        singleLine = singleLine,
        enabled = enabled,
        keyboardOptions = if (numeric) KeyboardOptions(keyboardType = KeyboardType.Decimal) else KeyboardOptions.Default,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .fillMaxWidth()
            .let { if (testTag != null) it.testTag(testTag) else it }
    )
}

@Composable
fun FvgPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    testTag: String? = null
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = FvgDeepGreen,
            contentColor = FvgWarmIvory
        ),
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .let { if (testTag != null) it.testTag(testTag) else it }
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = FvgWarmGold, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun FvgGoldButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    testTag: String? = null
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = FvgWarmGold,
            contentColor = FvgDeepGreen
        ),
        modifier = modifier
            .heightIn(min = 48.dp)
            .let { if (testTag != null) it.testTag(testTag) else it }
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun FvgChipSelector(
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    labelResolver: (String) -> String = { it }
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { opt ->
            FilterChip(
                selected = opt == selected,
                onClick = { onSelect(opt) },
                label = { Text(labelResolver(opt)) },
                modifier = Modifier.heightIn(min = 48.dp)
            )
        }
    }
}

@Composable
fun FvgEmptyStateCard(message: String) {
    FvgCard(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Outlined.Info,
                contentDescription = null,
                tint = FvgAntiqueGold,
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun FvgSparklineCanvas(
    values: List<Float>,
    lineColor: Color = FvgWarmGold,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (values.size < 2) {
            drawLine(
                color = lineColor.copy(alpha = 0.5f),
                start = Offset(0f, size.height * 0.6f),
                end = Offset(size.width, size.height * 0.6f),
                strokeWidth = 3f,
                cap = StrokeCap.Round
            )
            return@Canvas
        }
        val minV = values.minOrNull() ?: 0f
        val maxV = values.maxOrNull() ?: 1f
        val span = (maxV - minV).takeIf { it > 0.0001f } ?: 1f
        val stepX = size.width / (values.size - 1).coerceAtLeast(1)
        val path = Path()
        values.forEachIndexed { idx, v ->
            val x = idx * stepX
            val norm = (v - minV) / span
            val y = size.height - (norm * size.height * 0.78f + size.height * 0.11f)
            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 4.5f, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun FvgBarComparisonCanvas(
    bars: List<Pair<String, Float>>,
    barColorPrimary: Color = FvgForestGreen,
    barColorSecondary: Color = FvgWarmGold,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            if (bars.isEmpty()) return@Canvas
            val maxAbs = bars.maxOf { kotlin.math.abs(it.second) }.coerceAtLeast(1f)
            val slotW = size.width / bars.size
            val barW = (slotW * 0.54f).coerceAtMost(56f)
            val baselineY = size.height * 0.88f

            drawLine(
                color = FvgWarmStone,
                start = Offset(0f, baselineY),
                end = Offset(size.width, baselineY),
                strokeWidth = 2f
            )

            bars.forEachIndexed { i, pair ->
                val ratio = (kotlin.math.abs(pair.second) / maxAbs).coerceIn(0.04f, 1f)
                val barH = ratio * (baselineY - 12f)
                val left = i * slotW + (slotW - barW) / 2f
                val top = baselineY - barH
                drawRoundRect(
                    color = if (pair.second < 0f) FvgNegative else if (i % 2 == 0) barColorPrimary else barColorSecondary,
                    topLeft = Offset(left, top),
                    size = Size(barW, barH),
                    cornerRadius = CornerRadius(8f, 8f)
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            bars.forEach { (label, value) ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = String.format("%.1f", value),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (value < 0f) FvgNegative else FvgForestGreen
                    )
                }
            }
        }
    }
}

@Composable
fun FvgRoleBadge(role: String) {
    Surface(
        shape = CircleShape,
        color = FvgWarmGold.copy(alpha = 0.2f),
        border = BorderStroke(1.dp, FvgAntiqueGold.copy(alpha = 0.5f))
    ) {
        Text(
            text = role.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = FvgDeepGreen,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

/**
 * Live 3-day (72-hour) Trial Countdown displaying Days, Hours, Minutes, and Seconds ticking every second.
 */
@Composable
fun FvgTrialCountdownBanner(
    trialEndsAtMillis: Long?,
    isArabic: Boolean,
    isPreview72h: Boolean = false,
    onActionClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val effectiveEndMillis = remember(trialEndsAtMillis, isPreview72h) {
        trialEndsAtMillis ?: (System.currentTimeMillis() + 3L * 86400_000L)
    }

    LaunchedEffect(effectiveEndMillis) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val cd = remember(effectiveEndMillis, nowMillis) {
        FvgFinancialEngine.computeTrialCountdown(effectiveEndMillis, nowMillis)
    }

    fun pad(v: Long): String = v.toString().padStart(2, '0')

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("trial_countdown_banner"),
        shape = RoundedCornerShape(18.dp),
        color = if (cd.isExpired) FvgNegative.copy(alpha = 0.12f) else FvgSoftCream,
        border = BorderStroke(1.dp, if (cd.isExpired) FvgNegative else FvgWarmGold)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Filled.Schedule,
                        contentDescription = null,
                        tint = if (cd.isExpired) FvgNegative else FvgDeepGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = when {
                            cd.isExpired && isArabic -> "انتهت الفترة التجريبية (3 أيام / 72 ساعة)"
                            cd.isExpired -> "3-Day (72h) Trial Ended"
                            isPreview72h && isArabic -> "فترة تجربة كاملة 3 أيام (72 ساعة)"
                            isPreview72h -> "Full 3-Day (72-Hour) Free Trial Included"
                            isArabic -> "الفترة التجريبية النشطة (3 أيام)"
                            else -> "3-Day Active Trial Countdown"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (cd.isExpired) FvgNegative else FvgDeepGreen
                    )
                }
                if (onActionClick != null) {
                    TextButton(onClick = onActionClick, modifier = Modifier.heightIn(min = 48.dp)) {
                        Text(
                            text = if (isArabic) "الباقات" else "Plans",
                            color = FvgForestGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val units = listOf(
                    pad(cd.days) to (if (isArabic) "أيام" else "Days"),
                    pad(cd.hours) to (if (isArabic) "ساعات" else "Hours"),
                    pad(cd.minutes) to (if (isArabic) "دقائق" else "Mins"),
                    pad(cd.seconds) to (if (isArabic) "ثواني" else "Secs")
                )
                units.forEach { (num, lbl) ->
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        color = FvgDeepGreen
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = num,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = FvgWarmGold
                            )
                            Text(
                                text = lbl,
                                style = MaterialTheme.typography.labelSmall,
                                color = FvgWarmIvory
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FvgSplineLineChartCanvas(
    points: List<Pair<String, Float>>,
    lineColor: Color = FvgForestGreen,
    fillColor: Color = FvgWarmGold,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(155.dp)
        ) {
            if (points.size < 2) return@Canvas
            val vals = points.map { it.second }
            val minV = vals.minOrNull() ?: 0f
            val maxV = vals.maxOrNull() ?: 1f
            val span = (maxV - minV).takeIf { it > 0.001f } ?: 1f
            val padH = 18f
            val padV = 18f
            val usableW = (size.width - padH * 2f).coerceAtLeast(1f)
            val usableH = (size.height - padV * 2f).coerceAtLeast(1f)
            val stepX = usableW / (points.size - 1).coerceAtLeast(1)

            val coords = points.mapIndexed { idx, (_, v) ->
                val x = padH + idx * stepX
                val norm = (v - minV) / span
                val y = size.height - padV - norm * usableH
                Offset(x, y)
            }

            val linePath = Path().apply {
                moveTo(coords.first().x, coords.first().y)
                for (i in 0 until coords.size - 1) {
                    val p0 = coords[i]
                    val p1 = coords[i + 1]
                    val cx = (p0.x + p1.x) / 2f
                    cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
                }
            }

            val fillPath = Path().apply {
                addPath(linePath)
                lineTo(coords.last().x, size.height - padV)
                lineTo(coords.first().x, size.height - padV)
                close()
            }

            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(fillColor.copy(alpha = 0.28f), fillColor.copy(alpha = 0.02f))
                )
            )
            drawPath(
                path = linePath,
                color = lineColor,
                style = Stroke(width = 5f, cap = StrokeCap.Round)
            )
            coords.forEachIndexed { i, c ->
                val isLast = i == coords.lastIndex
                drawCircle(
                    color = if (isLast) FvgWarmGold else lineColor,
                    radius = if (isLast) 8f else 5f,
                    center = c
                )
            }
        }
        if (points.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                points.take(6).forEach { (lbl, value) ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(lbl.take(7), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(String.format("%.1f", value), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun FvgCvpChartCanvas(
    cvpPoints: List<FvgFinancialEngine.CvpPoint>,
    breakEvenUnits: Float?,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(175.dp)
        ) {
            if (cvpPoints.size < 2) return@Canvas
            val maxU = cvpPoints.maxOf { it.units }.coerceAtLeast(1f)
            val maxY = cvpPoints.maxOf { maxOf(it.totalCost, it.totalRevenue) }.coerceAtLeast(1f)
            val pad = 20f
            val w = size.width - pad * 2f
            val h = size.height - pad * 2f

            fun toPt(u: Float, yVal: Float): Offset =
                Offset(pad + (u / maxU) * w, size.height - pad - (yVal / maxY) * h)

            // Axes
            drawLine(FvgWarmStone, Offset(pad, size.height - pad), Offset(size.width - pad, size.height - pad), strokeWidth = 2f)
            drawLine(FvgWarmStone, Offset(pad, pad), Offset(pad, size.height - pad), strokeWidth = 2f)

            val costPath = Path()
            val revPath = Path()
            cvpPoints.forEachIndexed { idx, pt ->
                val cOff = toPt(pt.units, pt.totalCost)
                val rOff = toPt(pt.units, pt.totalRevenue)
                if (idx == 0) {
                    costPath.moveTo(cOff.x, cOff.y)
                    revPath.moveTo(rOff.x, rOff.y)
                } else {
                    costPath.lineTo(cOff.x, cOff.y)
                    revPath.lineTo(rOff.x, rOff.y)
                }
            }
            drawPath(costPath, color = FvgNegative, style = Stroke(width = 4.5f, cap = StrokeCap.Round))
            drawPath(revPath, color = FvgForestGreen, style = Stroke(width = 5f, cap = StrokeCap.Round))

            if (breakEvenUnits != null && breakEvenUnits in 0f..maxU) {
                val closest = cvpPoints.minByOrNull { kotlin.math.abs(it.units - breakEvenUnits) }
                if (closest != null) {
                    val beY = (closest.totalRevenue + closest.totalCost) / 2f
                    val bePt = toPt(breakEvenUnits, beY)
                    drawCircle(color = FvgWarmGold, radius = 9f, center = bePt)
                    drawCircle(color = FvgDeepGreen, radius = 4.5f, center = bePt)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(FvgForestGreen))
                Spacer(Modifier.width(4.dp))
                Text("Revenue Line", style = MaterialTheme.typography.labelSmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(FvgNegative))
                Spacer(Modifier.width(4.dp))
                Text("Total Cost Line", style = MaterialTheme.typography.labelSmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(FvgWarmGold))
                Spacer(Modifier.width(4.dp))
                Text("Break-Even", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
