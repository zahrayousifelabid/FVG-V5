package com.example.data.repository

import android.graphics.Bitmap
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "FvgAiRepository"

data class OcrExtractionResult(
    val extractedText: String,
    val vendorName: String,
    val documentDate: String,
    val currency: String,
    val totalAmount: String,
    val lineSummary: String
)

class FvgAiRepository {

    private val assistantModel by lazy {
        Firebase.ai.generativeModel(modelName = "gemini-3.8-flash")
    }

    private val ocrSchema = Schema.obj(
        properties = mapOf(
            "extractedText" to Schema.string(description = "Full verbatim OCR transcription of the document"),
            "vendorName" to Schema.string(description = "Supplier or merchant name if visible, else empty"),
            "documentDate" to Schema.string(description = "Document/invoice date in YYYY-MM-DD if visible, else empty"),
            "currency" to Schema.string(description = "3-letter currency code such as USD, SDG, SAR, EUR if visible, else empty"),
            "totalAmount" to Schema.string(description = "Numeric total amount without currency symbol, e.g. 1250.00"),
            "lineSummary" to Schema.string(description = "Concise list of detected line items, quantities, and unit prices")
        )
    )

    private val ocrModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = ocrSchema
            }
        )
    }

    fun streamGroundedExplanation(
        question: String,
        systemDataContext: String,
        languageCode: String
    ): Flow<String> = flow {
        val langInstruction = if (languageCode == "ar") {
            "Respond clearly in Arabic (العربية), citing exact numbers and source labels from the provided FVG system data."
        } else {
            "Respond clearly in English, citing exact numbers and source labels from the provided FVG system data."
        }
        val prompt = """
            You are FVG Financial Vision Guide's analytical assistant.
            STRICT RULES:
            1. Rely ONLY on the verified FVG system data provided below.
            2. NEVER invent figures, estimates, or missing records. If data is absent, explicitly state that it is not recorded yet.
            3. Identify the exact source module/table for every number you cite.
            4. Do NOT claim to modify database records or execute accounting postings.
            5. $langInstruction

            --- VERIFIED ORGANIZATION SYSTEM DATA ---
            $systemDataContext
            --- END SYSTEM DATA ---

            User Question: $question
        """.trimIndent()

        val acc = StringBuilder()
        try {
            withTimeout(60_000L) {
                assistantModel.generateContentStream(prompt).collect { chunk ->
                    val t = chunk.text.orEmpty()
                    if (t.isNotEmpty()) {
                        acc.append(t)
                        emit(acc.toString())
                    }
                }
            }
            if (acc.isBlank()) {
                throw IllegalStateException("AI assistant returned an empty response.")
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI assistant request timed out", e)
            throw IllegalStateException("AI assistant timed out after 60 seconds. Please retry.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI assistant generation failed", e)
            throw e
        }
    }

    suspend fun extractInvoiceDocument(bitmap: Bitmap): OcrExtractionResult {
        try {
            val response = withTimeout(60_000L) {
                ocrModel.generateContent(
                    content {
                        image(bitmap)
                        text(
                            "Extract invoice, receipt, or price sheet fields for human review. " +
                                "Do not guess unreadable numbers; return empty string if unclear."
                        )
                    }
                )
            }
            val jsonStr = response.text ?: throw IllegalStateException("OCR returned empty output")
            val json = JSONObject(jsonStr)
            return OcrExtractionResult(
                extractedText = json.optString("extractedText", ""),
                vendorName = json.optString("vendorName", ""),
                documentDate = json.optString("documentDate", ""),
                currency = json.optString("currency", ""),
                totalAmount = json.optString("totalAmount", ""),
                lineSummary = json.optString("lineSummary", "")
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "OCR extraction timed out", e)
            throw IllegalStateException("Document OCR timed out after 60 seconds.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "OCR extraction failed", e)
            throw e
        }
    }
}
