# Local installation

1. Python 3.11+ recommended. From `backend/`, create and activate a virtual environment.
2. Install `requirements.txt`.
3. Copy root `.env.example` to `.env`; change `FVG_SESSION_SECRET` to a long random value. Load environment variables using your shell or a reviewed dotenv loader; the current app does not auto-load `.env`.
4. Run `uvicorn app.main:app --reload` from `backend/`.
5. In `frontend/`, run `npm install` then `npm run dev`. Vite proxies API calls to localhost port 8000.
6. Do not expose the development server publicly. Configure HTTPS, firewall, secret management, persistent database and reviewed operational controls before any deployment.
