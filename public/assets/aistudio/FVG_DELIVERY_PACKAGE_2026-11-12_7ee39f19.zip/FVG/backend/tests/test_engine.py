from decimal import Decimal
import pytest
from app import engine as e

def test_total_cost_known_fixture(): assert e.total_cost([10, 20, 5]) == Decimal('35.00')
def test_unit_cost_known_fixture(): assert e.unit_cost(1200, 100) == Decimal('12.00')
def test_margin_and_markup():
    assert e.margin(25, 100) == Decimal('0.2500')
    assert e.markup(25, 75) == Decimal('0.3333')
def test_profit():
    assert e.profit_per_unit(20, 12) == Decimal('8.00')
    assert e.total_profit(500, 350) == Decimal('150.00')
def test_target_prices():
    assert e.target_price_by_margin(80, Decimal('.20')) == Decimal('100.00')
    assert e.target_price_by_markup(80, Decimal('.25')) == Decimal('100.00')
def test_break_even():
    assert e.break_even_units(1000, 50, 30) == Decimal('50')
    assert e.break_even_revenue(50, 50) == Decimal('2500.00')
def test_conversion():
    assert e.convert_units(2, 'kg', 'g', {('kg','g'):1000}) == Decimal('2000')
def test_cost_allocation(): assert e.allocate_cost(1000, [10, 30], 10) == Decimal('250.00')
def test_scenario_does_not_mutate_base():
    base={'materials':100, 'energy':50}
    out=e.scenario(base, {'materials':'.10', 'energy':'-.20'})
    assert out['base_total'] == Decimal('150.00')
    assert out['scenario_total'] == Decimal('150.00')
    assert base == {'materials':100, 'energy':50}
@pytest.mark.parametrize('fn,args', [
    (e.unit_cost,(100,0)), (e.unit_cost,(100,-1)), (e.margin,(1,0)),
    (e.markup,(1,0)), (e.total_cost,([-1],)),
    (e.break_even_units,(100,10,10)),
    (e.convert_units,(1,'kg','litre',{})),
    (e.allocate_cost,(100,[0,0],0)),
    (e.target_price_by_margin,(10,1)),
    (e.scenario,({'x':10},{'x':-1.1})),
])
def test_invalid_inputs_raise(fn,args):
    with pytest.raises(e.FinancialInputError): fn(*args)
