package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.components.*
import com.example.ui.i18n.fvgStrings
import com.example.ui.theme.*
import kotlinx.coroutines.delay

const val APPROVED_ARABIC_ABOUT_US =
    "في ظل متغيّرات اقتصادية متسارعة وضغوط تضخمية حادة تهدد استمرارية المشاريع، يأتي 'دليل رؤيتك المالي' ليكون بوصلتك نحو الاستقرار المالي. نحن لا نكتفي بحساب الأرقام، بل نسهل لك اتخاذ قرارات التسعير الصحيحة بشكل تلقائي ومدروس، لنحول معادلات التكاليف المعقدة إلى أدوات عملية دقيقة تضمن لك الحفاظ على رأس المال، تعظيم الأرباح، والعبور بمشروعك نحو بر الأمان بكل ثقة واحترافية."

@Composable
fun FvgSplashScreen(
    isArabic: Boolean,
    onSplashFinished: () -> Unit
) {
    LaunchedEffect(Unit) {
        delay(2000L)
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FvgWarmIvory)
            .clickable { onSplashFinished() }
            .testTag("fvg_splash_screen")
    ) {
        // Curved Wave Ribbons & Subtle Light Glow matching composite reference photo
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(FvgWarmGold.copy(alpha = 0.22f), Color.Transparent),
                    center = Offset(w * 0.5f, h * 0.34f),
                    radius = w * 0.55f
                ),
                center = Offset(w * 0.5f, h * 0.34f),
                radius = w * 0.55f
            )

            val upperForest = Path().apply {
                moveTo(0f, h * 0.62f)
                cubicTo(w * 0.30f, h * 0.55f, w * 0.65f, h * 0.72f, w, h * 0.61f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(upperForest, color = FvgForestGreen)

            val goldRibbon = Path().apply {
                moveTo(0f, h * 0.69f)
                cubicTo(w * 0.32f, h * 0.79f, w * 0.70f, h * 0.62f, w, h * 0.71f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(goldRibbon, color = FvgWarmGold)

            val deepGreenBase = Path().apply {
                moveTo(0f, h * 0.72f)
                cubicTo(w * 0.32f, h * 0.82f, w * 0.70f, h * 0.65f, w, h * 0.74f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(deepGreenBase, color = FvgDeepGreen)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp, vertical = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(Modifier.height(16.dp))

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    shadowElevation = 8.dp,
                    border = BorderStroke(2.dp, FvgWarmGold),
                    color = FvgDeepGreen,
                    modifier = Modifier.size(124.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.fvg_app_icon),
                        contentDescription = "FVG Logo Emblem",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(Modifier.height(22.dp))
                Text(
                    text = "FVG",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold,
                    color = FvgDeepGreen
                )
                Text(
                    text = "Financial Vision Guide",
                    style = MaterialTheme.typography.titleLarge,
                    color = FvgForestGreen
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HorizontalDivider(modifier = Modifier.width(36.dp), thickness = 1.5.dp, color = FvgWarmGold)
                    Text(
                        text = "دليل رؤيتك المالي",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = FvgAntiqueGold
                    )
                    HorizontalDivider(modifier = Modifier.width(36.dp), thickness = 1.5.dp, color = FvgWarmGold)
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = if (isArabic) "قرارات أذكى. مستقبل مالي أقوى." else "Smarter Decisions. Stronger Financial Future.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = FvgMutedForest,
                    textAlign = TextAlign.Center
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CircularProgressIndicator(
                    color = FvgWarmGold,
                    trackColor = FvgWarmIvory.copy(alpha = 0.25f),
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    text = if (isArabic) "انقر للمتابعة" else "Tap anywhere to continue",
                    style = MaterialTheme.typography.labelSmall,
                    color = FvgWarmIvory.copy(alpha = 0.85f)
                )
            }
        }
    }
}

/**
 * Second launch screen showing the Developer Portrait (Zahra Yousif) & Vision Story right after Splash,
 * and also accessible anytime from Dashboard / Org & Audit.
 */
@Composable
fun DeveloperShowcaseScreen(
    isArabic: Boolean,
    isDark: Boolean,
    onToggleLanguage: () -> Unit,
    onToggleTheme: () -> Unit,
    onContinue: () -> Unit
) {
    BackHandler { onContinue() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Box(modifier = Modifier.statusBarsPadding()) {
                FvgTopHeaderBanner(
                    title = if (isArabic) "مطوّرة المنصة ورؤية FVG" else "Developer & FVG Vision",
                    subtitle = "Financial Vision Guide • دليل رؤيتك المالي",
                    icon = Icons.Filled.VerifiedUser,
                    isArabic = isArabic,
                    isDark = isDark,
                    onToggleLanguage = onToggleLanguage,
                    onToggleTheme = onToggleTheme
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .testTag("developer_showcase_screen"),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(26.dp),
                color = FvgDeepGreen,
                border = BorderStroke(1.5.dp, FvgWarmGold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        border = BorderStroke(3.dp, FvgWarmGold),
                        shadowElevation = 6.dp,
                        color = FvgSoftCream,
                        modifier = Modifier.size(164.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.zahra_yousif_portrait),
                            contentDescription = "Zahra Yousif Developer Portrait",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Text(
                        text = "Zahra Yousif  |  زهراء يوسف",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = FvgWarmIvory,
                        textAlign = TextAlign.Center
                    )
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = FvgWarmGold.copy(alpha = 0.18f),
                        border = BorderStroke(1.dp, FvgWarmGold.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = if (isArabic)
                                "مطوّرة ومؤسسة FVG • خريجة محاسبة — جامعة النيل"
                            else
                                "Founder & Developer • Accounting Graduate, Nile University",
                            style = MaterialTheme.typography.labelLarge,
                            color = FvgWarmGold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Exact approved Arabic vision message
            FvgCard(containerColor = FvgSoftCream) {
                Text(
                    text = "رؤية دليل رؤيتك المالي (FVG)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = FvgDeepGreen
                )
                Text(
                    text = APPROVED_ARABIC_ABOUT_US,
                    style = MaterialTheme.typography.bodyLarge,
                    color = FvgInkDark
                )
                HorizontalDivider(color = FvgWarmGold.copy(alpha = 0.5f))
                Text(
                    text = "Amid rapid economic shifts and acute inflationary pressures threatening business continuity, Financial Vision Guide (FVG) serves as your compass toward financial stability. We go beyond simple number-crunching to automate disciplined pricing decisions—turning complex cost equations into precise, practical tools that safeguard capital, maximize profit, and steer your enterprise safely forward with confidence.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = FvgMutedForest
                )
            }

            FvgTrialCountdownBanner(
                trialEndsAtMillis = null,
                isArabic = isArabic,
                isPreview72h = true
            )

            FvgGoldButton(
                text = if (isArabic) "الدخول إلى منصة دليل رؤيتك المالي" else "Continue to Financial Vision Guide",
                icon = Icons.AutoMirrored.Filled.ArrowForward,
                onClick = onContinue,
                modifier = Modifier.fillMaxWidth(),
                testTag = "developer_continue_button"
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun PublicWebsiteAndAuthScreen(
    isArabic: Boolean,
    isDark: Boolean,
    isSigningIn: Boolean,
    authError: String?,
    onToggleLanguage: () -> Unit,
    onToggleTheme: () -> Unit,
    onGoogleSignInClick: () -> Unit
) {
    val s = fvgStrings(isArabic)
    val context = LocalContext.current
    var selectedPage by remember { mutableIntStateOf(0) }
    val scrollState = rememberScrollState()
    LaunchedEffect(selectedPage) {
        scrollState.scrollTo(0)
    }
    val pageTitles = listOf(
        s.publicHome, s.publicFeatures, s.publicPricing,
        s.publicAbout, s.publicFaq, s.publicContact,
        s.publicPrivacy, s.publicTerms
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                FvgTopHeaderBanner(
                    title = "${s.brandShort} • ${s.brandTaglineEn}",
                    subtitle = s.brandTaglineAr,
                    icon = Icons.AutoMirrored.Filled.TrendingUp,
                    isArabic = isArabic,
                    isDark = isDark,
                    onToggleLanguage = onToggleLanguage,
                    onToggleTheme = onToggleTheme
                )
                FvgSubTabRow(
                    tabs = pageTitles,
                    selectedIndex = selectedPage,
                    onSelect = { selectedPage = it },
                    testTagPrefix = "public_nav"
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (!authError.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = authError,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            when (selectedPage) {
                0 -> PublicHomeSection(isArabic, isSigningIn, onGoogleSignInClick) { selectedPage = it }
                1 -> PublicFeaturesSection(isArabic)
                2 -> PublicPricingSection(isArabic, isSigningIn, onGoogleSignInClick)
                3 -> PublicAboutSection(isArabic)
                4 -> PublicFaqSection(isArabic)
                5 -> PublicContactSection(isArabic) { subject, body ->
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:support@fvg-finance.app")
                        putExtra(Intent.EXTRA_SUBJECT, subject)
                        putExtra(Intent.EXTRA_TEXT, body)
                    }
                    runCatching { context.startActivity(intent) }
                }
                6 -> PublicPrivacySection(isArabic)
                7 -> PublicTermsSection(isArabic)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PublicHomeSection(
    isArabic: Boolean,
    isSigningIn: Boolean,
    onSignInClick: () -> Unit,
    onNavigatePage: (Int) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = FvgDeepGreen,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.fvg_app_icon),
                    contentDescription = "FVG Emblem",
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(14.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        text = if (isArabic) "منصة FVG المالية والمحاسبية" else "FVG Financial & Pricing Platform",
                        style = MaterialTheme.typography.headlineMedium,
                        color = FvgWarmIvory
                    )
                    Text(
                        text = if (isArabic) "دليل رؤيتك المالي • القرارات المالية الدقيقة" else "Financial Vision Guide • Precision Decisions",
                        style = MaterialTheme.typography.bodyMedium,
                        color = FvgWarmGold
                    )
                }
            }
            Text(
                text = if (isArabic)
                    "مراقبة تغيرات الأسعار والتضخم، حساب تكاليف المنتجات بدقة، إدارة القيود المحاسبية المزدوجة والقوائم المالية، تقييم المخزون بـ FIFO والمتوسط المرجح وتكلفة الاستبدال، ومساعد ذكاء اصطناعي مستند حصراً لبياناتك الحقيقية."
                else
                    "Monitor product & raw-material price changes, track inflation & weighted baskets, run exact multi-component costing & what-if pricing, post double-entry journals & IFRS-aligned statements, value inventory (FIFO, MWA & replacement cost), and query an AI assistant strictly grounded in your verified ledger.",
                style = MaterialTheme.typography.bodyLarge,
                color = FvgWarmIvory.copy(alpha = 0.92f)
            )
            FvgGoldButton(
                text = if (isSigningIn) (if (isArabic) "جاري المصادقة..." else "Signing in...")
                else if (isArabic) "تسجيل الدخول / إنشاء حساب عبر Google" else "Sign in / Register with Google",
                onClick = onSignInClick,
                enabled = !isSigningIn,
                icon = Icons.Filled.AccountCircle,
                modifier = Modifier.fillMaxWidth(),
                testTag = "google_sign_in_button"
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { onNavigatePage(1) },
                    border = BorderStroke(1.dp, FvgWarmGold),
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) {
                    Text(
                        text = if (isArabic) "استكشف المزايا" else "Explore Features",
                        color = FvgWarmGold
                    )
                }
                OutlinedButton(
                    onClick = { onNavigatePage(2) },
                    border = BorderStroke(1.dp, FvgWarmIvory.copy(alpha = 0.6f)),
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) {
                    Text(
                        text = if (isArabic) "باقة الـ 3 أيام" else "3-Day Trial Plans",
                        color = FvgWarmIvory
                    )
                }
            }
        }
    }

    // Live 3-day (72-hour) Days:Hours:Minutes:Seconds preview
    FvgTrialCountdownBanner(
        trialEndsAtMillis = null,
        isArabic = isArabic,
        isPreview72h = true,
        onActionClick = { onNavigatePage(2) }
    )

    // Founder & Commercial Showcase Cards (Preserving all approved photos)
    FvgCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.zahra_yousif_portrait),
                contentDescription = "Zahra Yousif Founder Portrait",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isArabic) "زهراء يوسف — مؤسسة ومطوّرة FVG" else "Zahra Yousif — Founder & Developer",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = FvgDeepGreen
                )
                Text(
                    text = if (isArabic)
                        "خريجة محاسبة — جامعة النيل • صاحبة رؤية دليل رؤيتك المالي."
                    else
                        "Accounting Graduate, Nile University • Creator of Financial Vision Guide.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    FvgCard {
        Text(
            text = if (isArabic) "عرض تطبيقات السوق — بن الزهراء للمنتجات" else "Commercial Product Costing Showcase — Ben Al-Zahra",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = FvgDeepGreen
        )
        Image(
            painter = painterResource(id = R.drawable.fvg_ben_alzahra_products),
            contentDescription = "Ben Al-Zahra Commercial Products Visual Showcase",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .height(170.dp)
                .clip(RoundedCornerShape(16.dp))
        )
        Text(
            text = if (isArabic)
                "مثال توضيحي مرئي لتطبيقات التسعير ومراقبة تكاليف التعبئة والمواد الخام في المشاريع التجارية (بدون أي أرقام مخترعة)."
            else
                "Visual commercial reference showcasing retail packaging & raw-material cost modeling inside FVG (zero fabricated ledger numbers).",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    FvgCard {
        Text(
            text = if (isArabic) "الأسئلة الجوهرية التي تجيب عليها المنصة" else "Key Decisions FVG Solves With Traceable Math",
            style = MaterialTheme.typography.titleMedium,
            color = FvgDeepGreen
        )
        val questions = if (isArabic) listOf(
            "كم تغيرت أسعار المواد الخام والسلع ونسبة الزيادة الفعلية؟",
            "ما أثر التضخم وسعر الصرف التاريخي على تكلفة الوحدة؟",
            "كم تبلغ قيمة المخزون الدفترية مقارنة بتكلفة الاستبدال الحالية؟",
            "هل المنظمة تحقق ربحاً أم خسارة، ولماذا تغير صافي الربح؟",
            "ما سعر البيع المستهدف ومعدل هامش الربح مقابل Markup ونقطة التعادل؟"
        ) else listOf(
            "How have product & raw-material prices changed over time (% & absolute delta)?",
            "How do inflation indices and historical FX rates shift real cost & purchasing power?",
            "What is inventory's FIFO/Moving-Average book value vs current replacement cost?",
            "Is the organization profitable and why did cash flow vs accrual profit diverge?",
            "What selling price meets target margin vs markup, and how many units break even?"
        )
        questions.forEach { q ->
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = FvgForestGreen, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(q, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }

    FvgCard(containerColor = FvgSoftCream) {
        Text(
            text = if (isArabic) "التسجيل واسترداد الحساب الآمن" else "Secure Registration & Account Recovery",
            style = MaterialTheme.typography.titleMedium,
            color = FvgDeepGreen
        )
        Text(
            text = if (isArabic)
                "تعتمد المنصة حصراً على Google Identity (Credential Manager + Firebase Auth) لحماية الحسابات واستعادة الوصول تلقائياً عبر Google دون تخزين كلمات مرور محلية."
            else
                "FVG enforces Google Identity via Jetpack Credential Manager & Firebase Auth—providing one-tap registration, automatic account recovery via Google, and zero insecure password stores.",
            style = MaterialTheme.typography.bodyMedium,
            color = FvgInkDark
        )
    }
}

@Composable
private fun PublicFeaturesSection(isArabic: Boolean) {
    val modules = if (isArabic) listOf(
        "مراقبة الأسعار والوحدات والتنبيهات" to "تسجيل تاريخي غير قابل للكتابة الفوقية، تنبيهات القفزات غير المعتادة (>=15%)، منع التكرار، الرسوم البيانية لتطور الأسعار، واستيراد CSV/XLSX.",
        "التضخم والسلات المرجحة والصرف التاريخي" to "مؤشرات شهرية وسنوية وتراكمية مع توضيح المصدر (رسمي/محسوب/يدوي/مبدئي)، تحليل مكونات السلة، وتوثيق أسعار الصرف التاريخية.",
        "التكاليف المعيارية والإنتاج وتحليل ماذا لو" to "المواد والأجور والطاقة والتغليف والنقل والهدر، الفصل بين Margin و Markup، أوامر الإنتاج والتكلفة المعيارية وتحليل التباين، منحنى CVP، ومحاكاة السيناريوهات.",
        "المحاسبة والقوائم المالية والأستاذ والنسب" to "مسودة وترحيل وعكس القيود، استيراد قيود CSV بأمان، دفتر الأستاذ العام بالرصيد المتحرك، مقارنة فترتين، أعمار الديون AR/AP، و18 نسبة مالية.",
        "المخزون والجرد الفعلي والهدر والموازنات" to "تقييم FIFO والمتوسط المرجح المتحرك، مقارنة تكلفة الاستبدال والتضخم، طلبات الهدر والتوالف بموافقة المشرف، الجرد الفعلي، والموازنات.",
        "الذكاء الاصطناعي وتصدير PDF / XLSX / CSV / JSON" to "تحليل مالي مقيد بالبيانات المسجلة، استخراج مسودات الفواتير للمراجعة البشرية، والنسخ الاحتياطي الكامل بصيغة JSON."
    ) else listOf(
        "Price Registry, Anomaly Alerts & Trends" to "Append-only observation trail, duplicate prevention, unusual >=15% movement badges, historical trend spline charts, and sanitized CSV/XLSX import.",
        "Inflation, Weighted Baskets & Historical FX" to "Official vs calculated vs manual vs provisional tagging, cumulative compounded inflation, line-item basket impact, and historical FX lookup.",
        "Costing, Standard Costs, Production & CVP" to "9-component cost calculator, Margin vs Markup separation, CVP Break-Even chart, Cost Volatility, Standard Cost Variance, Production Orders & What-If scenarios.",
        "Double-Entry Accounting, GL, Aging & 18 Ratios" to "Draft/Post/Reverse journals, CSV accounting import, Account General Ledger running balance, Period A vs B profit bridge, AR/AP aging buckets & 18 ratios.",
        "Inventory, Scrap Approvals, Stocktaking & Budgets" to "FIFO/MWA valuation, Book vs Replacement vs Inflation-Adjusted comparison, admin-approved Scrap/Losses with auto JE, stocktakes & budget revisions.",
        "Grounded AI, OCR & Full JSON Workspace Backup" to "Gemini 3.8 Flash strictly grounded Q&A, PickVisualMedia invoice OCR drafts, 12 report types in PDF/XLSX/CSV/JSON, plus full workspace backup."
    )

    modules.forEach { (title, desc) ->
        FvgCard {
            Text(title, style = MaterialTheme.typography.titleMedium, color = FvgDeepGreen)
            Text(desc, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun PublicPricingSection(
    isArabic: Boolean,
    isSigningIn: Boolean,
    onSignInClick: () -> Unit
) {
    FvgTrialCountdownBanner(
        trialEndsAtMillis = null,
        isArabic = isArabic,
        isPreview72h = true
    )

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = FvgSoftCream,
        border = BorderStroke(1.dp, FvgWarmGold),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = if (isArabic)
                "ملاحظة الشفافية: تبدأ جميع المنظمات بفترة تجربة مجانية كاملة لمدة 3 أيام (72 ساعة) مع عداد مباشر للأيام والساعات والدقائق والثواني. لا تتم معالجة بطاقات دفع خارجية دون ربط بوابة دفع موثقة."
            else
                "Adapter Status Notice: New organizations start with a full 3-day (72-hour) Trial workspace tracked by a live D:H:M:S countdown. Live external card/billing gateway webhooks require merchant credentials; plan state is managed cleanly via FVG's subscription adapter.",
            style = MaterialTheme.typography.bodyMedium,
            color = FvgDeepGreen,
            modifier = Modifier.padding(14.dp)
        )
    }

    val plans = listOf(
        Triple(if (isArabic) "التجربة (3 أيام / 72 ساعة)" else "3-Day (72h) Trial", "$0", listOf(
            if (isArabic) "منظمة واحدة • كافة الوحدات المحاسبية والتكاليف" else "1 Workspace • Full Core Prices, Costing & Accounting",
            if (isArabic) "تصدير CSV و JSON و PDF وعداد وقت حقيقي" else "PDF, CSV & JSON Exports with Live 72h Countdown"
        )),
        Triple(if (isArabic) "الخطة الاحترافية" else "Professional", "$29 / mo", listOf(
            if (isArabic) "تقييم FIFO والمتوسط المرجح والجرد والهدر الكامل" else "Full FIFO / Moving Avg Inventory, Scrap & Stocktaking",
            if (isArabic) "المساعد الذكي + قراءة الفواتير + XLSX" else "AI Financial Assistant, Invoice OCR & OpenXML XLSX"
        )),
        Triple(if (isArabic) "خطة المؤسسات" else "Enterprise", "$79 / mo", listOf(
            if (isArabic) "تعدد المستخدمين والأدوار (RBAC) وسجل التدقيق" else "Multi-User RBAC Roles & Immutable Audit Trail",
            if (isArabic) "سلات تضخم مخصصة وتحويل صرف تاريخي غير محدود" else "Custom Inflation Baskets & Unlimited Historical FX"
        ))
    )

    plans.forEach { (name, price, bullets) ->
        FvgCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(name, style = MaterialTheme.typography.titleMedium, color = FvgDeepGreen)
                Surface(shape = RoundedCornerShape(12.dp), color = FvgWarmGold) {
                    Text(
                        price,
                        style = MaterialTheme.typography.labelLarge,
                        color = FvgDeepGreen,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
            bullets.forEach { b ->
                Text("• $b", style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(4.dp))
            FvgPrimaryButton(
                text = if (isArabic) "ابدأ تجربة 3 أيام عبر Google" else "Start 3-Day Trial with Google",
                onClick = onSignInClick,
                enabled = !isSigningIn
            )
        }
    }
}

@Composable
private fun PublicAboutSection(isArabic: Boolean) {
    FvgCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.zahra_yousif_portrait),
                contentDescription = "Zahra Yousif Founder Portrait",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(84.dp)
                    .clip(CircleShape)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Zahra Yousif | زهراء يوسف",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = FvgDeepGreen
                )
                Text(
                    text = if (isArabic) "خريجة محاسبة — جامعة النيل • مطوّرة دليل رؤيتك المالي" else "Accounting Graduate, Nile University • Developer of FVG",
                    style = MaterialTheme.typography.bodyMedium,
                    color = FvgAntiqueGold
                )
            }
        }
        Text(
            text = APPROVED_ARABIC_ABOUT_US,
            style = MaterialTheme.typography.bodyLarge,
            color = FvgInkDark
        )
        HorizontalDivider()
        Text(
            text = if (isArabic)
                "FVG هو نظام متكامل للتحليل المالي والتسعير ومراقبة الأسعار والتضخم والمحاسبة وإدارة المخزون. صُمم لمساعدة المنشآت على اتخاذ قرارات مبنية على أرقام تاريخية دقيقة وقابلة للتدقيق دون بيانات وهمية."
            else
                "FVG (Financial Vision Guide) unifies price intelligence, inflation indexing, multi-currency FX history, product costing, double-entry accounting, and inventory valuation with deterministic BigDecimal precision.",
            style = MaterialTheme.typography.bodyMedium
        )
    }

    FvgCard {
        Text(
            text = if (isArabic) "عرض المشاريع التجارية — بن الزهراء" else "Commercial Product Reference — Ben Al-Zahra",
            style = MaterialTheme.typography.titleMedium,
            color = FvgDeepGreen
        )
        Image(
            painter = painterResource(id = R.drawable.fvg_ben_alzahra_products),
            contentDescription = "Ben Al-Zahra Commercial Showcase",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .height(170.dp)
                .clip(RoundedCornerShape(16.dp))
        )
    }
}

@Composable
private fun PublicFaqSection(isArabic: Boolean) {
    val faqs = if (isArabic) listOf(
        "ما مدة الفترة التجريبية وكيف يُحسب العداد؟" to
            "تستمر الفترة التجريبية 3 أيام كاملة (72 ساعة) من تاريخ إنشاء المنظمة، ويتم عرض الوقت المتبقي بالأيام والساعات والدقائق والثواني بشكل مباشر.",
        "ما الفرق بين هامش الربح (Margin) ونسبة الإضافة (Markup)؟" to
            "الهامش يُحسب بقسمة الربح على سعر البيع، بينما Markup يُحسب بقسمة الربح على تكلفة الوحدة. تفصل حاسبة FVG بينهما بوضوح لمنع التسعير بأقل من المستهدف.",
        "هل تخلط المنصة بين القيمة الدفترية للمخزون وتكلفة الاستبدال؟" to
            "لا أبداً. تُحسب القيمة الدفترية المحاسبية حصراً عبر FIFO أو المتوسط المرجح المتحرك داخل الميزانية، بينما تُعرض تكلفة الاستبدال والقيمة المعدلة بالتضخم في لوحة تحليل إداري مستقلة.",
        "كيف يضمن المساعد الذكي عدم اختلاق أرقام؟" to
            "يتم تمرير ملخص السجلات الفعلية فقط للمنظمة النشطة مع تعليمات صارمة بعدم التخمين والإشارة الصريحة لأي بيانات غير مسجلة."
    ) else listOf(
        "How long is the free trial and how is it tracked?" to
            "Every newly created organization receives a full 3-day (72-hour) free trial with a live Days : Hours : Minutes : Seconds countdown on the Dashboard and Plan Settings.",
        "Why does FVG separate Profit Margin % from Markup %?" to
            "Margin divides unit profit by selling price, whereas Markup divides unit profit by unit cost. Mixing them causes systematic underpricing; FVG computes both independently.",
        "How does Inventory Book Value differ from Replacement Cost?" to
            "Accounting Book Value (FIFO or Moving Weighted Average) drives your official Balance Sheet and COGS, while Replacement Cost and Inflation-Adjusted panels show management how much capital is required to restock at current prices.",
        "How are Double-Entry Journals protected against tampering?" to
            "Posted entries enforce equal total debits and credits and are locked from edits in Firestore security rules. Corrections use explicit Reversal entries plus an immutable audit trail."
    )

    faqs.forEach { (q, a) ->
        FvgCard {
            Text(q, style = MaterialTheme.typography.titleMedium, color = FvgDeepGreen)
            Text(a, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun PublicContactSection(
    isArabic: Boolean,
    onSendEmail: (String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf<String?>(null) }

    FvgCard {
        Text(
            text = if (isArabic) "تواصل مع فريق FVG" else "Contact FVG Team",
            style = MaterialTheme.typography.titleLarge,
            color = FvgDeepGreen
        )
        Surface(shape = RoundedCornerShape(12.dp), color = FvgSoftCream, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = if (isArabic)
                    "ملاحظة محول البريد: يتم إرسال الاستفسار عبر تطبيق البريد في جهازك إلى support@fvg-finance.app (خادم SMTP غير مدمج محلياً)."
                else
                    "Email Adapter Status: Inquiries dispatch securely through your device email client to support@fvg-finance.app (live SMTP relay requires server credentials).",
                style = MaterialTheme.typography.labelSmall,
                color = FvgDeepGreen,
                modifier = Modifier.padding(10.dp)
            )
        }
        FvgField(name, { name = it }, if (isArabic) "الاسم الكامل" else "Full Name", testTag = "contact_name_input")
        FvgField(email, { email = it }, if (isArabic) "البريد الإلكتروني" else "Work Email", testTag = "contact_email_input")
        FvgField(topic, { topic = it }, if (isArabic) "الموضوع" else "Subject / Inquiry Topic")
        FvgField(message, { message = it }, if (isArabic) "تفاصيل الرسالة" else "Message Details", singleLine = false)

        if (feedback != null) {
            Text(feedback!!, style = MaterialTheme.typography.bodyMedium, color = FvgForestGreen)
        }

        FvgPrimaryButton(
            text = if (isArabic) "إرسال عبر البريد" else "Send Inquiry via Email App",
            icon = Icons.Filled.Email,
            onClick = {
                if (name.isBlank() || !email.contains("@") || message.isBlank()) {
                    feedback = if (isArabic) "يرجى إدخال الاسم وبريد صحيح ونص الرسالة." else "Please provide your name, a valid email, and your message."
                } else {
                    onSendEmail("FVG Inquiry: ${topic.ifBlank { name }}", "From: $name ($email)\n\n$message")
                    feedback = if (isArabic) "تم فتح تطبيق البريد لإرسال استفسارك." else "Prepared inquiry in your email client."
                }
            },
            testTag = "contact_submit_button"
        )
    }
}

@Composable
private fun PublicPrivacySection(isArabic: Boolean) {
    FvgCard {
        Text(
            text = if (isArabic) "سياسة الخصوصية وحماية البيانات" else "Privacy Policy & Tenant Isolation",
            style = MaterialTheme.typography.titleLarge,
            color = FvgDeepGreen
        )
        Text(
            text = if (isArabic)
                "• تخضع كافة بيانات المنظمات لعزل صارم متعدد المستأجرين (Multi-Tenant Isolation) عبر قواعد أمان Firestore ومفاتيح العضوية.\n• لا يتم مشاركة بيانات الأسعار أو الحسابات مع أي منظمة أخرى.\n• المصادقة تتم حصراً عبر Google Identity و Firebase Auth."
            else
                "• Every organization's products, costs, journals, inventory, and audit logs are strictly isolated inside its tenant boundary via zero-trust Firestore rules.\n• FVG never mixes external tenants or fabricates financial data.\n• Authentication uses Google Identity & Firebase Auth with Credential Manager and App Check protection.",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Composable
private fun PublicTermsSection(isArabic: Boolean) {
    FvgCard {
        Text(
            text = if (isArabic) "شروط الخدمة والمنهجية المحاسبية" else "Terms of Service & Accounting Methodology",
            style = MaterialTheme.typography.titleLarge,
            color = FvgDeepGreen
        )
        Text(
            text = if (isArabic)
                "• القيم الناتجة عن الذكاء الاصطناعي ومسودات الفواتير (OCR) تخضع للمراجعة البشرية قبل اعتمادها.\n• تبقى القيود المرحّلة غير قابلة للتعديل لضمان سلامة المراجعة المالية، ويتم التصحيح عبر قيود العكس."
            else
                "• AI analytical responses and document OCR extractions are decision-support drafts and require explicit human verification before posting.\n• Posted accounting journal entries are immutable to preserve audit integrity; corrections are executed via formal reversal entries.",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}
