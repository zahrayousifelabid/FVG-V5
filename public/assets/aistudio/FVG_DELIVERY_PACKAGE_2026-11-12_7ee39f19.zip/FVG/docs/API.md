# API reference — development implementation

Base path: `/api/v1`. JSON requests. Authenticated routes require `Authorization: Bearer <session_token>`.

## Public routes
- `GET /health`
- `POST /auth/register` — email, password (minimum 12 chars), organization_name; creates a 72-hour trial and owner membership.
- `POST /auth/login` — email, password.

## Authenticated routes
- `POST /auth/logout`
- `GET /organizations`
- `POST /organizations` — name, currency.
- `POST /organizations/{org_id}/products` — name, optional sku, unit, currency.
- `GET /organizations/{org_id}/products`
- `POST /organizations/{org_id}/costing` — product_id, period, currency, named components object, good_saleable_units, selling_price.
- `GET /organizations/{org_id}/costing` — immutable snapshot history.
- `POST /organizations/{org_id}/allocations` — pool_name, pool_cost, basis, driver, period, driver_quantities, selected_driver_quantity, source_quantities, assumptions.
- `GET /organizations/{org_id}/allocations`
- `POST /units/convert` — quantity, from_unit, to_unit, explicit conversions map using `from|to` keys.
- `POST /organizations/{org_id}/scenarios` — snapshot_id, name, percentage changes as decimal fractions (e.g. 0.10 = +10%).
- `POST /organizations/{org_id}/research/evidence` — title, one of the approved status values, optional source_ref, notes.
- `GET /organizations/{org_id}/research/evidence`
- `GET /organizations/{org_id}/subscription`

## Calculation routes
- `POST /costs/total` — `components: number[]`.
- `POST /costs/unit` — `total_allocated_cost`, `good_saleable_units`.
- `POST /analysis/break-even-units` — `fixed_costs`, `selling_price`, `variable_cost_per_unit`.
- `POST /analysis/target-price` — `basis: margin|markup`, `unit_cost`, `target_rate`.
- `POST /analysis/profitability` — `selling_price`, `unit_cost`.

All organization routes enforce membership and prevent cross-tenant record access. Write routes require an unexpired trial or active subscription. No payment endpoint exists; `payment_enabled` is false. API docs are a scope reference, not a claim of OpenAPI contract review or production readiness.

## Raw materials, BOM, production costing and inventory (development scope)

All routes below require `Authorization: Bearer <session_token>` and organization membership. Write routes also enforce the server-side 72-hour trial/subscription gate.

- `POST /api/v1/organizations/{org_id}/materials` — create a raw material with base unit, currency and unit cost.
- `GET /api/v1/organizations/{org_id}/materials` — list organization materials.
- `POST /api/v1/organizations/{org_id}/products/{product_id}/bom` — add a material requirement per finished unit and a waste rate in `[0,1)`.
- `GET /api/v1/organizations/{org_id}/products/{product_id}/bom` — list BOM items.
- `POST /api/v1/organizations/{org_id}/production-orders` — calculate an order's material, conversion and overhead cost. Material quantity uses planned units × BOM quantity × (1 + waste rate); unit cost divides total cost by good saleable units. Product, materials and order currency must match. Good units cannot exceed planned units.
- `GET /api/v1/organizations/{org_id}/production-orders` — list costed production orders.
- `POST /api/v1/organizations/{org_id}/inventory/movements` — post a receipt, issue or positive adjustment in the material's base unit. Issues exceeding on-hand stock are rejected.
- `GET /api/v1/organizations/{org_id}/inventory` — current on-hand quantities calculated from movement history.
- `POST /api/v1/organizations/{org_id}/inventory/stocktake` — compare book quantity with a physical count and atomically post the signed difference. Positive differences add a valued incoming layer; negative differences post an issue. A count from zero can establish an opening quantity, but historical backdating is not supported.
- `GET /api/v1/organizations/{org_id}/inventory/valuation?method=fifo|weighted_average` — reconstruct raw-material inventory value from movement history using FIFO layers or moving weighted average.
- `POST /api/v1/organizations/{org_id}/production-orders/{order_id}/issue-materials?method=fifo|weighted_average` — atomically issue BOM quantities (including waste allowance) from raw-material stock once per production order; validates every material before posting, then updates the order's material, total and per-good-unit cost.

Valuation boundaries: valuation is reconstructed from movement records in timestamp/id order, not from a separate perpetual valuation subledger. For weighted average, each historical issue is valued at the moving average immediately before that issue; for FIFO, it consumes oldest available receipt/positive-adjustment layers. Manual issue movement unit_cost is not authoritative to these reconstructed valuation methods. Positive adjustments (including positive stocktake differences and opening quantity entry from a zero book balance) are treated as receipt layers; negative stocktake differences are posted as issues. Stocktake records notes and references but does not provide count-session approval or historical effective dates. Returns, landed-cost allocation and multi-warehouse transfers require separate workflows. Verify completeness and ordering of historical records before financial reporting.


## Research workspace metadata (development scope)

- `POST /organizations/{org_id}/research/establishments` and `GET .../establishments` — register participating or prospective establishments by pseudonym, sector, region and participation status.
- `POST /organizations/{org_id}/research/permissions` and `GET .../permissions` — record permission type/status/reference and optional validity dates. `granted` requires a document/reference identifier; the application records metadata and does not verify the document itself.
- `POST /organizations/{org_id}/research/interactions` and `GET .../interactions` — record interview/survey/observation metadata with a pseudonymous participant code. Matching granted permission is required: interview→interview, survey→survey, observation→site_access. This is not a survey-response store or interview-transcript system.
- `POST /organizations/{org_id}/research/hypotheses`, `GET .../hypotheses`, and `PATCH .../hypotheses/{hypothesis_id}` — maintain hypotheses and evidence references. An assessed status requires evidence records from the same organization. Status is a researcher assessment, not a verified research finding.
- `POST /organizations/{org_id}/research/data-dictionary` and `GET .../data-dictionary` — define variable names, definitions, types, units, allowed values and sensitivity labels.

These routes are organization-scoped and trial/subscription-gated for writes. Permission records do not replace ethics approval, signed consent, privacy review or legal advice. A secure document vault, participant contact register, full survey/interview instrument builder, coding/cleaning pipeline, data-retention automation and research report exporter are not implemented yet.


## Reporting and exports (development scope)

All endpoints require a bearer session and organization membership. Data is limited to the selected organization.

- `GET /api/v1/organizations/{org_id}/reports/costing.csv` — exports persisted costing snapshots with product, period, currency, source component JSON, quantities, price, calculated results and formula version.
- `GET /api/v1/organizations/{org_id}/reports/production.csv` — exports persisted production-order costing records.
- `GET /api/v1/organizations/{org_id}/reports/research.json` — exports research evidence, pseudonymous establishments, permission metadata, interaction metadata, hypotheses and data dictionary. The response carries a notice that the export does not establish findings.

CSV files use UTF-8 with BOM and neutralize values beginning with spreadsheet formula/control prefixes. JSON research export is a structured workspace export, not a publication-ready academic report. PDF/Excel output and report UI are not implemented.

### Cost report downloads

- `GET /api/v1/organizations/{org_id}/reports/costing.csv`
- `GET /api/v1/organizations/{org_id}/reports/costing.xlsx`
- `GET /api/v1/organizations/{org_id}/reports/costing.pdf`
- `GET /api/v1/organizations/{org_id}/reports/production.csv`
- `GET /api/v1/organizations/{org_id}/reports/research.json`

All downloads require a valid bearer session and organization membership. Costing XLSX and PDF contain persisted costing snapshots only. The PDF uses a Latin-capable default font; Arabic glyph shaping/font embedding is not yet configured, so Arabic text in PDF output may not render correctly. XLSX is currently a costing sheet, not a full multi-sheet accounting workbook.

## Production stages, work in progress and finished goods (development scope)

- `POST /organizations/{org_id}/production-orders/{order_id}/stages` — add an ordered production stage with its additional conversion and overhead costs.
- `GET /organizations/{org_id}/production-orders/{order_id}/stages` — list stages in sequence order.
- `POST /organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/labor` — record worker-coded or anonymous labor hours, hourly rate, currency, work description and date against an in-progress stage. The calculated labor amount is added to that stage's conversion cost and therefore flows into WIP and finished-goods receipt costing.
- `GET /organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/labor` — list stage labor entries and total recorded labor cost.
- `PATCH /organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}` — move a stage from `planned` to `in_progress` to `completed`. Earlier stages must be completed before a later stage can start. Completed stages are immutable. When every recorded stage is completed, the production order becomes `completed`.
- `GET /organizations/{org_id}/work-in-progress` — list non-completed production orders and show recorded WIP cost (initial order cost plus all recorded stage costs).
- `POST /organizations/{org_id}/production-orders/{order_id}/finished-goods` — receive finished saleable units only after every recorded stage is complete. Cumulative receipts cannot exceed the order's good saleable units. The receipt unit cost includes the original order cost plus all stage costs divided by good units.
- `GET /organizations/{org_id}/finished-goods` — show finished-goods quantities by product.
- `POST /organizations/{org_id}/finished-goods/movements` — record manual finished-goods issues or positive adjustments. Issues exceeding on-hand quantity are rejected.
- `POST /organizations/{org_id}/finished-goods/stocktake` — compare book quantity with physical count and post the signed difference; positive differences add a valued layer, negative differences issue stock.
- `GET /organizations/{org_id}/finished-goods/valuation?method=fifo|weighted_average` — reconstruct product-level finished-goods quantity, inventory value and average unit cost from timestamped movements using FIFO or moving weighted average. Production receipts use their recorded production-order unit cost; positive adjustments are treated as incoming layers.

BOM material issues can now be posted separately using the production-order `issue-materials` endpoint; the posting is atomic and protected against duplicate issue for the same order. This endpoint updates the order's recorded material and total cost using the selected raw-material valuation method. It does not automatically create a finished-goods receipt; that remains a separately confirmed action after production completion. Stage costs are additional to original order conversion/overhead inputs; users must avoid entering the same cost twice. FIFO and moving weighted-average valuation are available for raw materials and finished goods. Stocktake endpoints now post signed differences for raw materials and finished goods. Batch/lot/expiry, returns, rework, count-session approvals and reusable production routing templates remain outstanding. Scrap is captured and exposed through a provisional yield/cost analysis endpoint; it is not an automatic posting to saleable output or finished-goods inventory. Labor capture is currently manual hours × hourly rate; payroll integration, overtime rules and time-clock verification are not implemented.

### Production-stage actual material consumption and scrap
- `POST /api/v1/organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/materials` records an actual material issue against an in-progress stage. Request fields: `material_id`, `quantity`, `unit`, `valuation_method` (`fifo` or `weighted_average`), and unique organization-scoped `reference`. The material unit and currency must match the registered material and production order. Stock is validated and the issue is posted atomically. The actual issue value replaces the BOM estimate in the order's material-cost field once stage-level actual issues are captured; do not separately add the same actual issue to manual costing inputs.
- `GET /api/v1/organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/materials` lists stage issues and their valuation.
- `POST /api/v1/organizations/{org_id}/production-orders/{order_id}/stages/{stage_id}/scrap` records scrap quantity, product unit, reason, and occurrence date for an in-progress stage. `GET .../scrap` lists these records.
- `GET /api/v1/organizations/{org_id}/production-orders/{order_id}/scrap-analysis` summarizes scrap by stage and provides a provisional yield/cost sensitivity calculation (`planned units − summed stage scrap`). It does not mutate authoritative good units, costs, snapshots, or finished-goods receipts. Because the same units may be rejected at more than one stage, confirm that stage losses are distinct before relying on the summed estimate. The endpoint rejects summed scrap above planned units.

### Standard cost sheets and production variance analysis
- `POST /api/v1/organizations/{org_id}/products/{product_id}/standard-costs` creates a versioned standard-cost sheet. Request fields: `currency`, `materials[]` (`material_id`, `quantity_per_good_unit`, `standard_unit_cost`), `labor_hours_per_good_unit`, `standard_labor_hourly_rate`, and `overhead_per_good_unit`. Each material must belong to the organization and match the product currency. Standard sheets are append-only versions; the variance report uses the latest version.
- `GET /api/v1/organizations/{org_id}/production-orders/{order_id}/variance` compares the latest product standards with actual stage material issues, labor entries and recorded order/stage overhead. Material price variance = (actual rate − standard rate) × actual quantity; material usage variance = (actual quantity − standard quantity allowed for good output) × standard rate. Labor rate and efficiency variances follow the equivalent hours/rate formulas. Positive total variance is unfavorable; negative is favorable.
- Missing actual stage material or labor records are reported as unavailable, not assumed to be zero. The total variance is withheld when material or labor actuals are incomplete. Overhead actuals include recorded order overhead and stage overhead only. Standard sheets are versioned, but a production order does not yet pin a standard version at its start date; the report explicitly identifies the latest version used.

### Research fieldwork workspace

All routes below are authenticated and organization-scoped. Writes require a non-viewer role and an active trial/subscription. Use pseudonymous establishment and participant codes; do not place direct identifiers in notes.

- `POST/GET /api/v1/organizations/{org_id}/research/establishments` — register and list pseudonymous industrial establishments with sector, region and participation status.
- `POST/GET /api/v1/organizations/{org_id}/research/permissions` — record and list permission metadata. A `granted` permission requires a non-empty reference. This records metadata only; it does not verify the signed document or replace ethics/legal review.
- `POST/GET /api/v1/organizations/{org_id}/research/interactions` — log interview, survey or observation metadata. The API requires a matching granted and in-date permission for the selected establishment and interaction type. The record is metadata only, not a finding.
- `POST/GET /api/v1/organizations/{org_id}/research/hypotheses` and `PATCH /api/v1/organizations/{org_id}/research/hypotheses/{hypothesis_id}` — maintain proposed/reviewed hypotheses and assessment status. Evidence references must belong to the same organization; assessed statuses require evidence references. The status is a researcher assessment, not automatic verification.
- `POST/GET /api/v1/organizations/{org_id}/research/data-dictionary` — maintain variable definitions, data types, units, allowed values and sensitivity labels. Creation is audit logged.
- `GET /api/v1/organizations/{org_id}/reports/research.json` — structured workspace export; not a publication-ready academic report.

## Research instrument and data-quality endpoints
- `POST /api/v1/organizations/{org_id}/research/instruments`: create a versioned survey or interview instrument. Fields support `text`, `integer`, `decimal`, `date`, `boolean`, and `category`; optional `required` and `allowed_values` constraints are validated at response capture.
- `GET /api/v1/organizations/{org_id}/research/instruments`: list organization instruments and versions.
- `POST /api/v1/organizations/{org_id}/research/responses`: capture a response linked to an existing interaction and active instrument of the same type. Unknown fields, missing required values, invalid types and disallowed values are rejected.
- `GET /api/v1/organizations/{org_id}/research/responses`: list raw response records.
- `POST /api/v1/organizations/{org_id}/research/responses/{response_id}/cleaning-log`: record a cleaning issue and analysis action without modifying raw response JSON.
- `GET /api/v1/organizations/{org_id}/research/cleaning-logs`: list cleaning records.
- Research JSON export includes instrument definitions, immutable raw responses and cleaning logs. Review consent, anonymization and confidentiality before external sharing.
